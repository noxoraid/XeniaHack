# Changelog

Custom build changes, newest first. (App base: Termux 0.118.0, arm64-v8a only.)

## v2.3 — 2026-10-18
- Fixed: `termux-*` commands (and `termux-help-access`) hanging forever. The app now ships its own `termux-api` client that replaces the one from the package: it calls the receiver inside `com.termux` directly (`am broadcast -n com.termux/com.termux.api.TermuxApiReceiver`) and returns output through named pipes. No `com.termux.api` package and no socket handshake are involved any more.
- Cause confirmed from the package source (termux-api 0.60.0): on Android 14+ its client never uses the listener socket and always runs `am broadcast -n com.termux.api/.TermuxApiReceiver`.
- Changed: `termux-api-start` / `termux-api-stop` no longer point at the missing `com.termux.api` KeepAliveService.
- Added: an apt hook (`apt.conf.d/99-nxr-termux-api`) that puts the built-in client back after every `pkg install/upgrade termux-api`.
- Added: if the app does not answer within 10 s, the client stops with a message instead of waiting for ever.
- Changed: the old socket listener now serves each client on its own thread with a read timeout and restarts itself if it dies (still used by stock clients).
- Known limit: commands that hand a file descriptor back through a socket (USB open, some `termux-saf-*`) report an error with the built-in client.

## v2.2 — 2026-10-18
- Changed: `termux-*` API commands are now handled directly inside the app instead of going through an Android broadcast, which removes the system dispatch delay (noticeable on vivo/OriginOS). A broadcast is still used as fallback.
- Added: per-command timing in `error_log_api_timing_{yyyy-MM-dd}.txt` in Termux home (`queue` = wait before handling, `total` = full time).

## v2.1 — 2026-10-18
- Fixed: File Manager (and any screen with the mascot) force-closing on exit. The mascot bubble was being removed from its parent while the window was detaching, which corrupted the parent's child list (NullPointerException in `dispatchDetachedFromWindow`).

## v2.0 — 2026-10-18
- Removed: SMS, contacts and call log access (`termux-sms-list`, `termux-sms-send`, `termux-contact-list`, `termux-call-log`) and their permissions.
- Changed: APK is now signed with the project's own key `app/noxora.jks`.

## v1.9 — 2026-10-18
- Added: **Termux:API built in.** No separate Termux:API APK anymore; just run `pkg install termux-api` and every `termux-*` command works (contacts, SMS, call log, camera, mic, location, notifications, clipboard, sensors, and the rest). If the old Termux:API APK is installed, uninstall it first.
- Added: `termux-help-access` (typo alias `termux-help-acces`) lists every API command grouped by access, shows which permissions are already granted, and lists what is still missing. `termux-help-access --json` prints the same as JSON.
- Changed: API permissions are declared on the Termux app itself and asked on first use of each command.

## v1.8 — 2026-10-18
- Fixed: tapping a session in the drawer switches to it (taps are read from the list itself; long press renames). Failures go to `error_log_sessions_{yyyy-MM-dd}.txt` in Termux home.
- Changed: the UI font is applied once per view instead of on every layout pass, so it cannot keep re-laying out lists.

## v1.7 — 2026-10-18
- Fixed: mascot speech bubble now lives in the screen layout next to the mascot (not inside its small box), and a hide animation can no longer hide a newer bubble.
- Changed: File Manager taps are read from the list itself (tap = open folder / open editor, long press = select).
- Added: error log in Termux home, `error_log_{name}_{yyyy-MM-dd}.txt` (Asia/Jakarta time). Names: `filemanager`, `mascot`.

## v1.6 — 2026-10-18
- Added: **Read mode** switch in the drawer (above File Manager). On = typing, paste and extra keys are locked and the keyboard stays hidden; Off = typing works again. Scrolling, selecting and copying still work.
- Fixed: tapping a folder or a file in the File Manager now works from the row itself (open folder / open editor), no longer depends on the three-dot button.
- Changed: the mascot keeps the same relative position between the terminal and the File Manager.
- Added: **GitHub** button appears inside any subfolder (Termux home, shared storage). Two modes: Git (default, auto `git init`, install git if missing) or Token (GitHub API).
- Added: upload with a skip list (.git, node_modules, *.log) and commit message, create repo, browse repo files with sizes, create / edit / rename / delete files and folders on GitHub.
- Added: GitHub Actions viewer: runs per branch, full or errors-only log, copy / download log, download artifacts to the Download folder.

## v1.5 — 2026-10-17
- Added: in-app **Changelog** page (Custom Settings v2 → Changelog).
- This file lives in `app/src/main/assets/CHANGELOG.md`; every update adds an entry here.

## v1.4 — 2026-10-17
- Changed: mascot no longer uses text-to-speech. It now plays short built-in sound effects: swoosh (roaming), blink (wink), pop (bubble / drag release), boing (tap), chirp (random chatter).
- Added: File Manager **Select** and **Select all** in the top menu; **Select all / Unselect all / Done** in the selection menu. Works in every storage tab.
- Fixed: the selection menu can be opened even when nothing is selected.

## v1.3 — 2026-10-17
- Added: mascot says random lines (English + Indonesian) in a bubble every 14–30 seconds. Not in the Editor.
- Added: Custom Settings v2 mascot switches: **Hide bot**, **Hide text**, **Hide sound**.
- Added: **Back** button in Custom Settings v2.
- Fixed: File Manager checks a folder before entering it, so an unreadable folder (e.g. `Android/data`) shows a message instead of an empty screen.

## v1.2 — 2026-10-17
- Added: **Custom Settings v2** (drawer → Custom Settings v2).
- Added: Google Fonts picker, separate for **Terminal font** (also used by the Editor) and **UI font** (drawer, File Manager, dialogs, other screens).
- Added: Reset to default for each font.

## v1.1 — 2026-10-17
- Changed: only one GitHub workflow is kept (`build.yml`); other `.github` YAML files (funding, dependabot, issue templates) removed.
- Fixed: build error in `MascotWidget` (`requestDisallowInterceptTouchEvent` called on a `View`).

## v1.0 — 2026-10-17
- Base custom build: arm64-v8a only, only the aarch64 bootstrap (about 35 MB APK).
- Custom popups (input / confirm / menu).
- Redesigned drawer (rename / close per session, File Manager entry).
- File Manager (light theme) for Termux home and shared storage.
- Editor with line numbers.
- Offline mascot with roaming, speech bubble and drag.
