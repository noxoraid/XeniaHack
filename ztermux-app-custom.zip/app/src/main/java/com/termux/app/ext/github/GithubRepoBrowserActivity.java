package com.termux.app.ext.github;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.termux.R;
import com.termux.app.ext.filemanager.FileOps;
import com.termux.app.ext.task.TaskCenter;
import com.termux.app.ext.ui.CustomDialogs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GithubRepoBrowserActivity extends AppCompatActivity implements GithubRowAdapter.Listener {

    public static final String EXTRA_REPO = "com.termux.app.ext.github.EXTRA_REPO";
    public static final String EXTRA_BRANCH = "com.termux.app.ext.github.EXTRA_BRANCH";

    private static final long LARGEST_EDIT_BYTES = 1024L * 1024L;

    private interface Job {
        void run() throws IOException;
    }

    private final ExecutorService mIo = Executors.newSingleThreadExecutor();

    private String mRepo;
    private String mBranch;
    private String mDirectory = "";
    private GithubRestClient mClient;
    private GithubCommitWriter mWriter;
    private GithubTreeSnapshot mSnapshot;
    private GithubRowAdapter mAdapter;
    private TextView mPath, mEmpty, mSummary;
    private View mLoading;
    private volatile boolean mBusy;

    @NonNull
    public static Intent intentFor(@NonNull Context context, @NonNull String repo, @NonNull String branch) {
        Intent intent = new Intent(context, GithubRepoBrowserActivity.class);
        intent.putExtra(EXTRA_REPO, repo);
        intent.putExtra(EXTRA_BRANCH, branch);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_github_browser);

        mRepo = getIntent().getStringExtra(EXTRA_REPO);
        mBranch = getIntent().getStringExtra(EXTRA_BRANCH);
        String token = new GithubLinkStore(this).token();
        if (mRepo == null || mBranch == null || token.isEmpty()) { finish(); return; }
        mClient = new GithubRestClient(token);
        mWriter = new GithubCommitWriter(mClient, mRepo);

        mPath = findViewById(R.id.gb_path);
        mEmpty = findViewById(R.id.gb_empty);
        mSummary = findViewById(R.id.gb_summary);
        mLoading = findViewById(R.id.gb_loading);
        ((TextView) findViewById(R.id.gb_title)).setText(mRepo + " · " + mBranch);

        mAdapter = new GithubRowAdapter(this, this);
        ListView list = findViewById(R.id.gb_list);
        list.setAdapter(mAdapter);

        findViewById(R.id.gb_back).setOnClickListener(v -> finish());
        findViewById(R.id.gb_up).setOnClickListener(v -> goUp());
        findViewById(R.id.gb_more).setOnClickListener(v -> showTopMenu());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mClient != null) reload();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mIo.shutdownNow();
    }

    @Override
    public void onBackPressed() {
        if (!mDirectory.isEmpty()) { goUp(); return; }
        super.onBackPressed();
    }

    private void goUp() {
        if (mDirectory.isEmpty()) return;
        int slash = mDirectory.lastIndexOf('/');
        mDirectory = slash < 0 ? "" : mDirectory.substring(0, slash);
        render();
    }

    private void reload() {
        mLoading.setVisibility(View.VISIBLE);
        mIo.execute(() -> {
            GithubTreeSnapshot fresh = null;
            String problem = null;
            try {
                fresh = GithubTreeSnapshot.fetch(mClient, mRepo, mBranch);
            } catch (GithubApiException e) {
                if (e.status != 404 && e.status != 409) problem = e.getMessage();
            } catch (IOException e) {
                problem = e.getMessage();
            }
            final GithubTreeSnapshot snapshot = fresh;
            final String error = problem;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                mLoading.setVisibility(View.GONE);
                if (error != null) Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                mSnapshot = snapshot;
                render();
            });
        });
    }

    private void render() {
        mPath.setText("/" + mDirectory);
        List<GithubRowAdapter.Row> rows = new ArrayList<>();
        if (mSnapshot == null) {
            mAdapter.setRows(rows);
            mEmpty.setText("Nothing on branch " + mBranch + " yet.\nUpload this folder from the GitHub screen first.");
            mEmpty.setVisibility(View.VISIBLE);
            mSummary.setText("");
            return;
        }
        for (GithubTreeSnapshot.Node node : mSnapshot.children(mDirectory)) {
            String detail = node.directory
                ? FileOps.humanSize(mSnapshot.folderBytes(node.path)) + "  •  " + mSnapshot.folderFiles(node.path) + " files"
                : FileOps.humanSize(node.size);
            rows.add(new GithubRowAdapter.Row(node.name, detail, node.directory ? R.drawable.ic_folder : R.drawable.ic_file,
                node.directory ? R.color.fm_folder : R.color.fm_file, node, true));
        }
        mAdapter.setRows(rows);
        mEmpty.setText("This folder is empty");
        mEmpty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
        String here = mDirectory.isEmpty() ? "Whole repo" : "This folder";
        long bytes = mDirectory.isEmpty() ? mSnapshot.totalBytes() : mSnapshot.folderBytes(mDirectory);
        mSummary.setText(rows.size() + " items  •  " + here + " " + FileOps.humanSize(bytes) + (mSnapshot.isTruncated() ? "  •  partial listing" : ""));
    }

    @Override
    public void onRowClicked(@NonNull GithubRowAdapter.Row row) {
        GithubTreeSnapshot.Node node = (GithubTreeSnapshot.Node) row.tag;
        if (node.directory) {
            mDirectory = node.path;
            render();
            return;
        }
        if (node.size > LARGEST_EDIT_BYTES) {
            Toast.makeText(this, "File is too large to edit here (max 1 MB)", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(GithubFileEditActivity.intentFor(this, mRepo, mBranch, node.path, node.sha));
    }

    @Override
    public void onRowMenu(@NonNull GithubRowAdapter.Row row) {
        final GithubTreeSnapshot.Node node = (GithubTreeSnapshot.Node) row.tag;
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
        entries.add(new CustomDialogs.MenuEntry("Rename or move", R.drawable.ic_edit));
        entries.add(new CustomDialogs.MenuEntry("Delete", R.drawable.ic_delete, true));
        CustomDialogs.menu(this, true, node.name, entries, index -> {
            if (index == 0) promptRename(node); else confirmDelete(node);
        });
    }

    private void showTopMenu() {
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
        entries.add(new CustomDialogs.MenuEntry("New file", R.drawable.ic_file));
        entries.add(new CustomDialogs.MenuEntry("New folder", R.drawable.ic_folder));
        entries.add(new CustomDialogs.MenuEntry("Refresh", R.drawable.ic_sync));
        CustomDialogs.menu(this, true, mRepo, entries, index -> {
            if (index == 0) promptCreate(false);
            else if (index == 1) promptCreate(true);
            else reload();
        });
    }

    private String joinHere(@NonNull String name) {
        String clean = name.trim();
        while (clean.startsWith("/")) clean = clean.substring(1);
        return mDirectory.isEmpty() ? clean : mDirectory + "/" + clean;
    }

    private boolean invalidName(@NonNull String name) {
        String clean = name.trim();
        if (clean.isEmpty() || clean.contains("//")) return true;
        for (String part : clean.split("/")) if (part.equals("..") || part.equals(".")) return true;
        return false;
    }

    private void promptCreate(boolean folder) {
        CustomDialogs.input(this, true, folder ? "New folder" : "New file", folder ? "Folder name" : "File name", null, "Create", name -> {
            if (invalidName(name)) { Toast.makeText(this, "Invalid name", Toast.LENGTH_SHORT).show(); return; }
            final String target = joinHere(name) + (folder ? "/.gitkeep" : "");
            if (mSnapshot != null && mSnapshot.exists(target)) { Toast.makeText(this, "Already exists", Toast.LENGTH_SHORT).show(); return; }
            work("Creating…", () -> mWriter.putFile(mBranch, target, new byte[0], null, "Create " + target));
        });
    }

    private void promptRename(@NonNull GithubTreeSnapshot.Node node) {
        CustomDialogs.input(this, true, "Rename or move", "New path from repo root", node.path, "Apply", text -> {
            String target = text.trim();
            while (target.startsWith("/")) target = target.substring(1);
            if (invalidName(target)) { Toast.makeText(this, "Invalid path", Toast.LENGTH_SHORT).show(); return; }
            final String finalTarget = target;
            final GithubTreeSnapshot snapshot = mSnapshot;
            if (snapshot == null) return;
            work("Renaming…", () -> mWriter.renamePath(snapshot, mBranch, node.path, finalTarget));
        });
    }

    private void confirmDelete(@NonNull GithubTreeSnapshot.Node node) {
        final GithubTreeSnapshot snapshot = mSnapshot;
        if (snapshot == null) return;
        String message = node.directory ? "The folder and everything inside it will be deleted in one commit." : "The file will be deleted in one commit.";
        CustomDialogs.confirm(this, true, "Delete " + node.name + "?", message, "Delete", true,
            () -> work("Deleting…", () -> mWriter.deletePath(snapshot, mBranch, node.path)));
    }

    private void work(String label, @NonNull Job job) {
        if (mBusy) { Toast.makeText(this, "Still working…", Toast.LENGTH_SHORT).show(); return; }
        mBusy = true;
        mLoading.setVisibility(View.VISIBLE);
        if (label != null) Toast.makeText(this, label, Toast.LENGTH_SHORT).show();
        TaskCenter.submit(this, "github", (label == null ? "GitHub" : label.replace("…", "")) + " · " + mRepo,
            GithubRepoBrowserActivity.intentFor(this, mRepo, mBranch), false, handle -> {
                handle.progress(-1, label == null ? "Working…" : label);
                job.run();
            }, item -> {
                mBusy = false;
                if (isFinishing()) return;
                if (item.state == TaskCenter.State.FAILED) {
                    mLoading.setVisibility(View.GONE);
                    Toast.makeText(this, item.status, Toast.LENGTH_LONG).show();
                } else {
                    reload();
                }
            });
    }
}
