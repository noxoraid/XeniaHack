package com.termux.app.ext.github;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.termux.app.ext.diagnostics.TermuxErrorJournal;
import com.termux.app.ext.github.GitErrorDoctor.Kind;
import com.termux.shared.termux.TermuxConstants;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Runs git and, when it fails, works out why and fixes it by itself, then retries.
 * Only when the user must decide something (token, name, force push) it throws {@link NeedsUser}.
 */
public final class GitHealer {

    public static final class NeedsUser extends IOException {
        public final Kind kind;

        public NeedsUser(@NonNull Kind kind, @NonNull String message) {
            super(message);
            this.kind = kind;
        }
    }

    private static final String LOG_SOURCE = "github-hub";
    private static final int MAX_ROUNDS = 10;
    private static final String[] APT_FLAGS = {"-y", "-o", "Dpkg::Options::=--force-confold", "-o", "Dpkg::Options::=--force-confdef"};

    private final Context mContext;
    private final GitShell mGit;
    private final File mDir;
    private final GithubLinkStore mStore;
    private final GitShell.Sink mSink;
    private final Map<Kind, Integer> mTries = new EnumMap<>(Kind.class);
    private String mCommitMessage = GithubLinkStore.DEFAULT_MESSAGE;
    @Nullable private String[] mReplacement;

    public GitHealer(@NonNull Context context, @NonNull GitShell git, @NonNull File dir,
                     @NonNull GithubLinkStore store, @NonNull GitShell.Sink sink) {
        mContext = context.getApplicationContext();
        mGit = git;
        mDir = dir;
        mStore = store;
        mSink = sink;
    }

    public GitHealer commitMessage(@NonNull String message) {
        mCommitMessage = message;
        return this;
    }

    // ------------------------------------------------------------------ running

    @NonNull
    public GitShell.Outcome run(@NonNull String... args) throws IOException {
        return runAccepting(null, args);
    }

    /** acceptRegex: output that counts as success even when git exits non-zero (e.g. "nothing to commit"). */
    @NonNull
    public GitShell.Outcome runAccepting(@Nullable String acceptRegex, @NonNull String... args) throws IOException {
        String[] current = args;
        GitShell.Outcome last = null;
        Pattern accept = acceptRegex == null ? null : Pattern.compile(acceptRegex);
        for (int round = 0; round < MAX_ROUNDS; round++) {
            last = mGit.git(mSink, current);
            if (last.ok() || (accept != null && accept.matcher(last.text).find())) return last;
            Kind kind = GitErrorDoctor.diagnose(last.text);
            int attempt = bump(kind);
            say("⚠ " + GitErrorDoctor.title(kind));
            if (attempt > GitErrorDoctor.maxTries(kind)) throw giveUp(kind, last);
            mReplacement = null;
            fix(kind, current, last);
            if (mReplacement != null) current = mReplacement;
        }
        throw new IOException("Still failing after several automatic fixes.\n" + tail(last == null ? "" : last.text));
    }

    private int bump(Kind kind) {
        Integer value = mTries.get(kind);
        int next = value == null ? 1 : value + 1;
        mTries.put(kind, next);
        return next;
    }

    private void say(@NonNull String line) {
        mSink.line(line);
    }

    private void fixing(@NonNull String line) {
        mSink.line("🔧 " + line);
    }

    // ------------------------------------------------------------------ the fixes

    private void fix(Kind kind, String[] args, GitShell.Outcome failed) throws IOException {
        boolean pulling = args.length > 0 && "pull".equals(args[0]);
        switch (kind) {
            case BROKEN_BINARY:
                fixing("Updating Termux packages so git and libcurl match again…");
                repairPackages(mTries.get(kind) > 1);
                if (!mGit.git(null, "--version").ok()) throw giveUp(kind, failed);
                return;
            case DUBIOUS_OWNERSHIP:
                fixing("git config --global --add safe.directory " + mDir.getAbsolutePath());
                mGit.ensureSafeDirectory();
                if (mTries.get(kind) > 1) mGit.allowAllDirectories();
                return;
            case INDEX_LOCK:
                fixing("Removing stale .lock files in .git");
                removeLocks(failed.text);
                return;
            case DPKG_INTERRUPTED:
                fixing("dpkg --configure -a");
                mGit.run(mSink, "dpkg", "--configure", "-a");
                return;
            case PKG_LOCK:
                fixing("Waiting for the other package manager…");
                sleep(4000);
                return;
            case PKG_MIRROR:
                fixing("Refreshing package lists");
                mGit.run(mSink, "apt-get", "update");
                return;
            case NO_IDENTITY:
                if (!autoIdentity()) throw new NeedsUser(Kind.NO_IDENTITY, "git needs a name and email for commits.");
                return;
            case GPG:
                fixing("Turning commit signing off");
                mGit.git(null, "config", "--global", "commit.gpgsign", "false");
                return;
            case NOT_A_REPO:
                fixing("git init");
                if (!mGit.git(mSink, "init", "-b", mStore.branchFor(mDir)).ok()) mGit.git(mSink, "init");
                return;
            case UNRELATED_HISTORIES:
                fixing("Merging with --allow-unrelated-histories (your local files win on conflicts)");
                if (pulling) {
                    mReplacement = withFlags(args, "--allow-unrelated-histories", "-X", "ours");
                } else {
                    pullRemote(true);
                }
                return;
            case MERGE_CONFLICT:
                fixing("Resolving conflicts by keeping your local version");
                keepLocalAfterConflict();
                return;
            case UNFINISHED_MERGE:
                fixing("Cleaning up the unfinished merge/rebase");
                abortUnfinished();
                return;
            case NO_COMMITS:
                fixing("Creating the first commit");
                mGit.git(mSink, "add", "-A");
                mGit.git(mSink, "-c", "commit.gpgsign=false", "commit", "--allow-empty", "-m", mCommitMessage);
                return;
            case NON_FAST_FORWARD:
                if (mTries.get(kind) >= 3) throw new NeedsUser(Kind.NON_FAST_FORWARD,
                    "GitHub still has newer commits that cannot be merged automatically.");
                fixing("git pull to bring in what GitHub already has, then push again");
                if (pulling) return;
                pullRemote(false);
                return;
            case SSL_CERT:
                fixing("Reinstalling ca-certificates");
                mGit.run(mSink, "apt-get", "install", "--reinstall", "-y", "ca-certificates");
                File bundle = new File(TermuxConstants.TERMUX_PREFIX_DIR_PATH, "etc/tls/cert.pem");
                if (bundle.exists()) mGit.git(null, "config", "--global", "http.sslCAInfo", bundle.getAbsolutePath());
                say("If it keeps failing, check that the phone date and time are correct.");
                return;
            case AUTH_FAILED:
                fixAuth();
                return;
            case NO_REMOTE:
            case REMOTE_EXISTS:
                linkOrigin();
                return;
            case REPO_NOT_FOUND:
                checkRepoExists();
                return;
            case BIG_FILE:
                excludeBigFiles(failed.text);
                return;
            case BIG_PUSH:
                fixing("Using a bigger http buffer and HTTP/1.1 for this push");
                mGit.git(null, "config", "--global", "http.postBuffer", "524288000");
                mGit.git(null, "config", "--global", "http.version", "HTTP/1.1");
                mGit.git(null, "config", "--global", "http.lowSpeedLimit", "0");
                mGit.git(null, "config", "--global", "http.lowSpeedTime", "999999");
                return;
            case NETWORK:
                fixing("Network hiccup, trying again in a moment…");
                sleep(3000L * mTries.get(kind));
                return;
            case FS_PERMS:
                fixing("Disabling file modes and symlinks for this folder");
                mGit.git(null, "config", "core.filemode", "false");
                mGit.git(null, "config", "core.symlinks", "false");
                return;
            default:
                throw giveUp(kind, failed);
        }
    }

    @NonNull
    private IOException giveUp(Kind kind, GitShell.Outcome failed) {
        String detail = tail(failed.text);
        TermuxErrorJournal.note(LOG_SOURCE, "GAVE UP on " + kind + "\n" + detail);
        switch (kind) {
            case BROKEN_BINARY:
                return new NeedsUser(kind, "git in Termux is still broken after updating.");
            case BIG_PUSH:
                return new NeedsUser(kind, "git keeps getting cut off on this push.");
            case NON_FAST_FORWARD:
                return new NeedsUser(kind, "GitHub has commits you do not have.");
            case SECRET_BLOCKED:
                return new IOException("GitHub push protection found a secret (token or key) in your files. Remove it from the files "
                    + "or use the unblock link printed above, then upload again.");
            case PROTECTED_BRANCH:
                return new IOException("This branch is protected on GitHub. Press Branch, type another branch name and upload again.");
            case STORAGE_DENIED:
                return new IOException("Android blocked writing here. Give the app \"All files access\" in Settings, "
                    + "or move the folder into Termux home.");
            case NETWORK:
                return new IOException("Cannot reach GitHub. Check the internet connection and press Upload again.");
            case AUTH_FAILED:
                return new NeedsUser(kind, "GitHub rejected the login.");
            default:
                return new IOException(GitErrorDoctor.title(kind) + "\n" + detail
                    + "\n(Full output saved in " + TermuxErrorJournal.logPathHint(LOG_SOURCE) + ")");
        }
    }

    private void repairPackages(boolean reinstall) throws IOException {
        mGit.run(mSink, "apt-get", "update");
        if (!reinstall) {
            List<String> cmd = aptCommand("full-upgrade");
            mGit.run(mSink, cmd.toArray(new String[0]));
            return;
        }
        for (String pkg : new String[]{"libcurl", "libngtcp2", "libnghttp3", "libnghttp2", "openssl", "git"}) {
            List<String> cmd = aptCommand("install");
            cmd.add("--reinstall");
            cmd.add(pkg);
            mGit.run(mSink, cmd.toArray(new String[0]));
        }
    }

    private List<String> aptCommand(String verb) {
        List<String> cmd = new ArrayList<>();
        cmd.add("apt-get");
        for (String flag : APT_FLAGS) cmd.add(flag);
        cmd.add(verb);
        return cmd;
    }

    /** Installs git by itself, repairing dpkg / mirrors on the way. */
    public void installGit() throws IOException {
        GitShell.Outcome last = null;
        for (int round = 0; round < 4; round++) {
            last = mGit.run(mSink, "pkg", "install", "-y", "git");
            if (last.ok() && GitShell.isInstalled()) return;
            Kind kind = GitErrorDoctor.diagnose(last.text);
            say("⚠ " + GitErrorDoctor.title(kind));
            if (kind == Kind.DPKG_INTERRUPTED) { fixing("dpkg --configure -a"); mGit.run(mSink, "dpkg", "--configure", "-a"); }
            else if (kind == Kind.PKG_LOCK) { fixing("Waiting for the other package manager…"); sleep(4000); }
            else { fixing("apt-get update"); mGit.run(mSink, "apt-get", "update"); }
        }
        throw new IOException("Could not install git automatically. Run termux-change-repo, then pkg install git in the terminal.\n"
            + tail(last == null ? "" : last.text));
    }

    private void fixAuth() throws IOException {
        if (!mStore.hasToken()) throw new NeedsUser(Kind.AUTH_FAILED, "GitHub needs a token to push over https.");
        try {
            new GithubRestClient(mStore.token()).whoAmI();
        } catch (GithubApiException e) {
            if (e.status == 401) throw new NeedsUser(Kind.AUTH_FAILED, "Your saved token is invalid or expired.");
            throw e;
        }
        String origin = mGit.capture("remote", "get-url", "origin");
        String repo = GithubLinkStore.repoFromText(origin);
        if (repo != null && !origin.startsWith("https://github.com/")) {
            fixing("Switching origin to https so the token is used");
            mGit.git(null, "remote", "set-url", "origin", "https://github.com/" + repo + ".git");
            return;
        }
        throw new IOException("The token is valid but GitHub still refuses the push. It needs the repo scope (and workflow if you push "
            + ".github/workflows files) and write access to " + (repo == null ? "the repository" : repo) + ".");
    }

    private void linkOrigin() throws IOException {
        String repo = mStore.repoFor(mDir);
        if (repo.isEmpty()) throw new NeedsUser(Kind.NO_REMOTE, "No GitHub repository is linked to this folder.");
        String url = "https://github.com/" + repo + ".git";
        fixing("Linking origin to " + repo);
        if (!mGit.git(null, "remote", "set-url", "origin", url).ok()) mGit.git(null, "remote", "add", "origin", url);
    }

    private void checkRepoExists() throws IOException {
        if (!mStore.hasToken()) throw new NeedsUser(Kind.AUTH_FAILED, "Private repositories need a token.");
        String repo = mStore.repoFor(mDir);
        if (repo.isEmpty()) repo = String.valueOf(GithubLinkStore.repoFromText(mGit.capture("remote", "get-url", "origin")));
        try {
            new GithubRestClient(mStore.token()).getObject("/repos/" + repo);
        } catch (GithubApiException e) {
            if (e.status == 404) throw new NeedsUser(Kind.REPO_NOT_FOUND, repo + " does not exist (or the token cannot see it).");
            throw e;
        }
        throw new IOException(repo + " exists, but git was refused. Check that the token has the repo scope and write access.");
    }

    @NonNull
    public String authTarget() {
        String origin = mGit.capture0("remote", "get-url", "origin");
        String repo = GithubLinkStore.repoFromText(origin);
        if (mStore.hasToken() && repo != null) {
            return "https://x-access-token:" + mStore.token() + "@github.com/" + repo + ".git";
        }
        return "origin";
    }

    private void pullRemote(boolean unrelated) throws IOException {
        String branch = mStore.branchFor(mDir);
        List<String> cmd = new ArrayList<>();
        cmd.add("pull"); cmd.add("--no-rebase"); cmd.add("--no-edit");
        if (unrelated) { cmd.add("--allow-unrelated-histories"); cmd.add("-X"); cmd.add("ours"); }
        cmd.add(authTarget()); cmd.add(branch);
        GitShell.Outcome out = mGit.git(mSink, cmd.toArray(new String[0]));
        if (out.ok()) return;
        String text = out.text.toLowerCase();
        if (text.contains("couldn't find remote ref")) { say("The branch does not exist on GitHub yet, it will be created."); return; }
        Kind next = GitErrorDoctor.diagnose(out.text);
        if (next == Kind.MERGE_CONFLICT) { fixing("Conflicts: keeping your local version"); keepLocalAfterConflict(); return; }
        if (next == Kind.UNRELATED_HISTORIES && !unrelated) { pullRemote(true); return; }
        if (next == Kind.UNFINISHED_MERGE) { abortUnfinished(); return; }
        throw giveUp(next, out);
    }

    private void keepLocalAfterConflict() throws IOException {
        mGit.git(mSink, "checkout", "--ours", "--", ".");
        mGit.git(mSink, "add", "-A");
        mGit.git(mSink, "-c", "commit.gpgsign=false", "commit", "--no-edit", "-m", "Merge GitHub changes (kept local files on conflict)");
    }

    private void abortUnfinished() throws IOException {
        if (mGit.git(null, "merge", "--abort").ok()) return;
        if (mGit.git(null, "rebase", "--abort").ok()) return;
        if (mGit.git(null, "cherry-pick", "--abort").ok()) return;
        mGit.git(mSink, "add", "-A");
        mGit.git(mSink, "-c", "commit.gpgsign=false", "commit", "--no-edit", "-m", "Finish merge");
    }

    private void removeLocks(@NonNull String errorText) {
        Matcher m = Pattern.compile("Unable to create '([^']+\\.lock)'").matcher(errorText);
        String root = mDir.getAbsolutePath();
        while (m.find()) {
            File lock = new File(m.group(1));
            if (lock.getAbsolutePath().startsWith(root) && lock.delete()) say("Deleted " + lock.getName());
        }
        deleteLocksIn(new File(mDir, ".git"), 0);
    }

    private void deleteLocksIn(File folder, int depth) {
        File[] children = folder.listFiles();
        if (children == null || depth > 6) return;
        for (File child : children) {
            if (child.isDirectory()) {
                if (!child.getName().equals("objects")) deleteLocksIn(child, depth + 1);
            } else if (child.getName().endsWith(".lock") && child.delete()) {
                say("Deleted " + child.getName());
            }
        }
    }

    private void excludeBigFiles(@NonNull String text) throws IOException {
        Matcher m = Pattern.compile("(?i)file (\\S+) is [\\d.]+ ?mb").matcher(text);
        List<String> paths = new ArrayList<>();
        while (m.find()) paths.add(m.group(1));
        if (paths.isEmpty()) throw new IOException("GitHub rejected a file over 100 MB. Add it to Excludes and upload again.");
        String head = mGit.capture("rev-parse", "HEAD");
        StringBuilder excludes = new StringBuilder(mStore.excludesFor(mDir));
        boolean inOlderCommits = false;
        for (String path : paths) {
            excludes.append(", ").append(path);
            String history = mGit.capture("log", "--format=%H", "--", path).trim();
            if (!history.isEmpty() && !history.equals(head)) inOlderCommits = true;
            fixing("Excluding " + path);
            mGit.git(mSink, "rm", "--cached", "-r", "--ignore-unmatch", "--", path);
        }
        mStore.setExcludesFor(mDir, excludes.toString());
        if (inOlderCommits) {
            throw new IOException("The big file is also in older local commits. It is now in Excludes. Switch to API mode "
                + "(no history is sent) or delete the .git folder and upload again.");
        }
        mGit.git(mSink, "-c", "commit.gpgsign=false", "commit", "--amend", "--no-edit");
    }

    /** Name + email from the GitHub token, so nobody has to type them. */
    public boolean autoIdentity() {
        if (!mStore.hasToken()) return false;
        try {
            JSONObject user = new GithubRestClient(mStore.token()).whoAmI();
            String login = user.optString("login");
            if (login.isEmpty()) return false;
            String name = user.optString("name", "");
            if (name.isEmpty() || "null".equals(name)) name = login;
            String email = user.optString("email", "");
            if (email.isEmpty() || "null".equals(email)) email = user.optLong("id") + "+" + login + "@users.noreply.github.com";
            mGit.git(null, "config", "--global", "user.name", name);
            mGit.git(null, "config", "--global", "user.email", email);
            fixing("Set git identity from your GitHub account: " + name + " <" + email + ">");
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ helpers

    @NonNull
    private static String[] withFlags(String[] args, String... flags) {
        List<String> out = new ArrayList<>();
        out.add(args[0]);
        for (String f : flags) out.add(f);
        for (int i = 1; i < args.length; i++) out.add(args[i]);
        return out.toArray(new String[0]);
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    @NonNull
    static String tail(@NonNull String text) {
        String[] lines = text.trim().split("\\n");
        StringBuilder out = new StringBuilder();
        for (int i = Math.max(0, lines.length - 6); i < lines.length; i++) out.append(lines[i]).append('\n');
        return out.toString().trim();
    }
}
