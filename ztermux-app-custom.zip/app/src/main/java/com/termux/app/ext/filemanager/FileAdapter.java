package com.termux.app.ext.filemanager;

import android.content.Context;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.termux.R;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** List adapter for the File Manager with multi-selection support. */
public class FileAdapter extends BaseAdapter {

    public interface Listener {
        void onMoreClicked(@NonNull FileEntry entry);
    }

    private final Context mContext;
    private final LayoutInflater mInflater;
    private final Listener mListener;
    private final List<FileEntry> mItems = new ArrayList<>();
    private final Set<String> mSelected = new LinkedHashSet<>();
    private boolean mSelectionMode;

    public FileAdapter(@NonNull Context context, @NonNull Listener listener) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
        mListener = listener;
    }

    // --------------------------------------------------------------------- data

    public void setItems(@NonNull List<FileEntry> items) {
        mItems.clear();
        mItems.addAll(items);
        // Drop selections that no longer exist.
        Set<String> keep = new LinkedHashSet<>();
        for (FileEntry e : mItems) if (mSelected.contains(e.path())) keep.add(e.path());
        mSelected.retainAll(keep);
        notifyDataSetChanged();
    }

    // ---------------------------------------------------------------- selection

    public boolean isSelectionMode() { return mSelectionMode; }

    public void setSelectionMode(boolean enabled) {
        mSelectionMode = enabled;
        if (!enabled) mSelected.clear();
        notifyDataSetChanged();
    }

    public void toggle(@NonNull FileEntry entry) {
        if (!mSelected.remove(entry.path())) mSelected.add(entry.path());
        notifyDataSetChanged();
    }

    public void select(@NonNull FileEntry entry) {
        mSelected.add(entry.path());
        notifyDataSetChanged();
    }

    public void selectAll() {
        for (FileEntry e : mItems) mSelected.add(e.path());
        notifyDataSetChanged();
    }

    public void unselectAll() {
        mSelected.clear();
        notifyDataSetChanged();
    }

    public int selectedCount() { return mSelected.size(); }

    public boolean allSelected() { return !mItems.isEmpty() && mSelected.size() == mItems.size(); }

    @NonNull
    public List<FileEntry> getSelected() {
        List<FileEntry> out = new ArrayList<>();
        for (FileEntry e : mItems) if (mSelected.contains(e.path())) out.add(e);
        return out;
    }

    // ------------------------------------------------------------- BaseAdapter

    @Override public int getCount() { return mItems.size(); }
    @Override public FileEntry getItem(int position) { return mItems.get(position); }
    @Override public long getItemId(int position) { return mItems.get(position).path().hashCode(); }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView != null ? convertView : mInflater.inflate(R.layout.item_file_entry, parent, false);
        final FileEntry e = getItem(position);

        ImageView icon = row.findViewById(R.id.fm_icon);
        ImageView check = row.findViewById(R.id.fm_check);
        TextView name = row.findViewById(R.id.fm_name);
        TextView meta = row.findViewById(R.id.fm_meta);
        ImageButton more = row.findViewById(R.id.fm_more);

        icon.setImageResource(e.directory ? R.drawable.ic_folder : R.drawable.ic_file);
        icon.setColorFilter(ContextCompat.getColor(mContext, e.directory ? R.color.fm_folder : R.color.fm_file));
        name.setText(e.name());

        String date = com.termux.shared.android.AppTimeZone.format(e.modified, "yyyy-MM-dd HH:mm");
        meta.setText(e.directory ? date : FileOps.humanSize(e.size) + "  •  " + date);

        boolean selected = mSelected.contains(e.path());
        row.setActivated(selected);
        check.setVisibility(selected ? View.VISIBLE : View.GONE);
        more.setVisibility(mSelectionMode ? View.INVISIBLE : View.VISIBLE);
        more.setOnClickListener(v -> mListener.onMoreClicked(e));
        return row;
    }
}
