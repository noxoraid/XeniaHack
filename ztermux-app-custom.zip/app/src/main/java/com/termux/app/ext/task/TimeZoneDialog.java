package com.termux.app.ext.task;

import android.content.Context;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.termux.R;
import com.termux.app.ext.ui.CustomDialogs;
import com.termux.shared.android.AppTimeZone;
import com.termux.shared.termux.shell.command.environment.TermuxShellEnvironment;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

/** One place to pick the time zone used by the whole app (UI, logs, tasks, new terminal sessions). */
public final class TimeZoneDialog {

    private static final String[][] ZONES = {
        {"", "Follow device"},
        {"Asia/Jakarta", "Indonesia · WIB (Jakarta)"},
        {"Asia/Makassar", "Indonesia · WITA (Makassar)"},
        {"Asia/Jayapura", "Indonesia · WIT (Jayapura)"},
        {"Asia/Singapore", "Singapore"},
        {"Asia/Kuala_Lumpur", "Malaysia"},
        {"Asia/Bangkok", "Thailand"},
        {"Asia/Manila", "Philippines"},
        {"Asia/Shanghai", "China (Shanghai)"},
        {"Asia/Hong_Kong", "Hong Kong"},
        {"Asia/Tokyo", "Japan"},
        {"Asia/Seoul", "South Korea"},
        {"Asia/Kolkata", "India"},
        {"Asia/Dubai", "UAE (Dubai)"},
        {"Asia/Riyadh", "Saudi Arabia"},
        {"Europe/Istanbul", "Turkey"},
        {"Europe/Moscow", "Russia (Moscow)"},
        {"Europe/London", "United Kingdom (London)"},
        {"Europe/Paris", "France (Paris)"},
        {"Europe/Berlin", "Germany (Berlin)"},
        {"Africa/Cairo", "Egypt (Cairo)"},
        {"Africa/Lagos", "Nigeria (Lagos)"},
        {"America/New_York", "USA · Eastern (New York)"},
        {"America/Chicago", "USA · Central (Chicago)"},
        {"America/Denver", "USA · Mountain (Denver)"},
        {"America/Los_Angeles", "USA · Pacific (Los Angeles)"},
        {"America/Sao_Paulo", "Brazil (São Paulo)"},
        {"Australia/Sydney", "Australia (Sydney)"},
        {"Pacific/Auckland", "New Zealand (Auckland)"},
        {"UTC", "UTC"},
    };

    private TimeZoneDialog() {}

    @NonNull
    public static String describe() {
        String id = AppTimeZone.id();
        return (id.isEmpty() ? "Device" : id) + " · " + AppTimeZone.shortName() + " " + offset(AppTimeZone.zone());
    }

    private static String offset(TimeZone zone) {
        int minutes = zone.getOffset(System.currentTimeMillis()) / 60000;
        String sign = minutes < 0 ? "-" : "+";
        minutes = Math.abs(minutes);
        return "UTC" + sign + minutes / 60 + (minutes % 60 == 0 ? "" : ":" + String.format("%02d", minutes % 60));
    }

    public static void show(@NonNull Context context, @NonNull Runnable onChanged) {
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
        for (String[] z : ZONES) {
            String label = z[1] + (z[0].isEmpty() ? "" : "  ·  " + offset(TimeZone.getTimeZone(z[0])));
            if (z[0].equals(AppTimeZone.id())) label = "✓ " + label;
            entries.add(new CustomDialogs.MenuEntry(label, R.drawable.ic_info_outline_black_24dp));
        }
        entries.add(new CustomDialogs.MenuEntry("Other… (type a zone id)", R.drawable.ic_info_outline_black_24dp));
        CustomDialogs.menu(context, true, "Time zone", entries, index -> {
            if (index < ZONES.length) apply(context, ZONES[index][0], onChanged);
            else CustomDialogs.input(context, true, "Time zone id", "e.g. Europe/Madrid, America/Toronto, Asia/Karachi",
                AppTimeZone.id(), "Set", text -> {
                    String id = text.trim();
                    if (id.isEmpty() || !AppTimeZone.isValid(id)) {
                        Toast.makeText(context, "Unknown time zone id", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    apply(context, id, onChanged);
                });
        });
    }

    private static void apply(Context context, String id, Runnable onChanged) {
        AppTimeZone.set(context, id);
        try {
            TermuxShellEnvironment.writeEnvironmentToFile(context);
        } catch (RuntimeException ignored) {
            // environment file is refreshed on next app start anyway
        }
        Toast.makeText(context, "Time zone: " + describe() + ". New terminal sessions use it too.", Toast.LENGTH_LONG).show();
        onChanged.run();
    }
}
