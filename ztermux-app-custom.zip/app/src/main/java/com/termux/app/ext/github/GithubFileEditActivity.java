package com.termux.app.ext.github;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.termux.R;
import com.termux.app.ext.editor.CodeEditText;
import com.termux.app.ext.mascot.MascotEvents;
import com.termux.app.ext.mascot.MascotWidget;
import com.termux.app.ext.ui.CustomDialogs;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GithubFileEditActivity extends AppCompatActivity {

    public static final String EXTRA_REPO = "com.termux.app.ext.github.EXTRA_EDIT_REPO";
    public static final String EXTRA_BRANCH = "com.termux.app.ext.github.EXTRA_EDIT_BRANCH";
    public static final String EXTRA_PATH = "com.termux.app.ext.github.EXTRA_EDIT_PATH";
    public static final String EXTRA_SHA = "com.termux.app.ext.github.EXTRA_EDIT_SHA";

    private final ExecutorService mIo = Executors.newSingleThreadExecutor();

    private CodeEditText mText;
    private TextView mTitle;
    private MascotWidget mMascot;
    private GithubCommitWriter mWriter;
    private String mBranch, mPath, mSha, mName;
    private boolean mLoaded, mDirty, mSaving;

    @NonNull
    public static Intent intentFor(@NonNull Context context, @NonNull String repo, @NonNull String branch,
                                   @NonNull String path, @NonNull String sha) {
        Intent intent = new Intent(context, GithubFileEditActivity.class);
        intent.putExtra(EXTRA_REPO, repo);
        intent.putExtra(EXTRA_BRANCH, branch);
        intent.putExtra(EXTRA_PATH, path);
        intent.putExtra(EXTRA_SHA, sha);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        String repo = getIntent().getStringExtra(EXTRA_REPO);
        mBranch = getIntent().getStringExtra(EXTRA_BRANCH);
        mPath = getIntent().getStringExtra(EXTRA_PATH);
        mSha = getIntent().getStringExtra(EXTRA_SHA);
        String token = new GithubLinkStore(this).token();
        if (repo == null || mBranch == null || mPath == null || mSha == null || token.isEmpty()) { finish(); return; }
        mName = mPath.substring(mPath.lastIndexOf('/') + 1);
        mWriter = new GithubCommitWriter(new GithubRestClient(token), repo);

        mText = findViewById(R.id.ed_text);
        mTitle = findViewById(R.id.ed_title);
        mMascot = findViewById(R.id.ed_mascot);
        mMascot.setRoamingEnabled(false);
        mTitle.setText(mName);
        ((TextView) findViewById(R.id.ed_subtitle)).setText(repo + " · " + mBranch + " · " + mPath);

        findViewById(R.id.ed_back).setOnClickListener(v -> onBackPressed());
        findViewById(R.id.ed_btn_paste).setOnClickListener(v -> paste());
        findViewById(R.id.ed_btn_clear).setOnClickListener(v -> clearAll());
        findViewById(R.id.ed_btn_select_all).setOnClickListener(v -> { mText.requestFocus(); mText.selectAll(); });
        findViewById(R.id.ed_btn_copy).setOnClickListener(v -> copy());
        findViewById(R.id.ed_btn_save).setOnClickListener(v -> save(false));

        mText.setEnabled(false);
        mText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (mLoaded && !mDirty) { mDirty = true; refreshTitle(); }
            }
        });

        load();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mIo.shutdownNow();
    }

    private void refreshTitle() {
        mTitle.setText((mDirty ? "● " : "") + mName);
    }

    private void load() {
        mIo.execute(() -> {
            try {
                byte[] data = mWriter.readBlob(mSha);
                for (int i = 0; i < Math.min(data.length, 8000); i++) {
                    if (data[i] == 0) throw new IOException("This looks like a binary file");
                }
                final String content = new String(data, StandardCharsets.UTF_8);
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    mText.setText(content);
                    mText.setEnabled(true);
                    mLoaded = true;
                    mDirty = false;
                    refreshTitle();
                });
            } catch (IOException e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Cannot open file: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    finish();
                });
            }
        });
    }

    private void paste() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm != null ? cm.getPrimaryClip() : null;
        if (clip == null || clip.getItemCount() == 0) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show();
            return;
        }
        CharSequence text = clip.getItemAt(0).coerceToText(this);
        if (text == null || text.length() == 0) return;
        int start = Math.max(0, Math.min(mText.getSelectionStart(), mText.getSelectionEnd()));
        int end = Math.max(0, Math.max(mText.getSelectionStart(), mText.getSelectionEnd()));
        mText.getText().replace(start, end, text);
        mText.requestFocus();
    }

    private void clearAll() {
        if (mText.length() == 0) return;
        CustomDialogs.confirm(this, true, "Clear all text?", "This empties the editor. You can still leave without saving.",
            getString(R.string.editor_clear), true, () -> mText.setText(""));
    }

    private void copy() {
        int s = mText.getSelectionStart(), e = mText.getSelectionEnd();
        int from = Math.min(s, e), to = Math.max(s, e);
        boolean hasSelection = from >= 0 && to > from;
        CharSequence toCopy = hasSelection ? mText.getText().subSequence(from, to) : mText.getText();
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null) return;
        cm.setPrimaryClip(ClipData.newPlainText(mName, toCopy));
        Toast.makeText(this, hasSelection ? "Selection copied" : "All text copied", Toast.LENGTH_SHORT).show();
    }

    private void save(boolean closeAfter) {
        if (!mLoaded || mSaving) return;
        mSaving = true;
        final byte[] bytes = mText.getText().toString().getBytes(StandardCharsets.UTF_8);
        mIo.execute(() -> {
            try {
                String newSha = mWriter.putFile(mBranch, mPath, bytes, mSha, "Update " + mName);
                runOnUiThread(() -> {
                    mSaving = false;
                    if (!newSha.isEmpty()) mSha = newSha;
                    mDirty = false;
                    refreshTitle();
                    MascotEvents.postPending(MascotEvents.Event.FILE_SAVED);
                    mMascot.react(MascotEvents.Event.FILE_SAVED);
                    if (closeAfter) finish();
                });
            } catch (IOException e) {
                runOnUiThread(() -> {
                    mSaving = false;
                    mMascot.react(MascotEvents.Event.ERROR);
                    Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!mDirty) { super.onBackPressed(); return; }
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        View focus = getCurrentFocus();
        if (imm != null && focus != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
        entries.add(new CustomDialogs.MenuEntry("Save and close", R.drawable.ic_save));
        entries.add(new CustomDialogs.MenuEntry("Discard changes", R.drawable.ic_delete, true));
        CustomDialogs.menu(this, true, "Unsaved changes", entries, index -> {
            if (index == 0) save(true); else finish();
        });
    }
}
