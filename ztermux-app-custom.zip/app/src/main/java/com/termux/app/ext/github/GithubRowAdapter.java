package com.termux.app.ext.github;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.termux.R;

import java.util.ArrayList;
import java.util.List;

public final class GithubRowAdapter extends BaseAdapter {

    public static final class Row {
        public final String title;
        public final String detail;
        @DrawableRes public final int icon;
        @ColorRes public final int tint;
        public final Object tag;
        public final boolean hasMenu;

        public Row(String title, String detail, @DrawableRes int icon, @ColorRes int tint, Object tag, boolean hasMenu) {
            this.title = title;
            this.detail = detail;
            this.icon = icon;
            this.tint = tint;
            this.tag = tag;
            this.hasMenu = hasMenu;
        }
    }

    public interface Listener {
        void onRowClicked(@NonNull Row row);
        void onRowMenu(@NonNull Row row);
    }

    private final Context mContext;
    private final LayoutInflater mInflater;
    private final Listener mListener;
    private final List<Row> mRows = new ArrayList<>();

    public GithubRowAdapter(@NonNull Context context, @NonNull Listener listener) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
        mListener = listener;
    }

    public void setRows(@NonNull List<Row> rows) {
        mRows.clear();
        mRows.addAll(rows);
        notifyDataSetChanged();
    }

    @Override public int getCount() { return mRows.size(); }
    @Override public Row getItem(int position) { return mRows.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView != null ? convertView : mInflater.inflate(R.layout.item_file_entry, parent, false);
        final Row row = getItem(position);
        ImageView icon = view.findViewById(R.id.fm_icon);
        TextView title = view.findViewById(R.id.fm_name);
        TextView detail = view.findViewById(R.id.fm_meta);
        ImageButton menu = view.findViewById(R.id.fm_more);
        view.findViewById(R.id.fm_check).setVisibility(View.GONE);
        icon.setImageResource(row.icon);
        icon.setColorFilter(ContextCompat.getColor(mContext, row.tint));
        title.setText(row.title);
        detail.setText(row.detail);
        menu.setVisibility(row.hasMenu ? View.VISIBLE : View.INVISIBLE);
        menu.setOnClickListener(v -> mListener.onRowMenu(row));
        view.setOnClickListener(v -> mListener.onRowClicked(row));
        view.setOnLongClickListener(v -> {
            if (row.hasMenu) mListener.onRowMenu(row);
            return row.hasMenu;
        });
        return view;
    }
}
