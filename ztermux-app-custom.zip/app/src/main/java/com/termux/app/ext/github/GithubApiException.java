package com.termux.app.ext.github;

import java.io.IOException;

public final class GithubApiException extends IOException {

    public final int status;

    public GithubApiException(int status, String message) {
        super(message);
        this.status = status;
    }
}
