package com.termux.app.ext.github;

import androidx.annotation.NonNull;

import java.util.Locale;

/** Reads git/pkg output and says what kind of problem it is. */
public final class GitErrorDoctor {

    public enum Kind {
        BROKEN_BINARY, DUBIOUS_OWNERSHIP, INDEX_LOCK, DPKG_INTERRUPTED, PKG_LOCK, PKG_MIRROR,
        BIG_FILE, SECRET_BLOCKED, PROTECTED_BRANCH, NO_IDENTITY, NOT_A_REPO, UNRELATED_HISTORIES,
        MERGE_CONFLICT, UNFINISHED_MERGE, NO_COMMITS, NON_FAST_FORWARD, SSL_CERT, AUTH_FAILED,
        NO_REMOTE, REPO_NOT_FOUND, REMOTE_EXISTS, BIG_PUSH, NETWORK, FS_PERMS, STORAGE_DENIED, GPG, UNKNOWN
    }

    private GitErrorDoctor() {}

    private static boolean has(String text, String... needles) {
        for (String needle : needles) if (text.contains(needle)) return true;
        return false;
    }

    @NonNull
    public static Kind diagnose(@NonNull String raw) {
        String t = raw.toLowerCase(Locale.ROOT);
        if (has(t, "cannot link executable", "cannot locate symbol", "error while loading shared libraries", "library \"lib", "remote helper 'https' aborted")) return Kind.BROKEN_BINARY;
        if (has(t, "dubious ownership", "add safe.directory", "unsafe repository")) return Kind.DUBIOUS_OWNERSHIP;
        if (t.contains(".lock") && has(t, "file exists", "another git process")) return Kind.INDEX_LOCK;
        if (has(t, "dpkg was interrupted", "dpkg --configure -a")) return Kind.DPKG_INTERRUPTED;
        if (has(t, "could not get lock", "unable to acquire the dpkg")) return Kind.PKG_LOCK;
        if (has(t, "unable to locate package", "failed to fetch", "temporary failure resolving", "release file", "is not signed")) return Kind.PKG_MIRROR;
        if (has(t, "gh001", "exceeds github's file size limit", "large files detected")) return Kind.BIG_FILE;
        if (has(t, "gh013", "push cannot contain secrets", "secret scanning")) return Kind.SECRET_BLOCKED;
        if (has(t, "gh006", "protected branch")) return Kind.PROTECTED_BRANCH;
        if (has(t, "please tell me who you are", "unable to auto-detect email", "empty ident name", "user.useconfigonly")) return Kind.NO_IDENTITY;
        if (has(t, "gpg failed to sign", "signing failed")) return Kind.GPG;
        if (has(t, "not a git repository") && !has(t, "does not appear")) return Kind.NOT_A_REPO;
        if (has(t, "refusing to merge unrelated histories")) return Kind.UNRELATED_HISTORIES;
        if (has(t, "conflict (", "automatic merge failed", "fix conflicts")) return Kind.MERGE_CONFLICT;
        if (has(t, "not concluded your merge", "merge_head exists", "unmerged files", "unfinished merge", "rebase in progress", "you need to resolve your current index")) return Kind.UNFINISHED_MERGE;
        if (has(t, "src refspec", "does not have any commits yet", "unborn", "bad revision 'head'", "ambiguous argument 'head'")) return Kind.NO_COMMITS;
        if (has(t, "[rejected]", "fetch first", "non-fast-forward", "updates were rejected", "tip of your current branch is behind")) return Kind.NON_FAST_FORWARD;
        if (has(t, "ssl certificate problem", "unable to get local issuer", "server certificate verification failed", "cafile")) return Kind.SSL_CERT;
        if (has(t, "authentication failed", "invalid username", "could not read username", "could not read password", "terminal prompts disabled", "bad credentials", "permission denied (publickey)", "host key verification failed", "error: 403", "error: 401", "write access to repository not granted", "password authentication was removed")) return Kind.AUTH_FAILED;
        if (has(t, "'origin' does not appear", "no such remote", "no configured push destination", "no remote repository specified")) return Kind.NO_REMOTE;
        if (has(t, "repository not found", "error: 404", "does not appear to be a git repository", "could not read from remote repository")) return Kind.REPO_NOT_FOUND;
        if (has(t, "remote origin already exists")) return Kind.REMOTE_EXISTS;
        if (has(t, "rpc failed", "http 400", "http 413", "hung up unexpectedly", "unexpected disconnect", "curl 55", "curl 56", "curl 92", "curl 18", "pack-objects died")) return Kind.BIG_PUSH;
        if (has(t, "could not resolve host", "failed to connect", "timed out", "network is unreachable", "connection reset", "early eof", "transfer closed", "couldn't connect", "connection refused", "no route to host", "temporary failure in name resolution")) return Kind.NETWORK;
        if (has(t, "operation not permitted", "chmod on", "unable to set permissions", "symlink")) return Kind.FS_PERMS;
        if (has(t, "read-only file system", "permission denied", "unable to unlink", "unable to write")) return Kind.STORAGE_DENIED;
        return Kind.UNKNOWN;
    }

    public static int maxTries(@NonNull Kind kind) {
        switch (kind) {
            case NON_FAST_FORWARD: case NETWORK: case PKG_LOCK: return 3;
            case DUBIOUS_OWNERSHIP: case BROKEN_BINARY: case BIG_PUSH: case AUTH_FAILED: case FS_PERMS: return 2;
            case UNKNOWN: case STORAGE_DENIED: case SECRET_BLOCKED: case PROTECTED_BRANCH: return 0;
            default: return 2;
        }
    }

    @NonNull
    public static String title(@NonNull Kind kind) {
        switch (kind) {
            case BROKEN_BINARY: return "git or libcurl in Termux is out of sync";
            case DUBIOUS_OWNERSHIP: return "git does not trust this folder (safe.directory)";
            case INDEX_LOCK: return "A stale git lock file is blocking";
            case DPKG_INTERRUPTED: return "A previous package install was interrupted";
            case PKG_LOCK: return "Another package manager is running";
            case PKG_MIRROR: return "Termux package mirror problem";
            case BIG_FILE: return "A file is over GitHub's 100 MB limit";
            case SECRET_BLOCKED: return "GitHub blocked a secret inside your files";
            case PROTECTED_BRANCH: return "The branch is protected on GitHub";
            case NO_IDENTITY: return "git does not know your name/email";
            case NOT_A_REPO: return "This folder is not a git repository yet";
            case UNRELATED_HISTORIES: return "Local and GitHub histories are unrelated";
            case MERGE_CONFLICT: return "Merge conflict with GitHub";
            case UNFINISHED_MERGE: return "An unfinished merge/rebase is in the way";
            case NO_COMMITS: return "There is no commit to push yet";
            case NON_FAST_FORWARD: return "GitHub has commits you do not have locally";
            case SSL_CERT: return "SSL certificate problem";
            case AUTH_FAILED: return "GitHub rejected the login";
            case NO_REMOTE: return "No GitHub remote is linked";
            case REPO_NOT_FOUND: return "GitHub repository not found";
            case REMOTE_EXISTS: return "Remote origin already exists";
            case BIG_PUSH: return "The push was cut off (too big / unstable connection)";
            case NETWORK: return "Network problem while talking to GitHub";
            case FS_PERMS: return "This storage does not allow file modes/symlinks";
            case STORAGE_DENIED: return "Android blocked writing in this folder";
            case GPG: return "Commit signing failed";
            default: return "Unrecognised git error";
        }
    }
}
