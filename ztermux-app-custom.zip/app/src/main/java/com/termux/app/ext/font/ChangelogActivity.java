package com.termux.app.ext.font;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.termux.R;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import io.noties.markwon.Markwon;

/** Shows {@code assets/CHANGELOG.md}. Every update adds an entry to that file. */
public class ChangelogActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changelog);
        findViewById(R.id.cl_back).setOnClickListener(v -> finish());

        TextView text = findViewById(R.id.cl_text);
        String md;
        try (InputStream in = getAssets().open("CHANGELOG.md"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            md = new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            md = "Changelog not available.";
        }
        Markwon.create(this).setMarkdown(text, md);
    }
}
