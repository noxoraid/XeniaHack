package com.termux.app.ext.task;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.termux.shared.android.AppTimeZone;

import java.util.ArrayList;
import java.util.List;

/** The "Task" tab: every background job, with details and a Go-to button. Used in the File Manager and in TaskActivity. */
public final class TaskPanel extends LinearLayout implements TaskCenter.Listener {

    private static final int TEXT = 0xFF17181C, DIM = 0xFF6B7280, LINE = 0xFFE5E7EB, SURFACE = 0xFFFFFFFF, CHIP = 0xFFF1F2F5;

    private final Handler mTick = new Handler(Looper.getMainLooper());
    private final Adapter mAdapter = new Adapter();
    private final TextView mZone;
    private final TextView mEmpty;
    private List<TaskCenter.TaskItem> mItems = new ArrayList<>();

    private final Runnable mTicker = new Runnable() {
        @Override public void run() {
            if (TaskCenter.runningCount() > 0) mAdapter.notifyDataSetChanged();
            mTick.postDelayed(this, 1000);
        }
    };

    public TaskPanel(@NonNull Context context) {
        super(context);
        setOrientation(VERTICAL);
        setBackgroundColor(SURFACE);

        LinearLayout header = new LinearLayout(context);
        header.setOrientation(HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(10), dp(14), dp(10));
        mZone = chip("");
        mZone.setOnClickListener(v -> TimeZoneDialog.show(getContext(), this::refresh));
        header.addView(mZone, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView clear = chip("Clear finished");
        clear.setOnClickListener(v -> TaskCenter.clearFinished());
        LayoutParams cp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.leftMargin = dp(8);
        header.addView(clear, cp);
        addView(header, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        android.widget.FrameLayout body = new android.widget.FrameLayout(context);
        ListView list = new ListView(context);
        list.setDivider(new android.graphics.drawable.ColorDrawable(LINE));
        list.setDividerHeight(1);
        list.setAdapter(mAdapter);
        list.setDescendantFocusability(FOCUS_BLOCK_DESCENDANTS);
        body.addView(list, new android.widget.FrameLayout.LayoutParams(-1, -1));
        mEmpty = new TextView(context);
        mEmpty.setText("No tasks yet.\nDownloads, uploads and file jobs show up here and keep running when you leave.");
        mEmpty.setTextColor(DIM);
        mEmpty.setGravity(Gravity.CENTER);
        mEmpty.setPadding(dp(32), 0, dp(32), 0);
        body.addView(mEmpty, new android.widget.FrameLayout.LayoutParams(-1, -1));
        addView(body, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        refresh();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView chip(String text) {
        TextView t = new TextView(getContext());
        t.setText(text);
        t.setTextSize(12.5f);
        t.setTextColor(TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CHIP);
        bg.setCornerRadius(dp(14));
        t.setBackground(bg);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return t;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        TaskCenter.addListener(this);
        refresh();
        mTick.postDelayed(mTicker, 1000);
    }

    @Override
    protected void onDetachedFromWindow() {
        TaskCenter.removeListener(this);
        mTick.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    @Override
    public void onTasksChanged() { refresh(); }

    private void refresh() {
        mItems = TaskCenter.snapshot();
        mZone.setText("🕒 " + TimeZoneDialog.describe());
        mEmpty.setVisibility(mItems.isEmpty() ? VISIBLE : GONE);
        mAdapter.notifyDataSetChanged();
    }

    // ------------------------------------------------------------------ rows

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return mItems.size(); }
        @Override public Object getItem(int i) { return mItems.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int position, View convert, ViewGroup parent) {
            final TaskCenter.TaskItem item = mItems.get(position);
            Context c = getContext();
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(VERTICAL);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));

            LinearLayout top = new LinearLayout(c);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView title = new TextView(c);
            title.setText(item.title);
            title.setTextColor(TEXT);
            title.setTextSize(15f);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setMaxLines(2);
            top.addView(title, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView state = new TextView(c);
            state.setText(stateLabel(item));
            state.setTextColor(stateColor(item));
            state.setTextSize(12f);
            state.setTypeface(Typeface.DEFAULT_BOLD);
            top.addView(state);
            row.addView(top);

            TextView status = new TextView(c);
            status.setText(item.status);
            status.setTextColor(DIM);
            status.setTextSize(13f);
            status.setMaxLines(2);
            status.setPadding(0, dp(3), 0, 0);
            row.addView(status);

            if (item.running()) {
                ProgressBar bar = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
                bar.setIndeterminate(item.percent < 0);
                bar.setMax(100);
                bar.setProgress(Math.max(0, item.percent));
                LayoutParams bp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6));
                bp.topMargin = dp(8);
                row.addView(bar, bp);
            }

            TextView meta = new TextView(c);
            meta.setText(meta(item));
            meta.setTextColor(DIM);
            meta.setTextSize(11.5f);
            meta.setPadding(0, dp(6), 0, dp(8));
            row.addView(meta);

            LinearLayout buttons = new LinearLayout(c);
            TextView details = chip("Details");
            details.setOnClickListener(v -> showDetails(item));
            buttons.addView(details);
            if (item.gotoUri != null) {
                TextView go = chip("Go to  ➜");
                go.setOnClickListener(v -> goTo(item));
                LayoutParams gp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                gp.leftMargin = dp(8);
                buttons.addView(go, gp);
            }
            if (item.running() && item.cancellable) {
                TextView cancel = chip("Cancel");
                cancel.setOnClickListener(v -> TaskCenter.cancel(item));
                LayoutParams xp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                xp.leftMargin = dp(8);
                buttons.addView(cancel, xp);
            } else if (!item.running()) {
                TextView remove = chip("Remove");
                remove.setOnClickListener(v -> TaskCenter.remove(item));
                LayoutParams rp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rp.leftMargin = dp(8);
                buttons.addView(remove, rp);
            }
            row.addView(buttons);
            return row;
        }
    }

    private static String stateLabel(TaskCenter.TaskItem item) {
        switch (item.state) {
            case RUNNING: return item.percent >= 0 ? "RUNNING " + item.percent + "%" : "RUNNING";
            case DONE: return "DONE";
            case FAILED: return "FAILED";
            case CANCELLED: return "CANCELLED";
            case NEEDS_ACTION: return "NEEDS ACTION";
            default: return "STOPPED";
        }
    }

    private static int stateColor(TaskCenter.TaskItem item) {
        switch (item.state) {
            case RUNNING: return 0xFF2F6BFF;
            case DONE: return 0xFF1E9E5A;
            case FAILED: return 0xFFD93025;
            case NEEDS_ACTION: return 0xFFE08A00;
            default: return 0xFF6B7280;
        }
    }

    private static String meta(TaskCenter.TaskItem item) {
        String start = AppTimeZone.format(item.startedAt, "dd MMM HH:mm:ss") + " " + AppTimeZone.shortName();
        long end = item.running() ? System.currentTimeMillis() : item.finishedAt;
        long secs = Math.max(0, (end - item.startedAt) / 1000);
        String took = secs >= 60 ? (secs / 60) + "m " + (secs % 60) + "s" : secs + "s";
        return "Started " + start + "  ·  " + (item.running() ? "running " : "took ") + took;
    }

    private void goTo(TaskCenter.TaskItem item) {
        try {
            Intent intent = Intent.parseUri(item.gotoUri, Intent.URI_INTENT_SCHEME);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getContext(), "Cannot open that screen anymore", Toast.LENGTH_SHORT).show();
        }
    }

    private void showDetails(TaskCenter.TaskItem item) {
        Context c = getContext();
        ScrollView scroll = new ScrollView(c);
        TextView text = new TextView(c);
        String log = item.logText();
        text.setText(item.title + "\n" + stateLabel(item) + " · " + item.status + "\n" + meta(item) + "\n\n"
            + (log.isEmpty() ? "(no log lines)" : log));
        text.setTypeface(Typeface.MONOSPACE);
        text.setTextSize(11.5f);
        text.setTextColor(TEXT);
        text.setTextIsSelectable(true);
        text.setPadding(dp(18), dp(12), dp(18), dp(6));
        scroll.addView(text);
        AlertDialog.Builder b = new AlertDialog.Builder(c).setTitle("Task details").setView(scroll)
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy", (d, w) -> {
                ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("task", text.getText()));
                Toast.makeText(c, "Copied", Toast.LENGTH_SHORT).show();
            });
        if (item.gotoUri != null) b.setNegativeButton("Go to", (d, w) -> goTo(item));
        b.show();
    }
}
