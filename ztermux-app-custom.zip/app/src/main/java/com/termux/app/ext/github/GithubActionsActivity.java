package com.termux.app.ext.github;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.termux.R;
import com.termux.app.ext.filemanager.FileOps;
import com.termux.app.ext.filemanager.StorageAccess;
import com.termux.app.ext.task.TaskCenter;
import com.termux.app.ext.ui.CustomDialogs;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GithubActionsActivity extends AppCompatActivity implements GithubRowAdapter.Listener {

    public static final String EXTRA_REPO = "com.termux.app.ext.github.EXTRA_ACTIONS_REPO";
    public static final String EXTRA_BRANCH = "com.termux.app.ext.github.EXTRA_ACTIONS_BRANCH";

    private static final class RunEntry {
        final long id;
        final int number;

        RunEntry(long id, int number) {
            this.id = id;
            this.number = number;
        }
    }

    private final ExecutorService mIo = Executors.newSingleThreadExecutor();

    private String mRepo;
    private String mBranchFilter;
    private GithubRestClient mClient;
    private GithubRowAdapter mAdapter;
    private TextView mBranchChip, mEmpty;
    private View mLoading;

    @NonNull
    public static Intent intentFor(@NonNull Context context, @NonNull String repo, @NonNull String branch) {
        Intent intent = new Intent(context, GithubActionsActivity.class);
        intent.putExtra(EXTRA_REPO, repo);
        intent.putExtra(EXTRA_BRANCH, branch);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_github_actions);

        mRepo = getIntent().getStringExtra(EXTRA_REPO);
        mBranchFilter = getIntent().getStringExtra(EXTRA_BRANCH);
        String token = new GithubLinkStore(this).token();
        if (mRepo == null || token.isEmpty()) { finish(); return; }
        mClient = new GithubRestClient(token);

        mBranchChip = findViewById(R.id.ga_branch);
        mEmpty = findViewById(R.id.ga_empty);
        mLoading = findViewById(R.id.ga_loading);
        ((TextView) findViewById(R.id.ga_title)).setText("Actions · " + mRepo);

        mAdapter = new GithubRowAdapter(this, this);
        ListView list = findViewById(R.id.ga_list);
        list.setAdapter(mAdapter);

        findViewById(R.id.ga_back).setOnClickListener(v -> finish());
        findViewById(R.id.ga_refresh).setOnClickListener(v -> loadRuns());
        mBranchChip.setOnClickListener(v -> pickBranch());
        loadRuns();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mIo.shutdownNow();
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    private void loadRuns() {
        mBranchChip.setText("Branch: " + (mBranchFilter == null ? "all" : mBranchFilter) + "  ▾");
        mLoading.setVisibility(View.VISIBLE);
        mEmpty.setVisibility(View.GONE);
        final String filter = mBranchFilter;
        mIo.execute(() -> {
            List<GithubRowAdapter.Row> rows = new ArrayList<>();
            String problem = null;
            try {
                String query = "/repos/" + mRepo + "/actions/runs?per_page=30"
                    + (filter == null ? "" : "&branch=" + GithubRestClient.encodeSegment(filter));
                JSONArray runs = mClient.getObject(query).optJSONArray("workflow_runs");
                for (int i = 0; runs != null && i < runs.length(); i++) {
                    JSONObject run = runs.optJSONObject(i);
                    if (run != null) rows.add(rowFor(run));
                }
            } catch (IOException e) {
                problem = e.getMessage();
            }
            final String error = problem;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                mLoading.setVisibility(View.GONE);
                if (error != null) toast(error);
                mAdapter.setRows(rows);
                mEmpty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
            });
        });
    }

    @NonNull
    private GithubRowAdapter.Row rowFor(@NonNull JSONObject run) {
        String status = run.optString("status");
        String conclusion = run.optString("conclusion", "");
        boolean finished = "completed".equals(status);
        String state = finished ? conclusion : status;
        int icon = R.drawable.ic_sync;
        int tint = R.color.gh_wait;
        if (finished && "success".equals(conclusion)) { icon = R.drawable.ic_check; tint = R.color.gh_ok; }
        else if (finished && "failure".equals(conclusion)) { icon = R.drawable.ic_close; tint = R.color.gh_fail; }
        else if (finished) { icon = R.drawable.ic_file; tint = R.color.fm_file; }
        String title = run.optString("display_title", run.optString("name"));
        String created = run.optString("created_at").replace("T", " ").replace("Z", "");
        String detail = "#" + run.optInt("run_number") + "  •  " + run.optString("head_branch") + "  •  " + state + "  •  " + created;
        return new GithubRowAdapter.Row(title, detail, icon, tint, new RunEntry(run.optLong("id"), run.optInt("run_number")), true);
    }

    @Override
    public void onRowClicked(@NonNull GithubRowAdapter.Row row) {
        onRowMenu(row);
    }

    @Override
    public void onRowMenu(@NonNull GithubRowAdapter.Row row) {
        final RunEntry run = (RunEntry) row.tag;
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
        entries.add(new CustomDialogs.MenuEntry("View full log", R.drawable.ic_file));
        entries.add(new CustomDialogs.MenuEntry("View errors only", R.drawable.ic_close));
        entries.add(new CustomDialogs.MenuEntry("Artifacts", R.drawable.ic_save));
        CustomDialogs.menu(this, true, "Run #" + run.number, entries, index -> {
            if (index == 2) loadArtifacts(run);
            else startActivity(GithubLogActivity.intentFor(this, mRepo, run.id, run.number, index == 1));
        });
    }

    private void pickBranch() {
        mLoading.setVisibility(View.VISIBLE);
        mIo.execute(() -> {
            final List<String> names = new ArrayList<>();
            String problem = null;
            try {
                JSONArray branches = mClient.getArray("/repos/" + mRepo + "/branches?per_page=100");
                for (int i = 0; i < branches.length(); i++) {
                    JSONObject branch = branches.optJSONObject(i);
                    if (branch != null) names.add(branch.optString("name"));
                }
            } catch (IOException e) {
                problem = e.getMessage();
            }
            final String error = problem;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                mLoading.setVisibility(View.GONE);
                if (error != null) { toast(error); return; }
                List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
                entries.add(new CustomDialogs.MenuEntry("All branches", R.drawable.ic_select_all));
                for (String name : names) entries.add(new CustomDialogs.MenuEntry(name, R.drawable.ic_folder));
                CustomDialogs.menu(this, true, "Branch", entries, index -> {
                    mBranchFilter = index == 0 ? null : names.get(index - 1);
                    loadRuns();
                });
            });
        });
    }

    private void loadArtifacts(@NonNull RunEntry run) {
        mLoading.setVisibility(View.VISIBLE);
        mIo.execute(() -> {
            final List<JSONObject> found = new ArrayList<>();
            String problem = null;
            try {
                JSONArray artifacts = mClient.getObject("/repos/" + mRepo + "/actions/runs/" + run.id + "/artifacts").optJSONArray("artifacts");
                for (int i = 0; artifacts != null && i < artifacts.length(); i++) {
                    JSONObject artifact = artifacts.optJSONObject(i);
                    if (artifact != null) found.add(artifact);
                }
            } catch (IOException e) {
                problem = e.getMessage();
            }
            final String error = problem;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                mLoading.setVisibility(View.GONE);
                if (error != null) { toast(error); return; }
                if (found.isEmpty()) { toast("This run has no artifacts"); return; }
                List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
                for (JSONObject artifact : found) {
                    String label = artifact.optString("name") + "  ·  " + FileOps.humanSize(artifact.optLong("size_in_bytes"))
                        + (artifact.optBoolean("expired") ? "  (expired)" : "");
                    entries.add(new CustomDialogs.MenuEntry(label, R.drawable.ic_save));
                }
                CustomDialogs.menu(this, true, "Download to Download folder", entries, index -> download(found.get(index), run));
            });
        });
    }

    private void download(@NonNull JSONObject artifact, @NonNull RunEntry run) {
        if (artifact.optBoolean("expired")) { toast("This artifact has expired"); return; }
        if (!StorageAccess.hasExternalAccess(this)) {
            toast("Allow all files access, then try again");
            StorageAccess.requestExternalAccess(this);
            return;
        }
        final long id = artifact.optLong("id");
        final String name = artifact.optString("name", "artifact");
        final long total = artifact.optLong("size_in_bytes");
        final String repo = mRepo;
        final GithubRestClient client = mClient;
        final String fileName = name + "-run" + run.number + ".zip";
        Toast.makeText(this, "Downloading " + name + "… (see the Task tab)", Toast.LENGTH_SHORT).show();
        // Runs as a background Task so it survives leaving this screen or closing the app.
        TaskCenter.submit(this, "download", "Download " + fileName,
            com.termux.app.ext.filemanager.FileManagerActivity.intentFor(this,
                android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)),
            true, handle -> {
                handle.log("Repo " + repo + " · artifact " + name + " (" + FileOps.humanSize(total) + ")");
                File saved = GithubDownloadFolder.saveStream(fileName,
                    client.openDownload("/repos/" + repo + "/actions/artifacts/" + id + "/zip"), total);
                handle.log("Saved to Download/" + saved.getName());
                handle.progress(100, "Saved to Download/" + saved.getName());
            }, item -> {
                if (!isFinishing()) toast(item.state == TaskCenter.State.DONE ? item.status : "Download " + item.state.name().toLowerCase());
            });
    }
}
