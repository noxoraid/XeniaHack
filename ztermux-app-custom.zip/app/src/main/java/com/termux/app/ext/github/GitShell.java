package com.termux.app.ext.github;

import android.content.Context;

import androidx.annotation.NonNull;

import com.termux.shared.termux.TermuxConstants;
import com.termux.shared.termux.shell.command.environment.TermuxShellEnvironment;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.List;
import java.util.Map;

public final class GitShell {

    public interface Sink {
        void line(@NonNull String text);
    }

    public static final class Outcome {
        public final int exitCode;
        public final String text;

        Outcome(int exitCode, String text) {
            this.exitCode = exitCode;
            this.text = text;
        }

        public boolean ok() {
            return exitCode == 0;
        }
    }

    private final Context mContext;
    private final File mWorkDir;
    private final String mSecret;

    public GitShell(@NonNull Context context, @NonNull File workDir, @NonNull String secretToHide) {
        mContext = context.getApplicationContext();
        mWorkDir = workDir;
        mSecret = secretToHide;
    }

    public static boolean isInstalled() {
        return new File(TermuxConstants.TERMUX_BIN_PREFIX_DIR_PATH, "git").canExecute();
    }

    @NonNull
    public Outcome git(Sink sink, @NonNull String... args) throws IOException {
        List<String> command = new ArrayList<>();
        command.add(TermuxConstants.TERMUX_BIN_PREFIX_DIR_PATH + "/git");
        command.add("-c");
        command.add("safe.directory=*");
        for (String arg : args) command.add(arg);
        return exec(command, sink);
    }

    /** Runs any Termux binary (apt-get, dpkg, pkg…). command[0] is looked up in $PREFIX/bin. */
    @NonNull
    public Outcome run(Sink sink, @NonNull String... command) throws IOException {
        List<String> full = new ArrayList<>();
        for (int i = 0; i < command.length; i++) {
            full.add(i == 0 && !command[0].startsWith("/") ? TermuxConstants.TERMUX_BIN_PREFIX_DIR_PATH + "/" + command[0] : command[i]);
        }
        return exec(full, sink);
    }

    @NonNull
    public File workDir() {
        return mWorkDir;
    }

    /** Same as running: git config --global --add safe.directory <folder> (done once, also for the real path). */
    public void ensureSafeDirectory() {
        try {
            String existing = capture("config", "--global", "--get-all", "safe.directory");
            Set<String> have = new LinkedHashSet<>();
            for (String line : existing.split("\n")) have.add(line.trim());
            Set<String> wanted = new LinkedHashSet<>();
            wanted.add(mWorkDir.getAbsolutePath());
            try { wanted.add(mWorkDir.getCanonicalPath()); } catch (IOException ignored) { }
            for (String path : wanted) {
                if (!have.contains(path)) git(null, "config", "--global", "--add", "safe.directory", path);
            }
        } catch (IOException ignored) {
            return;
        }
    }

    public void allowAllDirectories() {
        try {
            String existing = capture("config", "--global", "--get-all", "safe.directory");
            if (!existing.contains("*")) git(null, "config", "--global", "--add", "safe.directory", "*");
        } catch (IOException ignored) {
            return;
        }
    }

    /** Like capture() but never throws. */
    @NonNull
    public String capture0(@NonNull String... args) {
        try { return capture(args); } catch (IOException e) { return ""; }
    }

    @NonNull
    public String capture(@NonNull String... args) throws IOException {
        Outcome outcome = git(null, args);
        return outcome.ok() ? outcome.text.trim() : "";
    }

    private Outcome exec(List<String> command, Sink sink) throws IOException {
        ProcessBuilder builder = new ProcessBuilder(command).directory(mWorkDir).redirectErrorStream(true);
        Map<String, String> environment = builder.environment();
        environment.putAll(new TermuxShellEnvironment().getEnvironment(mContext, false));
        environment.put("GIT_TERMINAL_PROMPT", "0");
        environment.put("GIT_EDITOR", "true");
        environment.put("DEBIAN_FRONTEND", "noninteractive");
        environment.put("NO_COLOR", "1");
        Process process = builder.start();
        StringBuilder all = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String safe = hide(line);
                all.append(safe).append('\n');
                if (sink != null) sink.line(safe);
            }
        }
        try {
            return new Outcome(process.waitFor(), all.toString());
        } catch (InterruptedException e) {
            process.destroy();
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted");
        }
    }

    private String hide(String line) {
        String safe = line;
        if (!mSecret.isEmpty()) safe = safe.replace(mSecret, "***");
        return safe.replaceAll("https://[^@/\\s]+@", "https://***@");
    }
}
