package com.termux.app.ext.mascot;

import androidx.annotation.Nullable;

/**
 * Tiny in-process event hand-off so one screen (e.g. the editor) can make the mascot of another screen
 * (the terminal) react once that screen is visible again. Purely offline, no I/O.
 */
public final class MascotEvents {

    public enum Event {
        WELCOME, DRAWER_OPENED, DRAWER_CLOSED,
        SESSION_CREATED, SESSION_RENAMED, SESSION_CLOSED,
        FILE_SAVED, FILE_OPERATION_DONE, ERROR, TAPPED
    }

    @Nullable private static Event sPending;

    private MascotEvents() {}

    public static synchronized void postPending(Event event) { sPending = event; }

    @Nullable
    public static synchronized Event consumePending() {
        Event e = sPending;
        sPending = null;
        return e;
    }
}
