package com.termux.app.ext.github;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public final class GithubTreeSnapshot {

    public static final class Node {
        public final String path;
        public final String name;
        public final boolean directory;
        public final long size;
        public final String sha;
        public final String mode;

        Node(String path, boolean directory, long size, String sha, String mode) {
            this.path = path;
            this.name = path.substring(path.lastIndexOf('/') + 1);
            this.directory = directory;
            this.size = size;
            this.sha = sha;
            this.mode = mode;
        }
    }

    private final Map<String, Node> mNodes = new TreeMap<>();
    private final Map<String, Long> mFolderBytes = new HashMap<>();
    private final Map<String, Integer> mFolderFiles = new HashMap<>();
    private final boolean mTruncated;

    private GithubTreeSnapshot(@NonNull JSONObject root) {
        mTruncated = root.optBoolean("truncated", false);
        JSONArray tree = root.optJSONArray("tree");
        if (tree == null) return;
        for (int i = 0; i < tree.length(); i++) {
            JSONObject entry = tree.optJSONObject(i);
            if (entry == null) continue;
            String path = entry.optString("path");
            String type = entry.optString("type");
            if (path.isEmpty()) continue;
            boolean directory = "tree".equals(type);
            long size = entry.optLong("size", 0L);
            mNodes.put(path, new Node(path, directory, size, entry.optString("sha"), entry.optString("mode", "100644")));
            if (!directory) {
                String parent = parentOf(path);
                while (parent != null) {
                    mFolderBytes.put(parent, (mFolderBytes.containsKey(parent) ? mFolderBytes.get(parent) : 0L) + size);
                    mFolderFiles.put(parent, (mFolderFiles.containsKey(parent) ? mFolderFiles.get(parent) : 0) + 1);
                    parent = parentOf(parent);
                }
            }
        }
    }

    @NonNull
    public static GithubTreeSnapshot fetch(@NonNull GithubRestClient client, @NonNull String repo, @NonNull String branch) throws IOException {
        JSONObject root = client.getObject("/repos/" + repo + "/git/trees/" + GithubRestClient.encodeSegment(branch) + "?recursive=1");
        return new GithubTreeSnapshot(root);
    }

    @Nullable
    private static String parentOf(String path) {
        int slash = path.lastIndexOf('/');
        return slash < 0 ? null : path.substring(0, slash);
    }

    public boolean isTruncated() {
        return mTruncated;
    }

    @Nullable
    public Node get(@NonNull String path) {
        return mNodes.get(path);
    }

    public boolean exists(@NonNull String path) {
        return mNodes.containsKey(path);
    }

    public long folderBytes(@NonNull String path) {
        Long value = mFolderBytes.get(path);
        return value == null ? 0L : value;
    }

    public int folderFiles(@NonNull String path) {
        Integer value = mFolderFiles.get(path);
        return value == null ? 0 : value;
    }

    public long totalBytes() {
        long total = 0L;
        for (Node node : mNodes.values()) if (!node.directory) total += node.size;
        return total;
    }

    @NonNull
    public List<Node> children(@NonNull String directory) {
        List<Node> out = new ArrayList<>();
        for (Node node : mNodes.values()) {
            String parent = parentOf(node.path);
            if (directory.isEmpty() ? parent == null : directory.equals(parent)) out.add(node);
        }
        Collections.sort(out, (a, b) -> {
            if (a.directory != b.directory) return a.directory ? -1 : 1;
            return a.name.toLowerCase(Locale.ROOT).compareTo(b.name.toLowerCase(Locale.ROOT));
        });
        return out;
    }

    @NonNull
    public List<Node> blobsUnder(@NonNull String path) {
        List<Node> out = new ArrayList<>();
        for (Node node : mNodes.values()) {
            if (node.directory || "160000".equals(node.mode)) continue;
            if (node.path.equals(path) || node.path.startsWith(path + "/")) out.add(node);
        }
        return out;
    }
}
