package com.termux.app.ext.github;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.termux.R;
import com.termux.app.ext.diagnostics.TermuxErrorJournal;
import com.termux.app.ext.task.TaskCenter;
import com.termux.app.ext.filemanager.FileOps;
import com.termux.app.ext.ui.CustomDialogs;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GithubHubActivity extends AppCompatActivity {

    public static final String EXTRA_DIR = "com.termux.app.ext.github.EXTRA_DIR";

    private static final String EXCLUDE_BEGIN = "# noxora-excludes-begin";
    private static final String EXCLUDE_END = "# noxora-excludes-end";

    private interface Job {
        void run() throws IOException;
    }

    private final ExecutorService mIo = Executors.newSingleThreadExecutor();

    private File mDir;
    private GithubLinkStore mStore;
    private ScrollView mScroll;
    private TextView mTokenLine, mRepoLine, mConsole, mModeHint;
    private EditText mExcludes, mMessage;
    private MaterialButton mUploadButton;
    private View mGitRow;
    private volatile boolean mBusy;
    private volatile boolean mCancelRequested;
    private volatile boolean mHasIdentity;
    private volatile String mOriginUrl = "";
    private static final String LOG_SOURCE = "github-hub";
    private Runnable mResume;
    private String mLastMessage = GithubLinkStore.DEFAULT_MESSAGE;
    private String mLastExcludes = "";

    @NonNull
    public static Intent intentFor(@NonNull Context context, @NonNull File dir) {
        Intent intent = new Intent(context, GithubHubActivity.class);
        intent.putExtra(EXTRA_DIR, dir.getAbsolutePath());
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_github_hub);

        String path = getIntent().getStringExtra(EXTRA_DIR);
        if (path == null) { finish(); return; }
        mDir = new File(path);
        mStore = new GithubLinkStore(this);

        mScroll = findViewById(R.id.gh_scroll);
        mTokenLine = findViewById(R.id.gh_token_line);
        mRepoLine = findViewById(R.id.gh_repo_line);
        mConsole = findViewById(R.id.gh_console);
        mModeHint = findViewById(R.id.gh_mode_hint);
        mExcludes = findViewById(R.id.gh_excludes);
        mMessage = findViewById(R.id.gh_message);
        mUploadButton = findViewById(R.id.gh_upload);
        mGitRow = findViewById(R.id.gh_git_row);

        ((TextView) findViewById(R.id.gh_title)).setText("GitHub · " + mDir.getName());
        ((TextView) findViewById(R.id.gh_folder)).setText(mDir.getAbsolutePath());
        mExcludes.setText(mStore.excludesFor(mDir));
        mMessage.setText(mStore.messageFor(mDir));

        findViewById(R.id.gh_back).setOnClickListener(v -> finish());
        findViewById(R.id.gh_set_token).setOnClickListener(v -> promptToken(null));
        findViewById(R.id.gh_choose_repo).setOnClickListener(v -> chooseRepo());
        findViewById(R.id.gh_create_repo).setOnClickListener(v -> createRepo());
        findViewById(R.id.gh_branch).setOnClickListener(v -> promptBranch());
        findViewById(R.id.gh_upload).setOnClickListener(v -> onUploadPressed());
        findViewById(R.id.gh_browse).setOnClickListener(v -> openBrowser());
        findViewById(R.id.gh_actions).setOnClickListener(v -> openActions());
        findViewById(R.id.gh_status).setOnClickListener(v -> runGitInfo("status", "-sb"));
        findViewById(R.id.gh_log).setOnClickListener(v -> runGitInfo("log", "--oneline", "-n", "15"));
        findViewById(R.id.gh_pull).setOnClickListener(v -> pullWithGit());

        MaterialButtonToggleGroup toggle = findViewById(R.id.gh_mode_toggle);
        toggle.check(GithubLinkStore.MODE_TOKEN.equals(mStore.mode()) ? R.id.gh_mode_token : R.id.gh_mode_git);
        toggle.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            mStore.setMode(checkedId == R.id.gh_mode_token ? GithubLinkStore.MODE_TOKEN : GithubLinkStore.MODE_GIT);
            refreshSummary();
        });

        refreshSummary();
        console("▣ FILE MANAGER terminal (separate from the main terminal)");
        console("  log: " + TermuxErrorJournal.logPathHint(LOG_SOURCE) + LOG_SOURCE + "_<date>.txt");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mIo.shutdownNow();
    }

    private boolean tokenMode() {
        return GithubLinkStore.MODE_TOKEN.equals(mStore.mode());
    }

    private void refreshSummary() {
        mGitRow.setVisibility(tokenMode() ? View.GONE : View.VISIBLE);
        mModeHint.setText(tokenMode()
            ? "Everything goes through the GitHub API. No git and no .git folder needed."
            : "Uses git from Termux and creates .git here automatically. A token is only needed to create repos, browse repo files and read Actions.");
        mTokenLine.setText(mStore.hasToken() ? "Token saved " + GithubLinkStore.maskedToken(mStore.token()) : "No token saved");
        String repo = mStore.repoFor(mDir);
        mRepoLine.setText(repo.isEmpty() ? "No repository linked yet" : repo + "  ·  " + mStore.branchFor(mDir));
    }

    private void console(@NonNull String line) {
        TermuxErrorJournal.note(LOG_SOURCE, line);
        TaskCenter.TaskHandle running = TaskCenter.current();
        if (running != null) running.log(line);
        runOnUiThread(() -> {
            if (isFinishing()) return;
            mConsole.append(line + "\n");
            mScroll.post(() -> mScroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private void work(String label, @NonNull Job job, @Nullable Runnable then) {
        if (mBusy) { toast("Still working…"); return; }
        mBusy = true;
        mCancelRequested = false;
        mUploadButton.setText(tokenMode() ? "Cancel" : "Working…");
        mUploadButton.setEnabled(tokenMode());
        if (label != null) console("▸ " + label);
        final GitHealer.NeedsUser[] ask = new GitHealer.NeedsUser[1];
        final String title = (label == null ? "GitHub" : label.replace("…", "")) + " · " + mDir.getName();
        // Runs as a background Task: keeps going when this screen is closed or the app is left.
        TaskCenter.submit(this, "github", title, intentFor(this, mDir), tokenMode(), handle -> {
            try {
                job.run();
            } catch (GitHealer.NeedsUser e) {
                ask[0] = e;
                handle.needsAction(e.getMessage() != null ? e.getMessage() : "Needs your action");
            } catch (IOException | RuntimeException e) {
                TermuxErrorJournal.record(LOG_SOURCE, "job failed: " + title, e);
                throw e;
            }
        }, item -> {
            mBusy = false;
            if (isFinishing()) return;
            mUploadButton.setText("Upload");
            mUploadButton.setEnabled(true);
            if (ask[0] != null) onNeedsUser(ask[0]);
            else if (item.state == TaskCenter.State.FAILED) console("✗ " + item.status);
            else if (item.state == TaskCenter.State.CANCELLED) console("Cancelled");
            else if (then != null) then.run();
        });
    }

    private boolean requireToken(@NonNull Runnable next) {
        if (mStore.hasToken()) return true;
        promptToken(next);
        return false;
    }

    private void promptToken(@Nullable Runnable after) {
        final boolean hadToken = mStore.hasToken();
        CustomDialogs.OnText remove = hadToken ? (text -> {
            mStore.setToken("");
            refreshSummary();
            console("Token removed");
        }) : null;
        CustomDialogs.input(this, true, "GitHub token", "ghp_… (classic token with repo + workflow scope)", null, "Save",
            hadToken ? "Remove" : null, remove, text -> {
                final String token = text.trim();
                if (token.isEmpty()) return;
                final String[] login = new String[1];
                work("Checking token…", () -> login[0] = new GithubRestClient(token).whoAmI().optString("login"), () -> {
                    mStore.setToken(token);
                    console("Token OK, signed in as " + login[0]);
                    refreshSummary();
                    if (after != null) after.run();
                });
            });
    }

    private void chooseRepo() {
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
        entries.add(new CustomDialogs.MenuEntry("Pick from my GitHub", R.drawable.ic_github));
        entries.add(new CustomDialogs.MenuEntry("Type owner/repo or URL", R.drawable.ic_edit));
        CustomDialogs.menu(this, true, "Repository", entries, index -> {
            if (index == 0) pickFromAccount(); else typeRepo();
        });
    }

    private void pickFromAccount() {
        if (!requireToken(this::pickFromAccount)) return;
        final GithubRestClient client = new GithubRestClient(mStore.token());
        final List<String> names = new ArrayList<>();
        work("Loading your repositories…", () -> {
            for (int page = 1; page <= 3; page++) {
                JSONArray batch = client.getArray("/user/repos?per_page=100&sort=updated&page=" + page);
                for (int i = 0; i < batch.length(); i++) {
                    JSONObject repo = batch.optJSONObject(i);
                    if (repo != null) names.add(repo.optString("full_name"));
                }
                if (batch.length() < 100) break;
            }
        }, () -> {
            if (names.isEmpty()) { toast("No repositories found"); return; }
            List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
            for (String name : names) entries.add(new CustomDialogs.MenuEntry(name, R.drawable.ic_github));
            CustomDialogs.menu(this, true, "Your repositories", entries, index -> selectRepo(names.get(index)));
        });
    }

    private void typeRepo() {
        CustomDialogs.input(this, true, "Repository", "owner/repo or https://github.com/owner/repo", mStore.repoFor(mDir), "Link", text -> {
            String repo = GithubLinkStore.repoFromText(text);
            if (repo == null) { toast("That is not a GitHub repository"); return; }
            selectRepo(repo);
        });
    }

    private void selectRepo(@NonNull String repo) {
        mStore.setRepoFor(mDir, repo);
        refreshSummary();
        syncOrigin(repo);
        if (!mStore.hasToken()) return;
        final String[] branch = new String[1];
        work("Reading default branch…", () -> branch[0] = new GithubCommitWriter(new GithubRestClient(mStore.token()), repo).defaultBranch(), () -> {
            mStore.setBranchFor(mDir, branch[0]);
            refreshSummary();
        });
    }

    private void syncOrigin(@NonNull String repo) {
        if (tokenMode() || !GitShell.isInstalled() || !new File(mDir, ".git").exists()) return;
        mIo.execute(() -> {
            try {
                GitShell git = shell();
                String url = "https://github.com/" + repo + ".git";
                if (!git.git(null, "remote", "set-url", "origin", url).ok()) git.git(null, "remote", "add", "origin", url);
            } catch (IOException ignored) {
                return;
            }
        });
    }

    private void createRepo() {
        if (!requireToken(this::createRepo)) return;
        CustomDialogs.input(this, true, "New repository", "Repository name", mDir.getName(), "Next", name -> {
            final String repoName = name.trim();
            if (repoName.isEmpty()) return;
            List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
            entries.add(new CustomDialogs.MenuEntry("Private", R.drawable.ic_github));
            entries.add(new CustomDialogs.MenuEntry("Public", R.drawable.ic_github));
            CustomDialogs.menu(this, true, "Visibility", entries, index -> doCreateRepo(repoName, index == 0));
        });
    }

    private void doCreateRepo(@NonNull String name, boolean isPrivate) {
        final GithubRestClient client = new GithubRestClient(mStore.token());
        final String[] created = new String[2];
        work("Creating " + name + "…", () -> {
            JSONObject result = client.post("/user/repos", GithubJson.of("name", name, "private", isPrivate));
            created[0] = result.optString("full_name");
            created[1] = result.optString("default_branch", "main");
        }, () -> {
            mStore.setRepoFor(mDir, created[0]);
            mStore.setBranchFor(mDir, created[1]);
            console("Created " + created[0]);
            refreshSummary();
            syncOrigin(created[0]);
        });
    }

    private void promptBranch() {
        CustomDialogs.input(this, true, "Branch", "Branch name", mStore.branchFor(mDir), "Save", text -> {
            String branch = text.trim();
            if (branch.isEmpty()) return;
            mStore.setBranchFor(mDir, branch);
            refreshSummary();
        });
    }

    private void openBrowser() {
        if (!requireToken(this::openBrowser)) return;
        String repo = mStore.repoFor(mDir);
        if (repo.isEmpty()) { toast("Link a repository first"); return; }
        startActivity(GithubRepoBrowserActivity.intentFor(this, repo, mStore.branchFor(mDir)));
    }

    private void openActions() {
        if (!requireToken(this::openActions)) return;
        String repo = mStore.repoFor(mDir);
        if (repo.isEmpty()) { toast("Link a repository first"); return; }
        startActivity(GithubActionsActivity.intentFor(this, repo, mStore.branchFor(mDir)));
    }

    private void onUploadPressed() {
        if (mBusy) {
            if (tokenMode()) { mCancelRequested = true; console("Cancelling…"); }
            return;
        }
        final String excludes = mExcludes.getText().toString().trim();
        String typed = mMessage.getText().toString().trim();
        final String message = typed.isEmpty() ? GithubLinkStore.DEFAULT_MESSAGE : typed;
        mStore.setExcludesFor(mDir, excludes);
        mStore.setMessageFor(mDir, message);
        mLastMessage = message;
        mLastExcludes = excludes;
        if (tokenMode()) uploadWithApi(message, excludes); else beginGitUpload(message, excludes);
    }

    private void uploadWithApi(@NonNull String message, @NonNull String excludes) {
        if (!requireToken(() -> uploadWithApi(message, excludes))) return;
        final String repo = mStore.repoFor(mDir);
        if (repo.isEmpty()) {
            toast("Pick or create a repository first");
            chooseRepo();
            return;
        }
        final String branch = mStore.branchFor(mDir);
        final GithubCommitWriter writer = new GithubCommitWriter(new GithubRestClient(mStore.token()), repo);
        final GithubUploadFilter filter = new GithubUploadFilter(excludes);
        final String[] result = new String[1];
        work("Uploading to " + repo + " (" + branch + ")…",
            () -> result[0] = writer.uploadFolder(mDir, branch, message, filter, progress()),
            () -> console(result[0]));
    }

    @NonNull
    private GithubCommitWriter.Progress progress() {
        return new GithubCommitWriter.Progress() {
            @Override public void say(@NonNull String line) { console(line); }
            @Override public boolean cancelled() {
                TaskCenter.TaskHandle running = TaskCenter.current();
                return mCancelRequested || (running != null && running.isCancelled());
            }
        };
    }

    @NonNull
    private GitShell shell() {
        return new GitShell(this, mDir, mStore.token());
    }

    @NonNull
    private GitHealer healer() {
        return new GitHealer(this, shell(), mDir, mStore, this::console).commitMessage(mLastMessage);
    }

    /** git missing: install it automatically, no questions. */
    private void askInstallGit(@Nullable Runnable after) {
        work("git is not installed, installing it now (pkg install git)…", () -> healer().installGit(), () -> {
            console("git installed");
            if (after != null) after.run();
        });
    }

    private void onNeedsUser(@NonNull GitHealer.NeedsUser e) {
        final Runnable resume = mResume != null ? mResume : () -> { };
        switch (e.kind) {
            case NO_IDENTITY:
                askIdentity(resume);
                break;
            case AUTH_FAILED:
                promptToken(resume);
                break;
            case NO_REMOTE:
                askRemote(resume);
                break;
            case REPO_NOT_FOUND:
                console("Pick the right repository or create a new one, then press Upload again.");
                chooseRepo();
                break;
            case NON_FAST_FORWARD:
                CustomDialogs.confirm(this, true, "Overwrite GitHub?",
                    "GitHub has changes that could not be merged automatically. Force push replaces the GitHub branch with your local files. Continue?",
                    "Force push", true, this::forcePush);
                break;
            case BROKEN_BINARY:
            case BIG_PUSH:
                console("Switching to GitHub API upload (does not need git).");
                uploadWithApi(mLastMessage, mLastExcludes);
                break;
            default:
                break;
        }
    }

    private void forcePush() {
        work("Force pushing…", () -> {
            GitHealer healer = healer();
            healer.run("push", "--force", healer.authTarget(), "HEAD:refs/heads/" + mStore.branchFor(mDir));
        }, () -> console("Force pushed to " + mStore.branchFor(mDir)));
    }

    private void beginGitUpload(@NonNull String message, @NonNull String excludes) {
        mResume = () -> beginGitUpload(message, excludes);
        if (!GitShell.isInstalled()) {
            askInstallGit(() -> beginGitUpload(message, excludes));
            return;
        }
        work("Preparing repository…", this::prepareRepository, () -> {
            if (!mHasIdentity) { askIdentity(() -> beginGitUpload(message, excludes)); return; }
            if (mOriginUrl.isEmpty()) { askRemote(() -> beginGitUpload(message, excludes)); return; }
            work("Uploading with git…", () -> pushWithGit(message, excludes), () -> console("Done."));
        });
    }

    private void prepareRepository() throws IOException {
        GitShell git = shell();
        if (!git.git(null, "--version").ok()) healer().run("--version");
        git.ensureSafeDirectory();
        if (!new File(mDir, ".git").exists()) {
            console("Creating .git");
            GitShell.Outcome made = git.git(this::console, "init", "-b", mStore.branchFor(mDir));
            if (!made.ok()) made = git.git(this::console, "init");
            if (!made.ok()) throw new IOException("git init failed");
        }
        String path = mDir.getAbsolutePath();
        if (path.startsWith("/storage/") || path.startsWith("/sdcard")) {
            git.git(null, "config", "core.filemode", "false");
            git.git(null, "config", "core.symlinks", "false");
        }
        mHasIdentity = !git.capture("config", "user.name").isEmpty() && !git.capture("config", "user.email").isEmpty();
        if (!mHasIdentity) mHasIdentity = healer().autoIdentity();
        String origin = git.capture("remote", "get-url", "origin");
        String linked = mStore.repoFor(mDir);
        if (origin.isEmpty() && !linked.isEmpty()) {
            origin = "https://github.com/" + linked + ".git";
            git.git(this::console, "remote", "add", "origin", origin);
        }
        String detected = GithubLinkStore.repoFromText(origin);
        if (detected != null && !detected.equals(linked)) {
            mStore.setRepoFor(mDir, detected);
            runOnUiThread(this::refreshSummary);
        }
        mOriginUrl = origin;
    }

    private void askIdentity(@NonNull Runnable after) {
        CustomDialogs.input(this, true, "Git name", "Name shown on your commits", null, "Next", name ->
            CustomDialogs.input(this, true, "Git email", "you@example.com", null, "Save", email -> {
                if (name.trim().isEmpty() || email.trim().isEmpty()) return;
                work("Saving git identity…", () -> {
                    GitShell git = shell();
                    git.git(null, "config", "--global", "user.name", name.trim());
                    git.git(null, "config", "--global", "user.email", email.trim());
                }, after);
            }));
    }

    private void askRemote(@NonNull Runnable after) {
        CustomDialogs.input(this, true, "GitHub repository", "owner/repo or https://github.com/owner/repo.git", null, "Link", text -> {
            final String repo = GithubLinkStore.repoFromText(text);
            if (repo == null) { toast("That is not a GitHub repository"); return; }
            mStore.setRepoFor(mDir, repo);
            refreshSummary();
            work("Linking origin…", () -> {
                GitShell.Outcome outcome = shell().git(null, "remote", "add", "origin", "https://github.com/" + repo + ".git");
                if (!outcome.ok()) throw new IOException(outcome.text.trim());
            }, after);
        });
    }

    private void writeExcludeBlock(@NonNull GithubUploadFilter filter) throws IOException {
        File info = new File(mDir, ".git/info");
        if (!info.isDirectory() && !info.mkdirs()) throw new IOException("Cannot create .git/info");
        File exclude = new File(info, "exclude");
        String current = exclude.exists() ? FileOps.readText(exclude) : "";
        int begin = current.indexOf(EXCLUDE_BEGIN);
        int end = current.indexOf(EXCLUDE_END);
        String kept = (begin >= 0 && end > begin) ? current.substring(0, begin) + current.substring(end + EXCLUDE_END.length()) : current;
        StringBuilder next = new StringBuilder(kept.trim());
        if (!filter.tokens().isEmpty()) {
            if (next.length() > 0) next.append("\n\n");
            next.append(EXCLUDE_BEGIN).append('\n');
            for (String token : filter.tokens()) next.append(token).append('\n');
            next.append(EXCLUDE_END);
        }
        next.append('\n');
        FileOps.writeText(exclude, next.toString());
    }

    private void pushWithGit(@NonNull String message, @NonNull String excludes) throws IOException {
        GitShell git = shell();
        GitHealer healer = healer().commitMessage(message);
        writeExcludeBlock(new GithubUploadFilter(excludes));
        String branch = mStore.branchFor(mDir);
        String current = git.capture("symbolic-ref", "--short", "HEAD");
        if (!branch.equals(current)) {
            if (!git.git(this::console, "checkout", branch).ok()
                && !git.git(this::console, "checkout", "-b", branch).ok()
                && !git.git(this::console, "symbolic-ref", "HEAD", "refs/heads/" + branch).ok()) {
                throw new IOException("Cannot switch to branch " + branch);
            }
        }
        healer.run("add", "-A");
        healer.runAccepting("nothing (added )?to commit", "-c", "commit.gpgsign=false", "commit", "-m", message);
        healer.run("push", healer.authTarget(), "HEAD:refs/heads/" + branch);
        console("Pushed to " + branch);
    }

    private void pullWithGit() {
        mResume = this::pullWithGit;
        if (!GitShell.isInstalled()) { askInstallGit(this::pullWithGit); return; }
        if (!new File(mDir, ".git").exists()) { toast("No .git here yet. Upload once to create it."); return; }
        work("git pull…", () -> {
            shell().ensureSafeDirectory();
            GitHealer healer = healer();
            if (healer.authTarget().equals("origin") && shell().capture("remote", "get-url", "origin").isEmpty()) {
                throw new GitHealer.NeedsUser(com.termux.app.ext.github.GitErrorDoctor.Kind.NO_REMOTE, "No origin remote yet");
            }
            healer.run("pull", "--no-rebase", "--no-edit", healer.authTarget(), mStore.branchFor(mDir));
        }, null);
    }

    private void runGitInfo(@NonNull String... args) {
        if (!GitShell.isInstalled()) { askInstallGit(() -> runGitInfo(args)); return; }
        if (!new File(mDir, ".git").exists()) { toast("No .git here yet. Upload once to create it."); return; }
        work("git " + args[0] + "…", () -> {
            shell().ensureSafeDirectory();
            healer().run(args);
        }, null);
    }
}
