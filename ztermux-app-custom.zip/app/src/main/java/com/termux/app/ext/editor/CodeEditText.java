package com.termux.app.ext.editor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Layout;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.content.ContextCompat;

import com.termux.R;
import com.termux.app.ext.font.FontManager;

/**
 * Plain EditText with a pinned line-number gutter. Lines never soft-wrap (horizontal scrolling), so the
 * visual line index equals the logical line number.
 */
public class CodeEditText extends AppCompatEditText {

    private final Paint mGutterBg = new Paint();
    private final Paint mGutterText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mDivider = new Paint();
    private final float mPad;
    private int mDigits = 2;

    public CodeEditText(Context context) { this(context, null); }

    public CodeEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        float density = getResources().getDisplayMetrics().density;
        mPad = 8 * density;

        mGutterBg.setColor(ContextCompat.getColor(context, R.color.fm_gutter));
        mDivider.setColor(ContextCompat.getColor(context, R.color.fm_divider));
        mGutterText.setColor(ContextCompat.getColor(context, R.color.fm_gutter_text));
        mGutterText.setTypeface(FontManager.getTerminalTypeface());
        mGutterText.setTextAlign(Paint.Align.RIGHT);

        setHorizontallyScrolling(true);
        setTypeface(FontManager.getTerminalTypeface());
        setVerticalScrollBarEnabled(true);
        setHorizontalScrollBarEnabled(true);
        setOverScrollMode(OVER_SCROLL_NEVER);
        updateGutterPadding();
    }

    @Override
    protected void onTextChanged(CharSequence text, int start, int lengthBefore, int lengthAfter) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter);
        if (mGutterText == null) return; // called from the TextView constructor, before our fields exist
        int digits = Math.max(2, String.valueOf(Math.max(1, getLineCount())).length());
        if (digits != mDigits) {
            mDigits = digits;
            updateGutterPadding();
        }
    }

    @Override
    public void setTextSize(float size) {
        super.setTextSize(size);
        if (mGutterText != null) updateGutterPadding();
    }

    private float gutterWidth() {
        mGutterText.setTextSize(getTextSize() * 0.85f);
        return mGutterText.measureText("0") * mDigits + mPad * 2;
    }

    private void updateGutterPadding() {
        int left = (int) (gutterWidth() + mPad);
        setPadding(left, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);

        final Layout layout = getLayout();
        if (layout == null) return;

        final float gw = gutterWidth();
        final int sx = getScrollX(), sy = getScrollY();
        final int top = sy, bottom = sy + getHeight();

        // Opaque gutter pinned to the left edge of the viewport (text scrolls underneath it).
        canvas.drawRect(sx, top, sx + gw, bottom, mGutterBg);
        canvas.drawRect(sx + gw - 1f, top, sx + gw, bottom, mDivider);

        final int first = layout.getLineForVertical(Math.max(0, top - getCompoundPaddingTop()));
        final int last = Math.min(layout.getLineCount() - 1,
            layout.getLineForVertical(Math.max(0, bottom - getCompoundPaddingTop())));
        final float right = sx + gw - mPad;
        final int offsetY = getCompoundPaddingTop();
        for (int line = first; line <= last; line++) {
            float baseline = layout.getLineBaseline(line) + offsetY;
            canvas.drawText(String.valueOf(line + 1), right, baseline, mGutterText);
        }
    }
}
