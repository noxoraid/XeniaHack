package com.termux.app.ext.filemanager;

import androidx.annotation.NonNull;

import java.io.File;

/** Immutable snapshot of one row in the File Manager list. */
public final class FileEntry {
    @NonNull public final File file;
    public final boolean directory;
    public final long size;
    public final long modified;

    public FileEntry(@NonNull File file) {
        this.file = file;
        this.directory = file.isDirectory();
        this.size = directory ? -1 : file.length();
        this.modified = file.lastModified();
    }

    @NonNull public String name() { return file.getName(); }
    @NonNull public String path() { return file.getAbsolutePath(); }
}
