package com.termux.app.ext.github;

import androidx.annotation.NonNull;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class GithubLogDigest {

    private static final Pattern TIMESTAMP = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}T[\\d:.]+Z ");
    private static final Pattern LEADING_NUMBER = Pattern.compile("^(?:.*/)?(\\d+)_");
    private static final Pattern PROBLEM = Pattern.compile(
        "##\\[error\\]|\\berror\\b|\\bfailed\\b|\\bfailure\\b|\\bfatal\\b|exception|cannot find symbol|what went wrong|\\bERR!",
        Pattern.CASE_INSENSITIVE);
    private static final String HEADER_MARK = "===== ";

    private GithubLogDigest() {}

    private static final class Section implements Comparable<Section> {
        final String name;
        final String text;
        final int order;

        Section(String name, String text) {
            this.name = name;
            this.text = text;
            Matcher m = LEADING_NUMBER.matcher(name);
            this.order = m.find() ? Integer.parseInt(m.group(1)) : Integer.MAX_VALUE;
        }

        @Override
        public int compareTo(Section other) {
            if (order != other.order) return order < other.order ? -1 : 1;
            return name.compareTo(other.name);
        }
    }

    @NonNull
    public static String readZip(@NonNull InputStream zipStream) throws IOException {
        List<Section> sections = new ArrayList<>();
        try (ZipInputStream zip = new ZipInputStream(zipStream)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[16384];
                int read;
                while ((read = zip.read(buffer)) != -1) out.write(buffer, 0, read);
                sections.add(new Section(entry.getName(), new String(out.toByteArray(), StandardCharsets.UTF_8)));
            }
        }
        Collections.sort(sections);
        StringBuilder full = new StringBuilder();
        for (Section section : sections) {
            full.append(HEADER_MARK).append(section.name).append(" =====\n");
            for (String line : section.text.split("\r?\n")) {
                full.append(TIMESTAMP.matcher(line).replaceFirst("")).append('\n');
            }
            full.append('\n');
        }
        return full.toString();
    }

    @NonNull
    public static String errorsOnly(@NonNull String fullLog) {
        String[] lines = fullLog.split("\n", -1);
        StringBuilder out = new StringBuilder();
        String header = null;
        boolean headerPrinted = false;
        int printedUntil = -1;
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.startsWith(HEADER_MARK)) {
                header = line;
                headerPrinted = false;
                continue;
            }
            if (!PROBLEM.matcher(line).find()) continue;
            if (header != null && !headerPrinted) {
                out.append(header).append('\n');
                headerPrinted = true;
            }
            int from = Math.max(printedUntil + 1, i - 1);
            int to = Math.min(lines.length - 1, i + 2);
            if (from > printedUntil + 1 && printedUntil >= 0) out.append("...\n");
            for (int k = from; k <= to; k++) {
                if (lines[k].startsWith(HEADER_MARK)) break;
                out.append(lines[k]).append('\n');
                printedUntil = k;
            }
        }
        return out.length() == 0 ? "No error lines found in this log." : out.toString();
    }
}
