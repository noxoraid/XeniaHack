package com.termux.app.terminal;

import android.annotation.SuppressLint;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.termux.R;
import com.termux.app.TermuxActivity;
import com.termux.app.ext.diagnostics.TermuxErrorJournal;
import com.termux.shared.termux.shell.command.runner.terminal.TermuxSession;
import com.termux.terminal.TerminalSession;

import java.util.List;

public class TermuxSessionsListViewController extends ArrayAdapter<TermuxSession> implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {

    private static final String JOURNAL_NAME = "sessions";

    final TermuxActivity mActivity;

    final StyleSpan boldSpan = new StyleSpan(Typeface.BOLD);
    final StyleSpan italicSpan = new StyleSpan(Typeface.ITALIC);

    public TermuxSessionsListViewController(TermuxActivity activity, List<TermuxSession> sessionList) {
        super(activity.getApplicationContext(), R.layout.item_terminal_sessions_list, sessionList);
        this.mActivity = activity;
    }

    @SuppressLint("SetTextI18n")
    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        View sessionRowView = convertView;
        if (sessionRowView == null) {
            LayoutInflater inflater = mActivity.getLayoutInflater();
            sessionRowView = inflater.inflate(R.layout.item_terminal_sessions_list, parent, false);
        }

        TextView sessionTitleView = sessionRowView.findViewById(R.id.session_title);
        View renameButton = sessionRowView.findViewById(R.id.session_rename_button);
        View closeButton = sessionRowView.findViewById(R.id.session_close_button);

        TerminalSession sessionAtRow = getItem(position).getTerminalSession();
        if (sessionAtRow == null) {
            sessionTitleView.setText("null session");
            return sessionRowView;
        }

        boolean isCurrent = sessionAtRow == mActivity.getCurrentSession();
        sessionRowView.setBackgroundResource(isCurrent ? R.drawable.bg_session_item_current : R.drawable.bg_session_item);

        String name = sessionAtRow.mSessionName;
        String sessionTitle = sessionAtRow.getTitle();

        String numberPart = "[" + (position + 1) + "] ";
        String sessionNamePart = (TextUtils.isEmpty(name) ? "" : name);
        String sessionTitlePart = (TextUtils.isEmpty(sessionTitle) ? "" : ((sessionNamePart.isEmpty() ? "" : "\n") + sessionTitle));

        String fullSessionTitle = numberPart + sessionNamePart + sessionTitlePart;
        SpannableString fullSessionTitleStyled = new SpannableString(fullSessionTitle);
        fullSessionTitleStyled.setSpan(new StyleSpan(Typeface.BOLD), 0, numberPart.length() + sessionNamePart.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        fullSessionTitleStyled.setSpan(new StyleSpan(Typeface.ITALIC), numberPart.length() + sessionNamePart.length(), fullSessionTitle.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        sessionTitleView.setText(fullSessionTitleStyled);

        boolean sessionRunning = sessionAtRow.isRunning();

        if (sessionRunning) {
            sessionTitleView.setPaintFlags(sessionTitleView.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            sessionTitleView.setPaintFlags(sessionTitleView.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
        int color = sessionRunning || sessionAtRow.getExitStatus() == 0
            ? ContextCompat.getColor(mActivity, R.color.drawer_text)
            : ContextCompat.getColor(mActivity, R.color.drawer_danger);
        sessionTitleView.setTextColor(color);

        renameButton.setOnClickListener(v -> mActivity.getTermuxTerminalSessionClient().renameSession(sessionAtRow));
        closeButton.setOnClickListener(v -> mActivity.getTermuxTerminalSessionClient().closeSession(sessionAtRow));
        return sessionRowView;
    }

    public void attachTo(@NonNull ListView list) {
        list.setAdapter(this);
        final GestureDetector detector = new GestureDetector(mActivity, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapUp(MotionEvent e) { actOnTap(list, e, false); return false; }
            @Override public void onLongPress(MotionEvent e) { actOnTap(list, e, true); }
        });
        list.setOnTouchListener((v, event) -> {
            detector.onTouchEvent(event);
            return false;
        });
    }

    private void actOnTap(@NonNull ListView list, @NonNull MotionEvent event, boolean longPress) {
        try {
            int position = list.pointToPosition((int) event.getX(), (int) event.getY());
            if (position == AdapterView.INVALID_POSITION || position >= getCount()) {
                TermuxErrorJournal.record(JOURNAL_NAME, "tap hit no session row at x=" + event.getX() + " y=" + event.getY()
                    + " rows=" + getCount(), null);
                return;
            }
            if (longPress) onItemLongClick(list, null, position, 0L); else onItemClick(list, null, position, 0L);
        } catch (RuntimeException e) {
            TermuxErrorJournal.record(JOURNAL_NAME, "session tap crashed", e);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        TermuxSession clickedSession = getItem(position);
        if (clickedSession == null || clickedSession.getTerminalSession() == null) {
            TermuxErrorJournal.record(JOURNAL_NAME, "session at row " + position + " is missing", null);
            return;
        }
        mActivity.getTermuxTerminalSessionClient().setCurrentSession(clickedSession.getTerminalSession());
        mActivity.getDrawer().closeDrawers();
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        final TermuxSession selectedSession = getItem(position);
        mActivity.getTermuxTerminalSessionClient().renameSession(selectedSession.getTerminalSession());
        return true;
    }

}
