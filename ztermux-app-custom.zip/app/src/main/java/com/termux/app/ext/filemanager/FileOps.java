package com.termux.app.ext.filemanager;

import android.system.Os;

import androidx.annotation.NonNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Locale;

/** Blocking file operations. Call from a background thread. */
public final class FileOps {

    private FileOps() {}

    // ------------------------------------------------------------------ queries

    public static boolean isSymlink(@NonNull File file) {
        try {
            File parent = file.getParentFile();
            File canonical = parent == null ? file : new File(parent.getCanonicalFile(), file.getName());
            return !canonical.getCanonicalFile().equals(canonical.getAbsoluteFile());
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean isSameOrInside(@NonNull File candidateChild, @NonNull File parent) {
        try {
            String c = candidateChild.getCanonicalPath(), p = parent.getCanonicalPath();
            return c.equals(p) || c.startsWith(p + "/");
        } catch (IOException e) {
            String c = candidateChild.getAbsolutePath(), p = parent.getAbsolutePath();
            return c.equals(p) || c.startsWith(p + "/");
        }
    }

    @NonNull
    public static String humanSize(long bytes) {
        if (bytes < 0) return "";
        if (bytes < 1024) return bytes + " B";
        double v = bytes;
        String[] units = {"KB", "MB", "GB", "TB"};
        int i = -1;
        do { v /= 1024; i++; } while (v >= 1024 && i < units.length - 1);
        return String.format(Locale.US, v >= 100 ? "%.0f %s" : "%.1f %s", v, units[i]);
    }

    /** True if the file looks like text (no NUL bytes in the first 8 KB) and is small enough to edit. */
    public static boolean isEditableText(@NonNull File file, long maxBytes) {
        if (!file.isFile() || file.length() > maxBytes) return false;
        try (InputStream in = new FileInputStream(file)) {
            byte[] buf = new byte[8192];
            int n = in.read(buf);
            for (int i = 0; i < n; i++) if (buf[i] == 0) return false;
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    // --------------------------------------------------------------- mutations

    /** Returns a destination File in {@code dir} that does not exist yet ("name (copy)", "name (copy 2)", ...). */
    @NonNull
    public static File uniqueTarget(@NonNull File dir, @NonNull String name) {
        File target = new File(dir, name);
        if (!target.exists() && !isSymlink(target)) return target;
        String base = name, ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
        int n = 1;
        while (true) {
            String suffix = n == 1 ? " (copy)" : " (copy " + n + ")";
            target = new File(dir, base + suffix + ext);
            if (!target.exists() && !isSymlink(target)) return target;
            n++;
        }
    }

    /** Copies a file or directory tree into {@code destDir}; returns the new top-level file. */
    @NonNull
    public static File copyInto(@NonNull File src, @NonNull File destDir) throws IOException {
        if (src.isDirectory() && isSameOrInside(destDir, src))
            throw new IOException("Cannot copy a folder into itself");
        File target = uniqueTarget(destDir, src.getName());
        copyRecursive(src, target);
        return target;
    }

    /** Moves into {@code destDir}: rename when possible, otherwise copy + delete. */
    @NonNull
    public static File moveInto(@NonNull File src, @NonNull File destDir) throws IOException {
        if (src.isDirectory() && isSameOrInside(destDir, src))
            throw new IOException("Cannot move a folder into itself");
        File parent = src.getParentFile();
        if (parent != null && parent.getAbsoluteFile().equals(destDir.getAbsoluteFile()))
            return src; // already there
        File target = uniqueTarget(destDir, src.getName());
        if (src.renameTo(target)) return target;
        copyRecursive(src, target);
        deleteRecursive(src);
        return target;
    }

    public static void rename(@NonNull File src, @NonNull String newName) throws IOException {
        if (newName.isEmpty() || newName.contains("/") || newName.equals(".") || newName.equals(".."))
            throw new IOException("Invalid name");
        File target = new File(src.getParentFile(), newName);
        if (target.exists()) throw new IOException("\"" + newName + "\" already exists");
        if (!src.renameTo(target)) throw new IOException("Rename failed");
    }

    public static void deleteRecursive(@NonNull File file) throws IOException {
        if (file.isDirectory() && !isSymlink(file)) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursive(child);
        }
        if (!file.delete() && file.exists() )
            throw new IOException("Could not delete " + file.getName());
    }

    public static void createFolder(@NonNull File parent, @NonNull String name) throws IOException {
        validateNewName(parent, name);
        if (!new File(parent, name).mkdirs()) throw new IOException("Could not create folder");
    }

    public static void createFile(@NonNull File parent, @NonNull String name) throws IOException {
        validateNewName(parent, name);
        if (!new File(parent, name).createNewFile()) throw new IOException("Could not create file");
    }

    public static void deleteAll(@NonNull List<File> files) throws IOException {
        for (File f : files) deleteRecursive(f);
    }

    // ---------------------------------------------------------------- internals

    private static void validateNewName(File parent, String name) throws IOException {
        if (name.isEmpty() || name.contains("/") || name.equals(".") || name.equals(".."))
            throw new IOException("Invalid name");
        if (new File(parent, name).exists()) throw new IOException("\"" + name + "\" already exists");
    }

    private static void copyRecursive(File src, File dst) throws IOException {
        if (isSymlink(src)) {
            try {
                Os.symlink(Os.readlink(src.getAbsolutePath()), dst.getAbsolutePath());
                return;
            } catch (Exception e) {
                throw new IOException("Could not copy symlink " + src.getName());
            }
        }
        if (src.isDirectory()) {
            if (!dst.exists() && !dst.mkdirs()) throw new IOException("Could not create " + dst.getName());
            File[] children = src.listFiles();
            if (children != null) {
                for (File child : children) copyRecursive(child, new File(dst, child.getName()));
            }
            dst.setExecutable(src.canExecute(), false);
        } else {
            try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            if (src.canExecute()) dst.setExecutable(true, false);
        }
    }

    /** Reads a whole text file as UTF-8. */
    @NonNull
    public static String readText(@NonNull File file) throws IOException {
        try (InputStream in = new FileInputStream(file)) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream((int) Math.max(32, file.length()));
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    public static void writeText(@NonNull File file, @NonNull String text) throws IOException {
        try (OutputStream out = new FileOutputStream(file, false)) {
            out.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            out.flush();
        }
    }
}
