package com.termux.app.ext.github;

import android.util.Base64;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.termux.app.ext.filemanager.FileOps;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public final class GithubCommitWriter {

    public interface Progress {
        void say(@NonNull String line);
        boolean cancelled();
    }

    private static final long LARGEST_UPLOAD_BYTES = 25L * 1024 * 1024;
    private static final int PARALLEL_BLOBS = 4;

    private final GithubRestClient mClient;
    private final String mRepo;

    public GithubCommitWriter(@NonNull GithubRestClient client, @NonNull String repo) {
        mClient = client;
        mRepo = repo;
    }

    @NonNull
    public String defaultBranch() throws IOException {
        return mClient.getObject("/repos/" + mRepo).optString("default_branch", "main");
    }

    @Nullable
    private String headOf(String branch) throws IOException {
        try {
            JSONObject ref = mClient.getObject("/repos/" + mRepo + "/git/ref/heads/" + GithubRestClient.encodePath(branch));
            JSONObject object = ref.optJSONObject("object");
            return object == null ? null : object.optString("sha", null);
        } catch (GithubApiException e) {
            if (e.status == 404 || e.status == 409) return null;
            throw e;
        }
    }

    private void createBranch(String branch, String sha) throws IOException {
        mClient.post("/repos/" + mRepo + "/git/refs", GithubJson.of("ref", "refs/heads/" + branch, "sha", sha));
    }

    @NonNull
    public String uploadFolder(@NonNull File root, @NonNull String branch, @NonNull String message,
                               @NonNull GithubUploadFilter filter, @NonNull Progress progress) throws IOException {
        List<File> files = new ArrayList<>();
        collect(root, root, filter, files, progress);
        if (files.isEmpty()) return "No files to upload.";
        progress.say(files.size() + " files found");

        String head = headOf(branch);
        if (head == null) {
            String fallback = defaultBranch();
            if (!fallback.equals(branch)) {
                String fallbackHead = headOf(fallback);
                if (fallbackHead != null) {
                    createBranch(branch, fallbackHead);
                    head = fallbackHead;
                    progress.say("Created branch " + branch + " from " + fallback);
                }
            }
        }

        int firstIndex = 0;
        if (head == null) {
            head = bootstrap(root, files.get(0), message, progress);
            firstIndex = 1;
            if (!defaultBranch().equals(branch)) createBranch(branch, head);
        }

        JSONObject headCommit = mClient.getObject("/repos/" + mRepo + "/git/commits/" + head);
        JSONObject headTree = headCommit.optJSONObject("tree");
        if (headTree == null) throw new IOException("Cannot read the head commit");
        final String baseTree = headTree.optString("sha");
        final GithubTreeSnapshot remote = GithubTreeSnapshot.fetch(mClient, mRepo, branch);

        final AtomicInteger skipped = new AtomicInteger();
        final AtomicInteger sent = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(PARALLEL_BLOBS);
        List<Future<JSONObject>> pending = new ArrayList<>();
        try {
            for (int i = firstIndex; i < files.size(); i++) {
                final File file = files.get(i);
                pending.add(pool.submit(blobTask(root, file, remote, progress, skipped, sent)));
            }
            JSONArray entries = new JSONArray();
            for (Future<JSONObject> future : pending) {
                if (progress.cancelled()) throw new IOException("Cancelled");
                try {
                    JSONObject entry = future.get();
                    if (entry != null) entries.put(entry);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new IOException("Interrupted");
                } catch (ExecutionException e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof IOException) throw (IOException) cause;
                    throw new IOException(String.valueOf(cause));
                }
            }
            if (entries.length() == 0) {
                if (firstIndex == 1) return "Done. Repository created with 1 file.";
                return "Everything is already up to date (" + skipped.get() + " files unchanged).";
            }
            String sha = commitEntries(head, branch, baseTree, entries, message);
            return "Done. Commit " + sha.substring(0, 7) + " on " + branch + ": " + sent.get() + " uploaded, " + skipped.get() + " unchanged.";
        } finally {
            pool.shutdownNow();
        }
    }

    private Callable<JSONObject> blobTask(final File root, final File file, final GithubTreeSnapshot remote,
                                          final Progress progress, final AtomicInteger skipped, final AtomicInteger sent) {
        return () -> {
            if (progress.cancelled()) throw new IOException("Cancelled");
            String relative = relativeTo(root, file);
            byte[] bytes = readFully(file);
            String localSha = GithubBlobHash.of(bytes);
            GithubTreeSnapshot.Node existing = remote.get(relative);
            if (existing != null && localSha.equals(existing.sha)) {
                skipped.incrementAndGet();
                return null;
            }
            JSONObject blob = mClient.post("/repos/" + mRepo + "/git/blobs",
                GithubJson.of("content", Base64.encodeToString(bytes, Base64.NO_WRAP), "encoding", "base64"));
            sent.incrementAndGet();
            progress.say("Uploaded " + relative + " (" + FileOps.humanSize(bytes.length) + ")");
            String mode = existing != null ? existing.mode : (file.canExecute() ? "100755" : "100644");
            return GithubJson.of("path", relative, "mode", mode, "type", "blob", "sha", blob.optString("sha"));
        };
    }

    @NonNull
    private String bootstrap(File root, File first, String message, Progress progress) throws IOException {
        String relative = relativeTo(root, first);
        byte[] bytes = readFully(first);
        progress.say("Repository is empty, creating the first commit with " + relative);
        JSONObject result = mClient.put("/repos/" + mRepo + "/contents/" + GithubRestClient.encodePath(relative),
            GithubJson.of("message", message, "content", Base64.encodeToString(bytes, Base64.NO_WRAP)));
        JSONObject commit = result.optJSONObject("commit");
        String sha = commit == null ? null : commit.optString("sha", null);
        if (sha == null) throw new IOException("GitHub did not return the first commit");
        return sha;
    }

    @NonNull
    private String commitEntries(String head, String branch, String baseTree, JSONArray entries, String message) throws IOException {
        JSONObject tree = mClient.post("/repos/" + mRepo + "/git/trees", GithubJson.of("base_tree", baseTree, "tree", entries));
        JSONObject commit = mClient.post("/repos/" + mRepo + "/git/commits",
            GithubJson.of("message", message, "tree", tree.optString("sha"), "parents", new JSONArray().put(head)));
        String commitSha = commit.optString("sha");
        mClient.patch("/repos/" + mRepo + "/git/refs/heads/" + GithubRestClient.encodePath(branch), GithubJson.of("sha", commitSha));
        return commitSha;
    }

    private void commitOnBranch(String branch, JSONArray entries, String message) throws IOException {
        String head = headOf(branch);
        if (head == null) throw new IOException("Branch " + branch + " does not exist yet");
        JSONObject headTree = mClient.getObject("/repos/" + mRepo + "/git/commits/" + head).optJSONObject("tree");
        if (headTree == null) throw new IOException("Cannot read the head commit");
        commitEntries(head, branch, headTree.optString("sha"), entries, message);
    }

    public void renamePath(@NonNull GithubTreeSnapshot snapshot, @NonNull String branch,
                           @NonNull String oldPath, @NonNull String newPath) throws IOException {
        if (newPath.equals(oldPath) || newPath.startsWith(oldPath + "/")) throw new IOException("Invalid target path");
        if (snapshot.exists(newPath)) throw new IOException("Target already exists");
        JSONArray entries = new JSONArray();
        for (GithubTreeSnapshot.Node node : snapshot.blobsUnder(oldPath)) {
            String target = newPath + node.path.substring(oldPath.length());
            entries.put(GithubJson.of("path", target, "mode", node.mode, "type", "blob", "sha", node.sha));
            entries.put(GithubJson.removal(node.path));
        }
        if (entries.length() == 0) throw new IOException("Nothing to rename");
        commitOnBranch(branch, entries, "Rename " + oldPath + " to " + newPath);
    }

    public void deletePath(@NonNull GithubTreeSnapshot snapshot, @NonNull String branch, @NonNull String path) throws IOException {
        JSONArray entries = new JSONArray();
        for (GithubTreeSnapshot.Node node : snapshot.blobsUnder(path)) entries.put(GithubJson.removal(node.path));
        if (entries.length() == 0) throw new IOException("Nothing to delete");
        commitOnBranch(branch, entries, "Delete " + path);
    }

    @NonNull
    public String putFile(@NonNull String branch, @NonNull String path, @NonNull byte[] content,
                          @Nullable String existingSha, @NonNull String message) throws IOException {
        JSONObject body = GithubJson.of("message", message, "content", Base64.encodeToString(content, Base64.NO_WRAP), "branch", branch);
        if (existingSha != null) {
            body = GithubJson.of("message", message, "content", Base64.encodeToString(content, Base64.NO_WRAP),
                "branch", branch, "sha", existingSha);
        }
        JSONObject result = mClient.put("/repos/" + mRepo + "/contents/" + GithubRestClient.encodePath(path), body);
        JSONObject written = result.optJSONObject("content");
        return written == null ? "" : written.optString("sha", "");
    }

    @NonNull
    public byte[] readBlob(@NonNull String sha) throws IOException {
        JSONObject blob = mClient.getObject("/repos/" + mRepo + "/git/blobs/" + sha);
        return Base64.decode(blob.optString("content", ""), Base64.DEFAULT);
    }

    private void collect(File root, File dir, GithubUploadFilter filter, List<File> out, Progress progress) throws IOException {
        File[] children = dir.listFiles();
        if (children == null) return;
        Arrays.sort(children);
        for (File child : children) {
            if (progress.cancelled()) throw new IOException("Cancelled");
            String relative = relativeTo(root, child);
            if (filter.skips(relative)) continue;
            if (isSymlink(child)) continue;
            if (child.isDirectory()) {
                collect(root, child, filter, out, progress);
                continue;
            }
            if (!child.isFile() || !child.canRead()) continue;
            if (child.length() > LARGEST_UPLOAD_BYTES) {
                progress.say("Skipped (over 25 MB): " + relative);
                continue;
            }
            out.add(child);
        }
    }

    private static boolean isSymlink(File file) throws IOException {
        File parent = file.getParentFile();
        if (parent == null) return false;
        File sibling = new File(parent.getCanonicalFile(), file.getName());
        return !sibling.getCanonicalFile().equals(sibling.getAbsoluteFile());
    }

    private static String relativeTo(File root, File file) {
        String base = root.getAbsolutePath();
        String full = file.getAbsolutePath();
        String relative = full.length() > base.length() ? full.substring(base.length() + 1) : "";
        return relative.replace(File.separatorChar, '/');
    }

    private static byte[] readFully(File file) throws IOException {
        try (InputStream in = new FileInputStream(file)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream((int) Math.max(32, Math.min(file.length(), LARGEST_UPLOAD_BYTES)));
            byte[] buffer = new byte[16384];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            return out.toByteArray();
        }
    }
}
