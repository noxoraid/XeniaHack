package com.termux.app.ext.filemanager;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.termux.shared.termux.TermuxConstants;

import java.io.File;

/** Storage roots and storage permission helpers (READ/WRITE_EXTERNAL_STORAGE + MANAGE_EXTERNAL_STORAGE). */
public final class StorageAccess {

    public static final int REQUEST_STORAGE = 4711;

    private StorageAccess() {}

    /** /data/data/com.termux/files/home */
    @NonNull
    public static File internalRoot() {
        return new File(TermuxConstants.TERMUX_HOME_DIR_PATH);
    }

    /** /storage/emulated/0 (shared storage). */
    @NonNull
    public static File externalRoot() {
        File dir = Environment.getExternalStorageDirectory();
        return dir != null ? dir : new File("/storage/emulated/0");
    }

    public static boolean hasExternalAccess(@NonNull Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        }
        return ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    /** Ask for access. Android 11+: "All files access" settings page; older: runtime permissions. */
    public static void requestExternalAccess(@NonNull Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + activity.getPackageName()));
                activity.startActivityForResult(intent, REQUEST_STORAGE);
            } catch (Exception e) {
                activity.startActivityForResult(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), REQUEST_STORAGE);
            }
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_STORAGE);
        }
    }

    /** Which storage root does {@code file} belong to? Null when neither. */
    public static File rootOf(@NonNull File file) {
        String p = file.getAbsolutePath();
        File internal = internalRoot(), external = externalRoot();
        if (isInside(p, internal.getAbsolutePath())) return internal;
        if (isInside(p, external.getAbsolutePath())) return external;
        return null;
    }

    private static boolean isInside(String path, String root) {
        return path.equals(root) || path.startsWith(root + "/");
    }
}
