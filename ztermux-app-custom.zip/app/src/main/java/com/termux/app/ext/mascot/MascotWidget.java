package com.termux.app.ext.mascot;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.termux.app.ext.diagnostics.TermuxErrorJournal;

import java.util.Random;

/**
 * Floating, draggable mascot with a speech bubble. Roams around its parent view on its own, greets the user and
 * changes expression when told about app events through {@link #react(MascotEvents.Event)}.
 * Fully offline and client-side.
 */
public class MascotWidget extends FrameLayout {

    private static final String[] IDLE_LINES = {
        "Need help with files?", "Psst... try the File Manager!", "I'm just hanging around.",
        "Tap me!", "Terminal time!", "Swipe from the left for sessions."
    };
    private static final String[] TAP_LINES = {
        "Hi there!", "Hehe, that tickles!", "Need help with files?", "Welcome!", "Ready when you are!"
    };
    private static final String[] DRAWER_LINES = {
        "Need help with files?", "Pick a session!", "Sessions at your service."
    };

    private static final String[] CHATTER_EN = {
        "Did you run pkg update today?", "Beep boop!", "I love a clean terminal.", "sudo make me a sandwich!",
        "Have you saved your files?", "Tab completion is your friend.", "I'm watching your prompt...",
        "Try the File Manager!", "Coffee break?", "Ctrl+C is the escape hatch."
    };
    private static final String[] CHATTER_ID = {
        "Sudah pkg update hari ini?", "Halo, lagi ngoding apa?", "Jangan lupa istirahat ya.",
        "Terminalnya keren nih!", "Sudah disimpan filenya?", "Coba buka File Manager!",
        "Aku ikut ngintip ya.", "Semangat terus!", "Ngopi dulu yuk.", "Ketik pelan-pelan, jangan buru-buru."
    };

    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final Random mRandom = new Random();
    private final MascotView mMascot;
    private final TextView mBubble;
    private final int mTouchSlop;

    private boolean mRoamingEnabled = true;
    private boolean mDragging;
    private float mDownRawX, mDownRawY, mDownTx, mDownTy;
    private boolean mGreeted;
    private boolean mSpotRestored;
    private int mBubbleToken;
    private final SharedPreferences.OnSharedPreferenceChangeListener mPrefsListener = (p, key) -> applyPrefs();
    private final Runnable mChatterRunnable = new Runnable() {
        @Override public void run() {
            chatterOnce();
            scheduleChatter();
        }
    };

    private final Runnable mHideBubble = this::hideBubble;
    private final Runnable mRoamRunnable = new Runnable() {
        @Override public void run() {
            roamOnce();
            scheduleRoam();
        }
    };

    public MascotWidget(Context context) { this(context, null); }

    public MascotWidget(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setClipChildren(false);
        setClipToPadding(false);
        mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();

        mMascot = new MascotView(context);
        addView(mMascot, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        mBubble = new TextView(context);
        mBubble.setTextColor(0xFF17181C);
        mBubble.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        mBubble.setPadding(dp(11), dp(7), dp(11), dp(7));
        mBubble.setMaxWidth(dp(190));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0x33000000);
        mBubble.setBackground(bg);
        mBubble.setElevation(dp(6));
        mBubble.setVisibility(GONE);
        mBubble.setClickable(false);

        setContentDescription("Mascot");
    }

    // ------------------------------------------------------------------ public

    public void setRoamingEnabled(boolean enabled) {
        mRoamingEnabled = enabled;
        mHandler.removeCallbacks(mRoamRunnable);
        mHandler.removeCallbacks(mChatterRunnable);
        if (enabled && isAttachedToWindow()) {
            scheduleRoam();
            scheduleChatter();
        }
    }

    /** Say hello once per widget instance. */
    public void greet() {
        if (mGreeted) return;
        mGreeted = true;
        react(MascotEvents.Event.WELCOME);
    }

    public void react(@NonNull MascotEvents.Event event) {
        switch (event) {
            case WELCOME:
                show(MascotView.Expression.HAPPY, "Welcome!", 2600);
                break;
            case DRAWER_OPENED:
                show(MascotView.Expression.CURIOUS, pick(DRAWER_LINES), 2800);
                break;
            case DRAWER_CLOSED:
                show(MascotView.Expression.WINK, null, 1400);
                break;
            case SESSION_CREATED:
                show(MascotView.Expression.HAPPY, "New session ready!", 2400);
                break;
            case SESSION_RENAMED:
                show(MascotView.Expression.WINK, "Nice name!", 2000);
                break;
            case SESSION_CLOSED:
                show(MascotView.Expression.SURPRISED, "Session closed.", 2000);
                break;
            case FILE_SAVED:
                show(MascotView.Expression.HAPPY, "File saved!", 2400);
                break;
            case FILE_OPERATION_DONE:
                show(MascotView.Expression.HAPPY, "Done!", 2000);
                break;
            case ERROR:
                show(MascotView.Expression.SAD, "Oops, that didn't work.", 2800);
                break;
            case TAPPED:
            default:
                show(MascotView.Expression.HAPPY, pick(TAP_LINES), 2200, MascotSound.Sfx.BOING);
                break;
        }
        mMascot.pulse();
    }

    /** Show a custom message with an expression. */
    public void say(@Nullable String message, @NonNull MascotView.Expression expression, long durationMs) {
        show(expression, message, durationMs);
    }

    // ----------------------------------------------------------------- lifecycle

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        MascotSettings.prefs(getContext()).registerOnSharedPreferenceChangeListener(mPrefsListener);
        applyPrefs();
        if (!MascotSettings.isSoundHidden(getContext())) MascotSound.preload(getContext());
        if (mRoamingEnabled) {
            scheduleRoam();
            scheduleChatter();
        }
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (!mSpotRestored && mRoamingEnabled && getParent() instanceof View) {
            View parent = (View) getParent();
            if (parent.getWidth() > 0 && parent.getHeight() > 0 && getWidth() > 0) {
                mSpotRestored = true;
                restoreSharedSpot(parent);
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mSpotRestored = false;
        mBubble.animate().cancel();
        MascotSettings.prefs(getContext()).unregisterOnSharedPreferenceChangeListener(mPrefsListener);
        MascotSound.stop();
        mHandler.removeCallbacksAndMessages(null);
        animate().cancel();
    }

    private void restoreSharedSpot(@NonNull View parent) {
        if (!MascotSharedSpot.isKnown()) {
            rememberSharedSpot();
            return;
        }
        float spanX = Math.max(1f, parent.getWidth() - getWidth());
        float spanY = Math.max(1f, parent.getHeight() - getHeight());
        float tx = MascotSharedSpot.fractionX() * spanX - getLeft();
        float ty = MascotSharedSpot.fractionY() * spanY - getTop();
        setTranslationX(tx);
        setTranslationY(ty);
    }

    private void rememberSharedSpot() {
        if (!(getParent() instanceof View)) return;
        View parent = (View) getParent();
        float spanX = parent.getWidth() - getWidth();
        float spanY = parent.getHeight() - getHeight();
        if (spanX <= 0 || spanY <= 0) return;
        MascotSharedSpot.remember((getLeft() + getTranslationX()) / spanX, (getTop() + getTranslationY()) / spanY);
    }

    private void rememberSharedSpotAt(float targetLeft, float targetTop) {
        if (!(getParent() instanceof View)) return;
        View parent = (View) getParent();
        float spanX = parent.getWidth() - getWidth();
        float spanY = parent.getHeight() - getHeight();
        if (spanX <= 0 || spanY <= 0) return;
        MascotSharedSpot.remember(targetLeft / spanX, targetTop / spanY);
    }

    // ----------------------------------------------------------------- bubble

    private void show(@NonNull MascotView.Expression expression, @Nullable String message, long durationMs) {
        MascotSound.Sfx sfx = message != null ? MascotSound.Sfx.POP
            : (expression == MascotView.Expression.WINK ? MascotSound.Sfx.BLINK : null);
        show(expression, message, durationMs, sfx);
    }

    private void show(@NonNull MascotView.Expression expression, @Nullable String message, long durationMs,
                      @Nullable MascotSound.Sfx sfx) {
        if (MascotSettings.isBotHidden(getContext())) return;
        mMascot.setExpression(expression, Math.max(1200, durationMs));
        if (sfx != null) sound(sfx);
        if (message == null) return;
        if (MascotSettings.isTextHidden(getContext())) return;

        try {
            mBubble.setText(message);
            if (!attachBubble()) return;
            mBubble.measure(MeasureSpec.makeMeasureSpec(dp(190), MeasureSpec.AT_MOST), MeasureSpec.UNSPECIFIED);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mBubble.getLayoutParams();
            lp.width = mBubble.getMeasuredWidth();
            lp.height = mBubble.getMeasuredHeight();
            mBubble.setLayoutParams(lp);
            placeBubble();
            mBubbleToken++;
            mBubble.animate().cancel();
            mBubble.setAlpha(0f);
            mBubble.setVisibility(VISIBLE);
            mBubble.bringToFront();
            mBubble.animate().alpha(1f).setDuration(160).start();
        } catch (RuntimeException e) {
            TermuxErrorJournal.record("mascot", "bubble failed for \"" + message + "\"", e);
            return;
        }

        mHandler.removeCallbacks(mHideBubble);
        mHandler.postDelayed(mHideBubble, durationMs);
    }

    private boolean attachBubble() {
        if (!(getParent() instanceof FrameLayout)) return false;
        FrameLayout parent = (FrameLayout) getParent();
        if (mBubble.getParent() == parent) return true;
        if (mBubble.getParent() instanceof ViewGroup) ((ViewGroup) mBubble.getParent()).removeView(mBubble);
        parent.addView(mBubble, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START));
        return true;
    }

    private void placeBubble() {
        if (!(getParent() instanceof View)) return;
        View parent = (View) getParent();
        int bw = mBubble.getMeasuredWidth(), bh = mBubble.getMeasuredHeight();
        float mascotLeft = getLeft() + getTranslationX();
        float mascotTop = getTop() + getTranslationY();
        float x = mascotLeft + (getWidth() - bw) / 2f;
        float y = mascotTop - bh - dp(6);
        if (parent.getWidth() > 0) x = Math.max(dp(6), Math.min(x, parent.getWidth() - bw - dp(6)));
        if (y < dp(4)) y = mascotTop + getHeight() + dp(6);
        mBubble.setTranslationX(x);
        mBubble.setTranslationY(y);
    }

    private void hideBubble() {
        final int token = ++mBubbleToken;
        mBubble.animate().cancel();
        mBubble.animate().alpha(0f).setDuration(200).withEndAction(() -> {
            if (token == mBubbleToken) mBubble.setVisibility(GONE);
        }).start();
    }

    // ---------------------------------------------------------- random chatter

    private void scheduleChatter() {
        mHandler.removeCallbacks(mChatterRunnable);
        mHandler.postDelayed(mChatterRunnable, 14000 + mRandom.nextInt(16000));
    }

    /** Says a random line (bubble + sound) now and then, unless hidden, dragged, or the screen is not focused. */
    private void chatterOnce() {
        if (!mRoamingEnabled || mDragging || !hasWindowFocus() || mBubble.getVisibility() == VISIBLE) return;
        if (MascotSettings.isBotHidden(getContext())) return;
        boolean indonesian = mRandom.nextBoolean();
        String line = indonesian ? pick(CHATTER_ID) : pick(CHATTER_EN);
        MascotView.Expression[] moods = {MascotView.Expression.HAPPY, MascotView.Expression.WINK, MascotView.Expression.CURIOUS};
        show(moods[mRandom.nextInt(moods.length)], line, 3400, MascotSound.Sfx.CHIRP);
        mMascot.pulse();
    }

    private void sound(@NonNull MascotSound.Sfx sfx) {
        if (MascotSettings.isSoundHidden(getContext()) || MascotSettings.isBotHidden(getContext())) return;
        MascotSound.play(getContext(), sfx);
    }

    /** Applies the hide-bot switch immediately (also when changed from Custom Settings v2). */
    private void applyPrefs() {
        boolean hidden = MascotSettings.isBotHidden(getContext());
        setVisibility(hidden ? GONE : VISIBLE);
        if (hidden) {
            MascotSound.stop();
            mBubble.setVisibility(GONE);
        }
    }

    // ----------------------------------------------------------------- roaming

    private void scheduleRoam() {
        mHandler.removeCallbacks(mRoamRunnable);
        mHandler.postDelayed(mRoamRunnable, 6000 + mRandom.nextInt(5000));
    }

    private void roamOnce() {
        if (mDragging || mBubble.getVisibility() == VISIBLE || !(getParent() instanceof View)) return;
        View parent = (View) getParent();
        int pw = parent.getWidth(), ph = parent.getHeight();
        if (pw <= 0 || ph <= 0 || getWidth() <= 0) return;

        final int m = dp(8);
        float maxX = Math.max(m, pw - getWidth() - m);
        float maxY = Math.max(m, ph - getHeight() - m);
        float targetLeft = m + mRandom.nextFloat() * (maxX - m);
        float targetTop = m + mRandom.nextFloat() * (maxY - m);

        float tx = targetLeft - getLeft();
        float ty = targetTop - getTop();
        float dx = tx - getTranslationX(), dy = ty - getTranslationY();
        float dist = (float) Math.hypot(dx, dy);
        if (dist < dp(40)) return;

        mMascot.lookTo(dx / dist, dy / dist, 1400);
        rememberSharedSpotAt(targetLeft, targetTop);
        sound(MascotSound.Sfx.SWOOSH);
        animate().translationX(tx).translationY(ty)
            .setDuration(Math.min(2600, 900 + (long) (dist * 1.2f)))
            .setInterpolator(new AccelerateDecelerateInterpolator())
            .withEndAction(() -> {
                if (mRandom.nextInt(4) == 0 && mBubble.getVisibility() != VISIBLE)
                    show(MascotView.Expression.HAPPY, pick(IDLE_LINES), 2600, MascotSound.Sfx.CHIRP);
            }).start();
    }

    // ------------------------------------------------------------------- touch

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        View parent = getParent() instanceof View ? (View) getParent() : null;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                animate().cancel();
                if (mRoamingEnabled) rememberSharedSpot();
                mDownRawX = event.getRawX();
                mDownRawY = event.getRawY();
                mDownTx = getTranslationX();
                mDownTy = getTranslationY();
                mDragging = false;
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = event.getRawX() - mDownRawX, dy = event.getRawY() - mDownRawY;
                if (!mDragging && Math.hypot(dx, dy) > mTouchSlop) {
                    mDragging = true;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    mMascot.setExpression(MascotView.Expression.SURPRISED, 0);
                }
                if (mDragging && parent != null) {
                    float tx = mDownTx + dx, ty = mDownTy + dy;
                    tx = Math.max(-getLeft(), Math.min(tx, parent.getWidth() - getWidth() - getLeft()));
                    ty = Math.max(-getTop(), Math.min(ty, parent.getHeight() - getHeight() - getTop()));
                    setTranslationX(tx);
                    setTranslationY(ty);
                    if (mBubble.getVisibility() == VISIBLE && mBubble.getParent() == getParent()) placeBubble();
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
                if (mDragging) {
                    mMascot.setExpression(MascotView.Expression.HAPPY, 1200);
                    if (mRoamingEnabled) rememberSharedSpot();
                    sound(MascotSound.Sfx.POP);
                } else {
                    performClick();
                    react(MascotEvents.Event.TAPPED);
                }
                mDragging = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                mDragging = false;
                mMascot.setExpression(MascotView.Expression.NEUTRAL, 0);
                return true;
            default:
                return super.onTouchEvent(event);
        }
    }

    @Override
    public boolean performClick() { return super.performClick(); }

    // ----------------------------------------------------------------- helpers

    private String pick(String[] lines) { return lines[mRandom.nextInt(lines.length)]; }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }
}
