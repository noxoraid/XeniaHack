package com.termux.app.ext.github;

import androidx.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public final class GithubRestClient {

    private static final String API_ROOT = "https://api.github.com";

    private final String mToken;

    public GithubRestClient(@NonNull String token) {
        mToken = token.trim();
    }

    @NonNull
    public static String encodeSegment(@NonNull String segment) {
        try {
            return URLEncoder.encode(segment, "UTF-8").replace("+", "%20");
        } catch (java.io.UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    @NonNull
    public static String encodePath(@NonNull String path) {
        StringBuilder out = new StringBuilder();
        for (String part : path.split("/")) {
            if (part.isEmpty()) continue;
            if (out.length() > 0) out.append('/');
            out.append(encodeSegment(part));
        }
        return out.toString();
    }

    @NonNull
    public JSONObject getObject(@NonNull String path) throws IOException {
        return parseObject(request("GET", path, null));
    }

    @NonNull
    public JSONArray getArray(@NonNull String path) throws IOException {
        try {
            return new JSONArray(request("GET", path, null));
        } catch (JSONException e) {
            throw new IOException("Unexpected response from GitHub");
        }
    }

    @NonNull
    public JSONObject post(@NonNull String path, @NonNull JSONObject body) throws IOException {
        return parseObject(request("POST", path, body));
    }

    @NonNull
    public JSONObject put(@NonNull String path, @NonNull JSONObject body) throws IOException {
        return parseObject(request("PUT", path, body));
    }

    @NonNull
    public JSONObject patch(@NonNull String path, @NonNull JSONObject body) throws IOException {
        return parseObject(request("PATCH", path, body));
    }

    @NonNull
    public InputStream openDownload(@NonNull String path) throws IOException {
        HttpURLConnection first = open("GET", API_ROOT + path, true);
        first.setInstanceFollowRedirects(false);
        int code = first.getResponseCode();
        if (code >= 300 && code < 400) {
            String location = first.getHeaderField("Location");
            first.disconnect();
            if (location == null) throw new IOException("GitHub redirected without a location");
            HttpURLConnection second = open("GET", location, false);
            int secondCode = second.getResponseCode();
            if (secondCode >= 400) {
                String text = readAll(second.getErrorStream());
                second.disconnect();
                throw new GithubApiException(secondCode, describeFailure(secondCode, text));
            }
            return second.getInputStream();
        }
        if (code >= 400) {
            String text = readAll(first.getErrorStream());
            first.disconnect();
            throw new GithubApiException(code, describeFailure(code, text));
        }
        return first.getInputStream();
    }

    @NonNull
    public JSONObject whoAmI() throws IOException {
        return getObject("/user");
    }

    private String request(String method, String path, JSONObject body) throws IOException {
        HttpURLConnection connection = open(method, API_ROOT + path, true);
        try {
            if (body != null) {
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = connection.getOutputStream()) {
                    out.write(bytes);
                }
            }
            int code = connection.getResponseCode();
            String text = readAll(code < 400 ? connection.getInputStream() : connection.getErrorStream());
            if (code >= 400) throw new GithubApiException(code, describeFailure(code, text));
            return text;
        } finally {
            connection.disconnect();
        }
    }

    private HttpURLConnection open(String method, String url, boolean authorized) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(90000);
        connection.setRequestProperty("Accept", "application/vnd.github+json");
        connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        connection.setRequestProperty("User-Agent", "Noxora-Termux");
        if (authorized) connection.setRequestProperty("Authorization", "Bearer " + mToken);
        return connection;
    }

    private static JSONObject parseObject(String text) throws IOException {
        try {
            return text.isEmpty() ? new JSONObject() : new JSONObject(text);
        } catch (JSONException e) {
            throw new IOException("Unexpected response from GitHub");
        }
    }

    private static String describeFailure(int code, String text) {
        String message = null;
        try {
            message = new JSONObject(text).optString("message", null);
        } catch (JSONException ignored) {
            message = null;
        }
        if (code == 401) return "Token rejected (401). Check the token or its expiry.";
        if (code == 403 && message != null && message.toLowerCase().contains("rate limit")) return "GitHub rate limit reached. Try again later.";
        return "HTTP " + code + (message != null ? ": " + message : "");
    }

    private static String readAll(InputStream stream) throws IOException {
        if (stream == null) return "";
        try (InputStream in = stream) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[16384];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
