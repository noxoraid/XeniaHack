package com.termux.app.ext.task;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Process-wide list of background tasks (downloads, uploads, file jobs).
 * Tasks live here, not in an Activity, and a foreground service keeps the process alive,
 * so leaving a screen or closing the app does not stop them.
 */
public final class TaskCenter {

    public enum State { RUNNING, DONE, FAILED, CANCELLED, NEEDS_ACTION, INTERRUPTED }

    public interface Job { void run(@NonNull TaskHandle handle) throws IOException; }

    /** Called on the main thread when a task has finished (success, failure, cancel or needs-action). */
    public interface Done { void onDone(@NonNull TaskItem item); }

    public interface Listener { void onTasksChanged(); }

    public static final class TaskItem {
        public final String id;
        public final String type;
        public final String title;
        @Nullable public final String gotoUri;
        public final boolean cancellable;
        public final long startedAt;
        public volatile long finishedAt;
        public volatile State state = State.RUNNING;
        public volatile String status = "Starting…";
        public volatile int percent = -1;
        volatile boolean cancelRequested;
        private final ArrayList<String> log = new ArrayList<>();

        TaskItem(String id, String type, String title, @Nullable String gotoUri, boolean cancellable, long startedAt) {
            this.id = id; this.type = type; this.title = title; this.gotoUri = gotoUri;
            this.cancellable = cancellable; this.startedAt = startedAt;
        }

        public boolean running() { return state == State.RUNNING; }

        synchronized void addLog(String line) {
            log.add(line);
            while (log.size() > 400) log.remove(0);
        }

        @NonNull
        public synchronized String logText() {
            StringBuilder out = new StringBuilder();
            for (String line : log) out.append(line).append('\n');
            return out.toString();
        }
    }

    public static final class TaskHandle {
        private final TaskItem item;
        private volatile State forced;

        TaskHandle(TaskItem item) { this.item = item; }

        public void log(@NonNull String line) { item.addLog(line); item.status = lastLine(line, item.status); changed(); }

        public void progress(int percent, @NonNull String status) { item.percent = percent; item.status = status; changed(); }

        public boolean isCancelled() { return item.cancelRequested; }

        /** The job finished but the user has to do something (token, name…); the task keeps this message. */
        public void needsAction(@NonNull String message) { forced = State.NEEDS_ACTION; item.status = message; item.addLog("⚠ " + message); }

        private static String lastLine(String line, String fallback) {
            String t = line.trim();
            return t.isEmpty() ? fallback : t;
        }
    }

    private static final String PREFS = "task_center";
    private static final String KEY_LIST = "list";
    private static final int KEEP = 60;

    private static final List<TaskItem> sItems = new ArrayList<>();
    private static final CopyOnWriteArrayList<Listener> sListeners = new CopyOnWriteArrayList<>();
    private static final ThreadLocal<TaskHandle> sCurrent = new ThreadLocal<>();
    private static final ExecutorService sPool = Executors.newCachedThreadPool();
    private static final Handler sMain = new Handler(Looper.getMainLooper());
    private static final AtomicBoolean sPending = new AtomicBoolean();
    private static Context sContext;

    private TaskCenter() {}

    /** Call from Application.onCreate. Tasks that were running when the process died become INTERRUPTED. */
    public static synchronized void init(@NonNull Context context) {
        if (sContext != null) return;
        sContext = context.getApplicationContext();
        try {
            String raw = prefs().getString(KEY_LIST, "[]");
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                TaskItem item = new TaskItem(o.getString("id"), o.optString("type"), o.optString("title"),
                    o.has("goto") ? o.optString("goto") : null, o.optBoolean("cancellable"), o.optLong("start"));
                item.finishedAt = o.optLong("end");
                State saved = State.valueOf(o.optString("state", "DONE"));
                item.state = saved == State.RUNNING ? State.INTERRUPTED : saved;
                item.status = saved == State.RUNNING ? "Stopped when the app was closed" : o.optString("status");
                item.percent = o.optInt("percent", -1);
                JSONArray lines = o.optJSONArray("log");
                for (int j = 0; lines != null && j < lines.length(); j++) item.addLog(lines.optString(j));
                sItems.add(item);
            }
        } catch (Exception ignored) {
            sItems.clear();
        }
    }

    @Nullable
    public static TaskHandle current() { return sCurrent.get(); }

    public static void addListener(@NonNull Listener l) { sListeners.addIfAbsent(l); }

    public static void removeListener(@NonNull Listener l) { sListeners.remove(l); }

    @NonNull
    public static synchronized List<TaskItem> snapshot() {
        List<TaskItem> copy = new ArrayList<>(sItems);
        java.util.Collections.reverse(copy);
        return copy;
    }

    public static synchronized int runningCount() {
        int n = 0;
        for (TaskItem i : sItems) if (i.running()) n++;
        return n;
    }

    @Nullable
    public static synchronized TaskItem firstRunning() {
        for (int i = sItems.size() - 1; i >= 0; i--) if (sItems.get(i).running()) return sItems.get(i);
        return null;
    }

    public static void cancel(@NonNull TaskItem item) {
        if (item.running() && item.cancellable) {
            item.cancelRequested = true;
            item.status = "Cancelling…";
            changed();
        }
    }

    public static synchronized void remove(@NonNull TaskItem item) {
        if (item.running()) return;
        sItems.remove(item);
        persist();
        changed();
    }

    public static synchronized void clearFinished() {
        List<TaskItem> keep = new ArrayList<>();
        for (TaskItem i : sItems) if (i.running()) keep.add(i);
        sItems.clear();
        sItems.addAll(keep);
        persist();
        changed();
    }

    /**
     * Starts a background task. {@code goTo} is the screen the "Go to" button opens.
     * Runs on a pool thread; {@code done} (optional) runs on the main thread afterwards.
     */
    @NonNull
    public static TaskItem submit(@NonNull Context context, @NonNull String type, @NonNull String title,
                                  @Nullable Intent goTo, boolean cancellable, @NonNull Job job, @Nullable Done done) {
        init(context);
        final TaskItem item = new TaskItem(UUID.randomUUID().toString(), type, title,
            goTo == null ? null : goTo.toUri(Intent.URI_INTENT_SCHEME), cancellable, System.currentTimeMillis());
        synchronized (TaskCenter.class) {
            sItems.add(item);
            while (sItems.size() > KEEP) {
                int drop = -1;
                for (int i = 0; i < sItems.size(); i++) if (!sItems.get(i).running()) { drop = i; break; }
                if (drop < 0) break;
                sItems.remove(drop);
            }
            persist();
        }
        TaskService.ensureRunning(sContext);
        changed();
        sPool.execute(() -> {
            TaskHandle handle = new TaskHandle(item);
            sCurrent.set(handle);
            State end = State.DONE;
            try {
                job.run(handle);
                if (handle.forced != null) end = handle.forced;
                else if (item.cancelRequested) end = State.CANCELLED;
                else item.status = "Done";
            } catch (IOException | RuntimeException e) {
                String message = e.getMessage() != null ? e.getMessage() : e.toString();
                if (item.cancelRequested) { end = State.CANCELLED; item.status = "Cancelled"; }
                else { end = State.FAILED; item.status = message; item.addLog("✗ " + message); }
            } finally {
                sCurrent.remove();
            }
            if (end == State.DONE) item.percent = 100;
            item.finishedAt = System.currentTimeMillis();
            item.state = end;
            synchronized (TaskCenter.class) { persist(); }
            TaskService.notifyFinished(sContext, item);
            changed();
            if (done != null) sMain.post(() -> done.onDone(item));
        });
        return item;
    }

    private static SharedPreferences prefs() {
        return sContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static void persist() {
        if (sContext == null) return;
        try {
            JSONArray array = new JSONArray();
            for (TaskItem i : sItems) {
                JSONObject o = new JSONObject();
                o.put("id", i.id); o.put("type", i.type); o.put("title", i.title);
                if (i.gotoUri != null) o.put("goto", i.gotoUri);
                o.put("cancellable", i.cancellable); o.put("start", i.startedAt); o.put("end", i.finishedAt);
                o.put("state", i.state.name()); o.put("status", i.status); o.put("percent", i.percent);
                JSONArray lines = new JSONArray();
                String[] all = i.logText().split("\n");
                for (int k = Math.max(0, all.length - 80); k < all.length; k++) lines.put(all[k]);
                o.put("log", lines);
                array.put(o);
            }
            prefs().edit().putString(KEY_LIST, array.toString()).apply();
        } catch (Exception ignored) {
            return;
        }
    }

    static void changed() {
        if (!sPending.compareAndSet(false, true)) return;
        sMain.postDelayed(() -> {
            sPending.set(false);
            for (Listener l : sListeners) l.onTasksChanged();
        }, 150);
    }
}
