package com.termux.app.ext.diagnostics;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.termux.shared.termux.TermuxConstants;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Logs are split by where they come from so they never get mixed up:
 *   ~/logs/terminal-home/         main terminal (sessions, crashes)
 *   ~/logs/terminal-filemanager/  file manager + its GitHub console
 */
public final class TermuxErrorJournal {

    public static final String SCOPE_HOME = "terminal-home";
    public static final String SCOPE_FILEMANAGER = "terminal-filemanager";

    private static final long LARGEST_JOURNAL_BYTES = 512L * 1024L;

    private TermuxErrorJournal() {}

    @NonNull
    public static String scopeFor(@NonNull String source) {
        String s = source.toLowerCase(Locale.ROOT);
        if (s.startsWith("filemanager") || s.startsWith("github") || s.startsWith("editor")) return SCOPE_FILEMANAGER;
        return SCOPE_HOME;
    }

    @NonNull
    public static File logDir(@NonNull String scope) {
        File dir = new File(new File(TermuxConstants.TERMUX_HOME_DIR_PATH, "logs"), scope);
        if (!dir.isDirectory() && dir.mkdirs()) writeReadme(dir.getParentFile());
        return dir;
    }

    @NonNull
    public static String logPathHint(@NonNull String source) {
        return "~/logs/" + scopeFor(source) + "/";
    }

    public static synchronized void record(@NonNull String source, @NonNull String message, @Nullable Throwable error) {
        write(source, message, error);
    }

    /** Plain line (no stack trace), used to mirror the GitHub console into a file. */
    public static synchronized void note(@NonNull String source, @NonNull String line) {
        write(source, line, null);
    }

    private static void write(String source, String message, @Nullable Throwable error) {
        try {
            Date now = new Date();
            SimpleDateFormat dayFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            SimpleDateFormat clockFormat = new SimpleDateFormat("HH:mm:ss", Locale.US);
            TimeZone asia = com.termux.shared.android.AppTimeZone.zone();
            dayFormat.setTimeZone(asia);
            clockFormat.setTimeZone(asia);
            String scope = scopeFor(source);
            File journal = new File(logDir(scope), source + "_" + dayFormat.format(now) + ".txt");
            if (journal.length() > LARGEST_JOURNAL_BYTES) return;
            try (PrintWriter out = new PrintWriter(new FileWriter(journal, true))) {
                out.println("[" + clockFormat.format(now) + " " + com.termux.shared.android.AppTimeZone.shortName() + "][" + scope + "] " + message);
                if (error != null) {
                    StringWriter trace = new StringWriter();
                    error.printStackTrace(new PrintWriter(trace));
                    out.println(trace);
                }
            }
        } catch (IOException | RuntimeException ignored) {
            return;
        }
    }

    private static void writeReadme(@Nullable File logsRoot) {
        if (logsRoot == null) return;
        try (PrintWriter out = new PrintWriter(new FileWriter(new File(logsRoot, "README.txt"), false))) {
            out.println("terminal-home/         logs from the MAIN terminal (home screen, sessions, crashes)");
            out.println("terminal-filemanager/  logs from the FILE MANAGER terminal (GitHub console, file operations)");
            out.println("A file you do not see in one place lives in the other folder.");
        } catch (IOException ignored) {
            return;
        }
    }
}
