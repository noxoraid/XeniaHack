package com.termux.app.ext.terminal;

import android.content.Context;

import androidx.annotation.NonNull;

import com.termux.app.ext.mascot.MascotSettings;

public final class TerminalReadLock {

    public static final String KEY_READ_LOCK = "terminal_read_lock";

    private static volatile boolean sLocked;

    private TerminalReadLock() {}

    public static void load(@NonNull Context context) {
        sLocked = MascotSettings.prefs(context).getBoolean(KEY_READ_LOCK, false);
    }

    public static boolean isOn() {
        return sLocked;
    }

    public static void set(@NonNull Context context, boolean locked) {
        sLocked = locked;
        MascotSettings.set(context, KEY_READ_LOCK, locked);
    }
}
