package com.termux.app.ext.filemanager;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButtonToggleGroup;
import com.termux.R;
import com.termux.app.ext.diagnostics.TermuxErrorJournal;
import com.termux.app.ext.task.TaskCenter;
import com.termux.app.ext.task.TaskPanel;
import com.termux.app.ext.task.TimeZoneDialog;
import com.termux.app.ext.editor.EditorActivity;
import com.termux.app.ext.github.GithubHubActivity;
import com.termux.app.ext.mascot.MascotEvents;
import com.termux.app.ext.mascot.MascotWidget;
import com.termux.app.ext.ui.CustomDialogs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Light-themed GUI file manager for the two storages Termux users care about:
 * the Termux home (/data/data/com.termux/files/home) and shared storage (/storage/emulated/0).
 */
public class FileManagerActivity extends AppCompatActivity implements FileAdapter.Listener {

    private static final String JOURNAL_NAME = "filemanager";

    private final ExecutorService mIo = Executors.newSingleThreadExecutor();

    private File mInternalRoot, mExternalRoot;
    private File mInternalDir, mExternalDir;
    private boolean mExternal;           // which storage tab is active
    private boolean mShowHidden = true;  // Termux home is full of dotfiles
    private volatile boolean mBusy;

    // Pending Copy / Move (paste bar)
    private final List<File> mClipboard = new ArrayList<>();
    private boolean mClipboardMove;

    private FileAdapter mAdapter;
    private ListView mList;
    private TextView mPath, mEmpty, mSelCount, mPasteLabel;
    private View mTopBar, mSelectionBar, mNoAccess, mPasteBar;
    private MascotWidget mMascot;
    private TextView mGithubButton;
    private TaskPanel mTaskPanel;
    private boolean mTaskTab;

    public static final String EXTRA_PATH = "com.termux.app.ext.filemanager.EXTRA_PATH";
    public static final String EXTRA_OPEN_TASKS = "com.termux.app.ext.filemanager.EXTRA_OPEN_TASKS";

    @NonNull
    public static android.content.Intent intentFor(@NonNull android.content.Context context, @NonNull File dir) {
        return new android.content.Intent(context, FileManagerActivity.class).putExtra(EXTRA_PATH, dir.getAbsolutePath());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_manager);

        mInternalRoot = StorageAccess.internalRoot();
        mExternalRoot = StorageAccess.externalRoot();
        mInternalDir = mInternalRoot;
        mExternalDir = mExternalRoot;

        mList = findViewById(R.id.fm_list);
        mPath = findViewById(R.id.fm_path);
        mEmpty = findViewById(R.id.fm_empty);
        mSelCount = findViewById(R.id.fm_sel_count);
        mPasteLabel = findViewById(R.id.fm_paste_label);
        mTopBar = findViewById(R.id.fm_top_bar);
        mSelectionBar = findViewById(R.id.fm_selection_bar);
        mNoAccess = findViewById(R.id.fm_no_access);
        mPasteBar = findViewById(R.id.fm_paste_bar);
        mMascot = findViewById(R.id.fm_mascot);

        mAdapter = new FileAdapter(this, this);
        mList.setAdapter(mAdapter);
        final GestureDetector tapDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapUp(MotionEvent e) { handleListTap(e, false); return false; }
            @Override public void onLongPress(MotionEvent e) { handleListTap(e, true); }
        });
        mList.setOnTouchListener((v, event) -> {
            tapDetector.onTouchEvent(event);
            return false;
        });
        TermuxErrorJournal.record(JOURNAL_NAME, "opened sdk=" + Build.VERSION.SDK_INT + " model=" + Build.MODEL, null);
        findViewById(R.id.fm_back).setOnClickListener(v -> finish());
        findViewById(R.id.fm_top_more).setOnClickListener(v -> showTopMenu());
        findViewById(R.id.fm_up).setOnClickListener(v -> navigateUp());
        mGithubButton = findViewById(R.id.fm_github);
        mGithubButton.setOnClickListener(v -> openGithubHub());
        findViewById(R.id.fm_grant_access).setOnClickListener(v -> StorageAccess.requestExternalAccess(this));
        findViewById(R.id.fm_paste_cancel).setOnClickListener(v -> clearClipboard());
        findViewById(R.id.fm_paste_here).setOnClickListener(v -> pasteHere());

        findViewById(R.id.fm_sel_close).setOnClickListener(v -> exitSelectionMode());
        findViewById(R.id.fm_sel_all).setOnClickListener(v -> {
            if (mAdapter.allSelected()) mAdapter.unselectAll(); else mAdapter.selectAll();
            updateSelectionBar();
        });
        findViewById(R.id.fm_sel_copy).setOnClickListener(v -> startClipboard(selectedFiles(), false));
        findViewById(R.id.fm_sel_delete).setOnClickListener(v -> confirmDelete(selectedFiles()));
        findViewById(R.id.fm_sel_more).setOnClickListener(v -> showSelectionMenu());

        MaterialButtonToggleGroup toggle = findViewById(R.id.fm_storage_toggle);
        toggle.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            exitSelectionMode();
            if (checkedId == R.id.fm_tab_task) { showTaskTab(true); return; }
            showTaskTab(false);
            mExternal = checkedId == R.id.fm_tab_external;
            reload();
        });
        mTaskPanel = new TaskPanel(this);
        ((android.view.ViewGroup) mList.getParent()).addView(mTaskPanel,
            new android.widget.FrameLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
        mTaskPanel.setVisibility(View.GONE);
        toggle.check(R.id.fm_tab_internal);

        String startPath = getIntent().getStringExtra(EXTRA_PATH);
        if (startPath != null) {
            File start = new File(startPath);
            if (start.isDirectory()) {
                if (isInside(start, mExternalRoot)) { mExternalDir = start; toggle.check(R.id.fm_tab_external); }
                else if (isInside(start, mInternalRoot)) { mInternalDir = start; reload(); }
            }
        }
        if (getIntent().getBooleanExtra(EXTRA_OPEN_TASKS, false)) toggle.check(R.id.fm_tab_task);

        mList.post(() -> mMascot.greet());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Returning from the "All files access" settings page or after the editor saved something.
        if (mExternal) reload();
        else if (currentDir().exists()) reload();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mIo.shutdownNow();
    }

    @Override
    public void onBackPressed() {
        if (mAdapter.isSelectionMode()) { exitSelectionMode(); return; }
        if (!currentDir().equals(currentRoot())) { navigateUp(); return; }
        super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == StorageAccess.REQUEST_STORAGE) reload();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == StorageAccess.REQUEST_STORAGE) reload();
    }

    // ------------------------------------------------------------ navigation

    private File currentRoot() { return mExternal ? mExternalRoot : mInternalRoot; }
    private File currentDir() { return mExternal ? mExternalDir : mInternalDir; }

    private void setCurrentDir(File dir) {
        if (mExternal) mExternalDir = dir; else mInternalDir = dir;
    }

    private void navigateUp() {
        File dir = currentDir();
        if (dir.equals(currentRoot())) return;
        File parent = dir.getParentFile();
        if (parent != null) {
            setCurrentDir(parent);
            exitSelectionMode();
            reload();
        }
    }

    private void onEntryClicked(@NonNull FileEntry entry) {
        if (mAdapter.isSelectionMode()) {
            mAdapter.toggle(entry);
            if (mAdapter.selectedCount() == 0) exitSelectionMode(); else updateSelectionBar();
            return;
        }
        if (entry.directory) {
            // Check first, so an unreadable folder (e.g. Android/data on Android 11+) doesn't leave us in an empty screen.
            if (!entry.file.canRead() || entry.file.list() == null) {
                TermuxErrorJournal.record(JOURNAL_NAME, "cannot open folder " + entry.file.getAbsolutePath()
                    + " exists=" + entry.file.exists() + " canRead=" + entry.file.canRead(), null);
                Toast.makeText(this, "Can't open this folder (no permission)", Toast.LENGTH_SHORT).show();
                return;
            }
            setCurrentDir(entry.file);
            exitSelectionMode();
            reload();
            mList.setSelection(0);
        } else {
            openInEditor(entry.file);
        }
    }

    private void openInEditor(@NonNull File file) {
        if (file.length() > EditorActivity.MAX_EDIT_BYTES) {
            TermuxErrorJournal.record(JOURNAL_NAME, "file too large to edit " + file.getAbsolutePath() + " size=" + file.length(), null);
            Toast.makeText(this, "File is too large to edit (max 2 MB)", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!FileOps.isEditableText(file, EditorActivity.MAX_EDIT_BYTES)) {
            TermuxErrorJournal.record(JOURNAL_NAME, "file rejected as binary " + file.getAbsolutePath(), null);
            Toast.makeText(this, "This looks like a binary file and can't be edited", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            startActivity(EditorActivity.intentFor(this, file));
        } catch (RuntimeException e) {
            TermuxErrorJournal.record(JOURNAL_NAME, "editor failed to start for " + file.getAbsolutePath(), e);
            Toast.makeText(this, "Cannot open the editor, see " + TermuxErrorJournal.logPathHint(JOURNAL_NAME), Toast.LENGTH_LONG).show();
        }
    }

    // ---------------------------------------------------------------- loading

    private void showTaskTab(boolean on) {
        mTaskTab = on;
        mTaskPanel.setVisibility(on ? View.VISIBLE : View.GONE);
        mList.setVisibility(on ? View.GONE : View.VISIBLE);
        ((View) mPath.getParent()).setVisibility(on ? View.GONE : View.VISIBLE);
        if (on) {
            mEmpty.setVisibility(View.GONE);
            mNoAccess.setVisibility(View.GONE);
            mGithubButton.setVisibility(View.GONE);
        }
    }

    private void reload() {
        if (mTaskTab) return;
        final File dir = currentDir();
        mPath.setText(dir.getAbsolutePath());
        updateGithubButton();

        if (mExternal && !StorageAccess.hasExternalAccess(this)) {
            mNoAccess.setVisibility(View.VISIBLE);
            mEmpty.setVisibility(View.GONE);
            mAdapter.setItems(Collections.emptyList());
            return;
        }
        mNoAccess.setVisibility(View.GONE);

        final boolean showHidden = mShowHidden;
        mIo.execute(() -> {
            final File[] files;
            try {
                files = dir.listFiles();
            } catch (RuntimeException e) {
                TermuxErrorJournal.record(JOURNAL_NAME, "listing crashed for " + dir.getAbsolutePath(), e);
                return;
            }
            if (files == null) {
                TermuxErrorJournal.record(JOURNAL_NAME, "listFiles returned null for " + dir.getAbsolutePath()
                    + " exists=" + dir.exists() + " canRead=" + dir.canRead(), null);
            }
            final List<FileEntry> entries = new ArrayList<>();
            if (files != null) {
                for (File f : files) {
                    if (!showHidden && f.getName().startsWith(".")) continue;
                    entries.add(new FileEntry(f));
                }
                Collections.sort(entries, (a, b) -> {
                    if (a.directory != b.directory) return a.directory ? -1 : 1;
                    return a.name().toLowerCase(Locale.ROOT).compareTo(b.name().toLowerCase(Locale.ROOT));
                });
            }
            final boolean unreadable = files == null;
            runOnUiThread(() -> {
                if (isFinishing() || !dir.equals(currentDir())) return;
                mAdapter.setItems(entries);
                mEmpty.setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
                if (unreadable) Toast.makeText(this, "Cannot read this folder", Toast.LENGTH_SHORT).show();
                if (mAdapter.isSelectionMode()) updateSelectionBar();
            });
        });
    }

    // -------------------------------------------------------------- selection

    private void enterSelectionMode() {
        mAdapter.setSelectionMode(true);
        mTopBar.setVisibility(View.GONE);
        mSelectionBar.setVisibility(View.VISIBLE);
        updateSelectionBar();
    }

    private void exitSelectionMode() {
        mAdapter.setSelectionMode(false);
        mSelectionBar.setVisibility(View.GONE);
        mTopBar.setVisibility(View.VISIBLE);
    }

    private void updateSelectionBar() {
        mSelCount.setText(getString(R.string.fm_selected_count, mAdapter.selectedCount()));
    }

    @NonNull
    private List<File> selectedFiles() {
        List<File> out = new ArrayList<>();
        for (FileEntry e : mAdapter.getSelected()) out.add(e.file);
        return out;
    }

    // ------------------------------------------------------------------ menus

    private void showTopMenu() {
        final List<Runnable> actions = new ArrayList<>();
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_select), R.drawable.ic_check));
        actions.add(() -> { enterSelectionMode(); updateSelectionBar(); });
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_select_all), R.drawable.ic_select_all));
        actions.add(() -> { enterSelectionMode(); mAdapter.selectAll(); updateSelectionBar(); });
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_new_folder), R.drawable.ic_folder));
        actions.add(() -> promptCreate(true));
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_new_file), R.drawable.ic_file));
        actions.add(() -> promptCreate(false));
        entries.add(new CustomDialogs.MenuEntry(getString(mShowHidden ? R.string.fm_hide_hidden : R.string.fm_show_hidden), R.drawable.ic_select_all));
        actions.add(() -> { mShowHidden = !mShowHidden; reload(); });
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_refresh), R.drawable.ic_sync));
        actions.add(this::reload);
        entries.add(new CustomDialogs.MenuEntry("Time zone · " + com.termux.shared.android.AppTimeZone.shortName(), R.drawable.ic_info_outline_black_24dp));
        actions.add(() -> TimeZoneDialog.show(this, this::reload));
        CustomDialogs.menu(this, true, getString(R.string.fm_title), entries, index -> actions.get(index).run());
    }

    private void showSelectionMenu() {
        final List<File> files = selectedFiles();
        final List<Runnable> actions = new ArrayList<>();
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();

        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_select_all), R.drawable.ic_select_all));
        actions.add(() -> { mAdapter.selectAll(); updateSelectionBar(); });
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_unselect_all), R.drawable.ic_close));
        actions.add(() -> { mAdapter.unselectAll(); updateSelectionBar(); });

        if (!files.isEmpty()) {
            entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_move), R.drawable.ic_arrow_up));
            actions.add(() -> startClipboard(files, true));
            if (files.size() == 1) {
                entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_rename), R.drawable.ic_edit));
                actions.add(() -> promptRename(files.get(0)));
            }
            entries.add(crossStorageEntry(files.get(0)));
            actions.add(() -> copyToOtherStorage(files));
        }
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_done), R.drawable.ic_check));
        actions.add(this::exitSelectionMode);

        CustomDialogs.menu(this, true, getString(R.string.fm_selected_count, files.size()), entries,
            index -> actions.get(index).run());
    }

    private void handleListTap(@NonNull MotionEvent event, boolean longPress) {
        try {
            int position = mList.pointToPosition((int) event.getX(), (int) event.getY());
            if (position == AdapterView.INVALID_POSITION || position >= mAdapter.getCount()) {
                TermuxErrorJournal.record(JOURNAL_NAME, "tap hit no row at x=" + event.getX() + " y=" + event.getY()
                    + " rows=" + mAdapter.getCount(), null);
                return;
            }
            FileEntry entry = mAdapter.getItem(position);
            if (longPress) {
                if (mAdapter.isSelectionMode()) return;
                enterSelectionMode();
                mAdapter.select(entry);
                updateSelectionBar();
            } else {
                onEntryClicked(entry);
            }
        } catch (RuntimeException e) {
            TermuxErrorJournal.record(JOURNAL_NAME, "tap handling crashed in " + currentDir().getAbsolutePath(), e);
            Toast.makeText(this, "Tap failed, see " + TermuxErrorJournal.logPathHint(JOURNAL_NAME), Toast.LENGTH_LONG).show();
        }
    }

    private void openGithubHub() {
        File dir = currentDir();
        if (dir.equals(currentRoot())) return;
        startActivity(GithubHubActivity.intentFor(this, dir));
    }

    private void updateGithubButton() {
        if (mTaskTab) { mGithubButton.setVisibility(View.GONE); return; }
        File dir = currentDir();
        boolean inside = !dir.equals(currentRoot());
        mGithubButton.setVisibility(inside ? View.VISIBLE : View.GONE);
        if (inside) mGithubButton.setText(getString(R.string.fm_github) + " · " + dir.getName());
    }

    @Override
    public void onMoreClicked(@NonNull FileEntry entry) {
        final File file = entry.file;
        final List<File> single = Collections.singletonList(file);
        final List<Runnable> actions = new ArrayList<>();
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();

        if (!entry.directory && FileOps.isEditableText(file, EditorActivity.MAX_EDIT_BYTES)) {
            entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_open_editor), R.drawable.ic_edit));
            actions.add(() -> openInEditor(file));
        }
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_copy), R.drawable.ic_copy));
        actions.add(() -> startClipboard(single, false));
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_move), R.drawable.ic_arrow_up));
        actions.add(() -> startClipboard(single, true));
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_rename), R.drawable.ic_edit));
        actions.add(() -> promptRename(file));
        entries.add(crossStorageEntry(file));
        actions.add(() -> copyToOtherStorage(single));
        entries.add(new CustomDialogs.MenuEntry(getString(R.string.fm_delete), R.drawable.ic_delete, true));
        actions.add(() -> confirmDelete(single));

        CustomDialogs.menu(this, true, entry.name(), entries, index -> actions.get(index).run());
    }

    private CustomDialogs.MenuEntry crossStorageEntry(File file) {
        boolean inInternal = isInside(file, mInternalRoot);
        return new CustomDialogs.MenuEntry(getString(inInternal ? R.string.fm_copy_to_external : R.string.fm_copy_to_internal), R.drawable.ic_sync);
    }

    // ------------------------------------------------------------- operations

    private void promptCreate(boolean folder) {
        CustomDialogs.input(this, true, getString(folder ? R.string.fm_new_folder : R.string.fm_new_file),
            folder ? "Folder name" : "File name", null, "Create", name -> {
                final String n = name.trim();
                final File dir = currentDir();
                runOp("Creating…", () -> {
                    if (folder) FileOps.createFolder(dir, n); else FileOps.createFile(dir, n);
                });
            });
    }

    private void promptRename(@NonNull File file) {
        CustomDialogs.input(this, true, getString(R.string.fm_rename), "New name", file.getName(),
            getString(R.string.fm_rename), name -> {
                final String n = name.trim();
                runOp(null, () -> FileOps.rename(file, n));
            });
        exitSelectionMode();
    }

    private void confirmDelete(@NonNull List<File> files) {
        if (files.isEmpty()) return;
        final List<File> copy = new ArrayList<>(files);
        String msg = copy.size() == 1 ? "\"" + copy.get(0).getName() + "\" will be permanently deleted."
            : copy.size() + " items will be permanently deleted.";
        CustomDialogs.confirm(this, true, "Delete?", msg, getString(R.string.fm_delete), true, () -> {
            exitSelectionMode();
            runOp("Deleting…", () -> FileOps.deleteAll(copy));
        });
    }

    private void startClipboard(@NonNull List<File> files, boolean move) {
        if (files.isEmpty()) return;
        mClipboard.clear();
        mClipboard.addAll(files);
        mClipboardMove = move;
        exitSelectionMode();
        updatePasteBar();
    }

    private void clearClipboard() {
        mClipboard.clear();
        updatePasteBar();
    }

    private void updatePasteBar() {
        if (mClipboard.isEmpty()) { mPasteBar.setVisibility(View.GONE); return; }
        String what = mClipboard.size() == 1 ? mClipboard.get(0).getName() : mClipboard.size() + " items";
        mPasteLabel.setText((mClipboardMove ? "Move: " : "Copy: ") + what);
        mPasteBar.setVisibility(View.VISIBLE);
    }

    private void pasteHere() {
        if (mClipboard.isEmpty()) return;
        if (mExternal && !StorageAccess.hasExternalAccess(this)) { StorageAccess.requestExternalAccess(this); return; }
        final List<File> files = new ArrayList<>(mClipboard);
        final boolean move = mClipboardMove;
        final File dest = currentDir();
        clearClipboard();
        runOp(move ? "Moving…" : "Copying…", () -> {
            for (File f : files) {
                if (move) FileOps.moveInto(f, dest); else FileOps.copyInto(f, dest);
            }
        });
    }

    /** "Copy to Internal Home" / "Copy to External Storage": copies into the root of the other storage. */
    private void copyToOtherStorage(@NonNull List<File> files) {
        final boolean toExternal = isInside(files.get(0), mInternalRoot);
        final File dest = toExternal ? mExternalRoot : mInternalRoot;
        if (toExternal && !StorageAccess.hasExternalAccess(this)) {
            StorageAccess.requestExternalAccess(this);
            return;
        }
        final List<File> copy = new ArrayList<>(files);
        exitSelectionMode();
        runOp(toExternal ? "Copying to shared storage…" : "Copying to Termux home…", () -> {
            for (File f : copy) FileOps.copyInto(f, dest);
        });
    }

    private interface IoTask { void run() throws IOException; }

    /** Runs {@code task} as a background Task: it keeps going if you leave this screen or close the app. */
    private void runOp(String startToast, @NonNull IoTask task) {
        if (mBusy) { Toast.makeText(this, "Still working…", Toast.LENGTH_SHORT).show(); return; }
        mBusy = true;
        if (startToast != null) Toast.makeText(this, startToast, Toast.LENGTH_SHORT).show();
        final String label = startToast == null ? "File operation" : startToast.replace("…", "");
        final File here = currentDir();
        TaskCenter.submit(this, "files", label + " · " + here.getName(), intentFor(this, here), false, handle -> {
            handle.progress(-1, label + "…");
            try {
                task.run();
            } catch (IOException | RuntimeException e) {
                TermuxErrorJournal.record(JOURNAL_NAME, "file operation failed in " + here.getAbsolutePath(), e);
                throw e;
            }
        }, item -> {
            mBusy = false;
            if (isFinishing()) return;
            if (item.state == TaskCenter.State.DONE) {
                mMascot.react(MascotEvents.Event.FILE_OPERATION_DONE);
            } else {
                mMascot.react(MascotEvents.Event.ERROR);
                Toast.makeText(this, item.status, Toast.LENGTH_LONG).show();
            }
            reload();
        });
    }

    private static boolean isInside(File file, File root) {
        String p = file.getAbsolutePath(), r = root.getAbsolutePath();
        return p.equals(r) || p.startsWith(r + "/");
    }
}
