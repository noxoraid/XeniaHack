package com.termux.app.ext.task;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.termux.R;

/** Foreground service whose only job is to keep the process (and running tasks) alive. */
public class TaskService extends Service implements TaskCenter.Listener {

    private static final String CHANNEL_RUNNING = "tasks_running";
    private static final String CHANNEL_DONE = "tasks_done";
    private static final int RUNNING_ID = 7311;

    private PowerManager.WakeLock mWake;

    public static void ensureRunning(@NonNull Context context) {
        try {
            Intent intent = new Intent(context, TaskService.class);
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent); else context.startService(intent);
        } catch (RuntimeException ignored) {
            return;
        }
    }

    public static void notifyFinished(@NonNull Context context, @NonNull TaskCenter.TaskItem item) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            createChannels(nm);
            Notification n = new NotificationCompat.Builder(context, CHANNEL_DONE)
                .setSmallIcon(R.drawable.ic_service_notification)
                .setContentTitle(item.title)
                .setContentText(stateLabel(item) + " · " + item.status)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(stateLabel(item) + "\n" + item.status))
                .setContentIntent(openTasks(context))
                .setAutoCancel(true)
                .build();
            nm.notify(item.id.hashCode(), n);
        } catch (RuntimeException ignored) {
            return;
        }
    }

    private static String stateLabel(TaskCenter.TaskItem item) {
        switch (item.state) {
            case DONE: return "Finished";
            case FAILED: return "Failed";
            case CANCELLED: return "Cancelled";
            case NEEDS_ACTION: return "Needs your action";
            default: return "Stopped";
        }
    }

    private static PendingIntent openTasks(Context context) {
        Intent intent = new Intent(context, TaskActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(context, 0, intent, flags);
    }

    private static void createChannels(NotificationManager nm) {
        if (Build.VERSION.SDK_INT < 26) return;
        nm.createNotificationChannel(new NotificationChannel(CHANNEL_RUNNING, "Running tasks", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CHANNEL_DONE, "Finished tasks", NotificationManager.IMPORTANCE_DEFAULT));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) createChannels(nm);
        startForegroundCompat();
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            mWake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "termux:tasks");
            mWake.acquire(3 * 60 * 60 * 1000L);
        }
        TaskCenter.addListener(this);
    }

    private void startForegroundCompat() {
        Notification n = build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(RUNNING_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(RUNNING_ID, n);
    }

    private Notification build() {
        int running = TaskCenter.runningCount();
        TaskCenter.TaskItem first = TaskCenter.firstRunning();
        String title = running <= 1 ? (first == null ? "Tasks" : first.title) : running + " tasks running";
        String text = first == null ? "Nothing running" : first.status;
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_RUNNING)
            .setSmallIcon(R.drawable.ic_service_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openTasks(this));
        if (first != null && first.percent >= 0) b.setProgress(100, first.percent, false);
        else b.setProgress(0, 0, true);
        return b.build();
    }

    @Override
    public void onTasksChanged() {
        if (TaskCenter.runningCount() == 0) {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
            stopSelf();
            return;
        }
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(RUNNING_ID, build());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (TaskCenter.runningCount() == 0) onTasksChanged();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        TaskCenter.removeListener(this);
        if (mWake != null && mWake.isHeld()) mWake.release();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
