package com.termux.app.ext.github;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

final class GithubBlobHash {

    private GithubBlobHash() {}

    static String of(byte[] content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            digest.update(("blob " + content.length + "\0").getBytes(java.nio.charset.StandardCharsets.UTF_8));
            digest.update(content);
            StringBuilder hex = new StringBuilder(40);
            for (byte b : digest.digest()) hex.append(String.format("%02x", b));
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
