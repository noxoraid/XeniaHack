package com.termux.app.ext.github;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public final class GithubUploadFilter {

    private final List<String> mNames = new ArrayList<>();
    private final List<String> mSuffixes = new ArrayList<>();
    private final List<String> mPrefixes = new ArrayList<>();
    private final List<String> mTokens = new ArrayList<>();

    public GithubUploadFilter(@NonNull String raw) {
        for (String part : raw.split("[,;\\s]+")) {
            String token = part.trim();
            if (token.isEmpty()) continue;
            mTokens.add(token);
            if (token.startsWith("*.")) {
                mSuffixes.add(token.substring(1));
            } else if (token.contains("/")) {
                String trimmed = token;
                while (trimmed.startsWith("/")) trimmed = trimmed.substring(1);
                while (trimmed.endsWith("/")) trimmed = trimmed.substring(0, trimmed.length() - 1);
                if (!trimmed.isEmpty()) mPrefixes.add(trimmed);
            } else {
                mNames.add(token);
            }
        }
    }

    @NonNull
    public List<String> tokens() {
        return mTokens;
    }

    public boolean skips(@NonNull String relativePath) {
        String[] parts = relativePath.split("/");
        for (String part : parts) {
            if (mNames.contains(part)) return true;
        }
        String last = parts[parts.length - 1];
        for (String suffix : mSuffixes) {
            if (last.endsWith(suffix)) return true;
        }
        for (String prefix : mPrefixes) {
            if (relativePath.equals(prefix) || relativePath.startsWith(prefix + "/")) return true;
        }
        return false;
    }
}
