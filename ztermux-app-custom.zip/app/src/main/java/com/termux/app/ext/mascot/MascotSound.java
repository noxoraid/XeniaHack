package com.termux.app.ext.mascot;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import androidx.annotation.NonNull;

import com.termux.R;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Short built-in sound effects for the mascot (swoosh, blink, pop, boing, chirp). Bundled as small WAV files in
 * {@code res/raw}, played with a {@link SoundPool}: fully offline, no speech engine, no downloads.
 */
public final class MascotSound {

    public enum Sfx {
        SWOOSH(R.raw.sfx_swoosh), BLINK(R.raw.sfx_blink), POP(R.raw.sfx_pop),
        BOING(R.raw.sfx_boing), CHIRP(R.raw.sfx_chirp);

        final int res;
        Sfx(int res) { this.res = res; }
    }

    private static final Random RANDOM = new Random();
    private static final float VOLUME = 0.55f;

    private static SoundPool sPool;
    private static final int[] sIds = new int[Sfx.values().length];
    private static final Set<Integer> sLoaded = new HashSet<>();

    private MascotSound() {}

    private static synchronized void init(Context app) {
        if (sPool != null) return;
        sPool = new SoundPool.Builder()
            .setMaxStreams(3)
            .setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .build();
        sPool.setOnLoadCompleteListener((pool, sampleId, status) -> {
            if (status == 0) synchronized (MascotSound.class) { sLoaded.add(sampleId); }
        });
        for (Sfx s : Sfx.values()) sIds[s.ordinal()] = sPool.load(app, s.res, 1);
    }

    /** Plays one effect with a slightly random pitch so it never sounds identical. The first call only loads. */
    public static synchronized void play(@NonNull Context context, @NonNull Sfx sfx) {
        try {
            init(context.getApplicationContext());
            int id = sIds[sfx.ordinal()];
            if (!sLoaded.contains(id)) return;
            float rate = 0.92f + RANDOM.nextFloat() * 0.18f;
            sPool.play(id, VOLUME, VOLUME, 1, 0, rate);
        } catch (Exception ignored) {
            // Sound is decoration only; never crash the app for it.
        }
    }

    /** Warm up the pool so the first effect is not lost. */
    public static void preload(@NonNull Context context) {
        try { init(context.getApplicationContext()); } catch (Exception ignored) { }
    }

    public static synchronized void stop() {
        try { if (sPool != null) sPool.autoPause(); } catch (Exception ignored) { }
    }
}
