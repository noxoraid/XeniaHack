package com.termux.app.ext.github;

import android.os.Environment;

import androidx.annotation.NonNull;

import com.termux.app.ext.filemanager.FileOps;
import com.termux.app.ext.task.TaskCenter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

final class GithubDownloadFolder {

    private GithubDownloadFolder() {}

    @NonNull
    static File uniqueTarget(@NonNull String fileName) throws IOException {
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Cannot open the Download folder");
        String safe = fileName.replaceAll("[^A-Za-z0-9._-]", "_");
        File target = new File(dir, safe);
        int counter = 1;
        int dot = safe.lastIndexOf('.');
        String stem = dot > 0 ? safe.substring(0, dot) : safe;
        String extension = dot > 0 ? safe.substring(dot) : "";
        while (target.exists()) target = new File(dir, stem + "-" + (counter++) + extension);
        return target;
    }

    @NonNull
    static File saveStream(@NonNull String fileName, @NonNull InputStream in) throws IOException {
        return saveStream(fileName, in, -1);
    }

    /** Saves into Download/, reporting progress to the running Task and stopping if it is cancelled. */
    @NonNull
    static File saveStream(@NonNull String fileName, @NonNull InputStream in, long totalBytes) throws IOException {
        File target = uniqueTarget(fileName);
        TaskCenter.TaskHandle task = TaskCenter.current();
        long done = 0;
        long lastReport = 0;
        boolean finished = false;
        try (InputStream source = in; OutputStream out = new FileOutputStream(target)) {
            byte[] buffer = new byte[32768];
            int read;
            while ((read = source.read(buffer)) != -1) {
                if (task != null && task.isCancelled()) throw new IOException("Cancelled");
                out.write(buffer, 0, read);
                done += read;
                long now = System.currentTimeMillis();
                if (task != null && now - lastReport > 400) {
                    lastReport = now;
                    int percent = totalBytes > 0 ? (int) Math.min(99, done * 100 / totalBytes) : -1;
                    task.progress(percent, FileOps.humanSize(done) + (totalBytes > 0 ? " / " + FileOps.humanSize(totalBytes) : ""));
                }
            }
            finished = true;
        } finally {
            if (!finished && target.exists()) //noinspection ResultOfMethodCallIgnored
                target.delete();
        }
        return target;
    }

    @NonNull
    static File saveText(@NonNull String fileName, @NonNull String text) throws IOException {
        File target = uniqueTarget(fileName);
        try (OutputStream out = new FileOutputStream(target)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
        return target;
    }
}
