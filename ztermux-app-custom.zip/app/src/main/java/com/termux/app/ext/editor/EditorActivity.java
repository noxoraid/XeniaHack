package com.termux.app.ext.editor;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.termux.R;
import com.termux.app.ext.filemanager.FileOps;
import com.termux.app.ext.mascot.MascotEvents;
import com.termux.app.ext.mascot.MascotWidget;
import com.termux.app.ext.ui.CustomDialogs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Full-screen text/code editor with line numbers, opened from the File Manager. */
public class EditorActivity extends AppCompatActivity {

    public static final String EXTRA_PATH = "com.termux.app.ext.editor.EXTRA_PATH";
    public static final long MAX_EDIT_BYTES = 2L * 1024 * 1024;

    private final ExecutorService mIo = Executors.newSingleThreadExecutor();

    private CodeEditText mText;
    private TextView mTitle;
    private TextView mSubtitle;
    private MascotWidget mMascot;
    private File mFile;
    private boolean mLoaded;
    private boolean mDirty;
    private boolean mSaving;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        String path = getIntent().getStringExtra(EXTRA_PATH);
        if (path == null) { finish(); return; }
        mFile = new File(path);

        mText = findViewById(R.id.ed_text);
        mTitle = findViewById(R.id.ed_title);
        mSubtitle = findViewById(R.id.ed_subtitle);
        mMascot = findViewById(R.id.ed_mascot);
        mMascot.setRoamingEnabled(false); // editor mascot stays docked so it never covers the text being edited

        mTitle.setText(mFile.getName());
        mSubtitle.setText(mFile.getAbsolutePath());

        findViewById(R.id.ed_back).setOnClickListener(v -> onBackPressed());
        findViewById(R.id.ed_btn_paste).setOnClickListener(v -> paste());
        findViewById(R.id.ed_btn_clear).setOnClickListener(v -> clearAll());
        findViewById(R.id.ed_btn_select_all).setOnClickListener(v -> selectAll());
        findViewById(R.id.ed_btn_copy).setOnClickListener(v -> copy());
        findViewById(R.id.ed_btn_save).setOnClickListener(v -> save(false));

        mText.setEnabled(false);
        mText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (mLoaded && !mDirty) { mDirty = true; updateTitle(); }
            }
        });

        load();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mIo.shutdownNow();
    }

    // ------------------------------------------------------------------ loading

    private void load() {
        mIo.execute(() -> {
            try {
                final String content = FileOps.readText(mFile);
                runOnUiThread(() -> {
                    if (isFinishing()) return;
                    mText.setText(content);
                    mText.setEnabled(true);
                    mLoaded = true;
                    mDirty = false;
                    updateTitle();
                    mMascot.say("Happy editing!", com.termux.app.ext.mascot.MascotView.Expression.HAPPY, 2000);
                });
            } catch (IOException e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Cannot open file: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    finish();
                });
            }
        });
    }

    private void updateTitle() {
        mTitle.setText((mDirty ? "● " : "") + mFile.getName());
    }

    // ------------------------------------------------------------------ actions

    private void paste() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm != null ? cm.getPrimaryClip() : null;
        if (clip == null || clip.getItemCount() == 0) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show();
            return;
        }
        CharSequence text = clip.getItemAt(0).coerceToText(this);
        if (text == null || text.length() == 0) return;
        int start = Math.max(0, Math.min(mText.getSelectionStart(), mText.getSelectionEnd()));
        int end = Math.max(0, Math.max(mText.getSelectionStart(), mText.getSelectionEnd()));
        mText.getText().replace(start, end, text);
        mText.requestFocus();
    }

    private void clearAll() {
        if (mText.length() == 0) return;
        CustomDialogs.confirm(this, true, "Clear all text?", "This empties the editor. You can still leave without saving.",
            getString(R.string.editor_clear), true, () -> mText.setText(""));
    }

    private void selectAll() {
        mText.requestFocus();
        mText.selectAll();
    }

    private void copy() {
        int s = mText.getSelectionStart(), e = mText.getSelectionEnd();
        CharSequence toCopy = (s >= 0 && e > s) ? mText.getText().subSequence(s, e)
            : (s >= 0 && e >= 0 && s > e ? mText.getText().subSequence(e, s) : mText.getText());
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText(mFile.getName(), toCopy));
            Toast.makeText(this, (s != e ? "Selection" : "All text") + " copied", Toast.LENGTH_SHORT).show();
        }
    }

    /** @param closeAfter finish the activity once the write succeeded. */
    private void save(boolean closeAfter) {
        if (!mLoaded || mSaving) return;
        mSaving = true;
        final String content = mText.getText().toString();
        mIo.execute(() -> {
            try {
                FileOps.writeText(mFile, content);
                runOnUiThread(() -> {
                    mSaving = false;
                    mDirty = false;
                    updateTitle();
                    setResult(RESULT_OK);
                    MascotEvents.postPending(MascotEvents.Event.FILE_SAVED);
                    mMascot.react(MascotEvents.Event.FILE_SAVED);
                    if (closeAfter) finish();
                });
            } catch (IOException e) {
                runOnUiThread(() -> {
                    mSaving = false;
                    mMascot.react(MascotEvents.Event.ERROR);
                    Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!mDirty) { super.onBackPressed(); return; }
        hideKeyboard();
        List<CustomDialogs.MenuEntry> entries = new ArrayList<>();
        entries.add(new CustomDialogs.MenuEntry("Save and close", R.drawable.ic_save));
        entries.add(new CustomDialogs.MenuEntry("Discard changes", R.drawable.ic_delete, true));
        CustomDialogs.menu(this, true, "Unsaved changes", entries, index -> {
            if (index == 0) save(true); else finish();
        });
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        View v = getCurrentFocus();
        if (imm != null && v != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    @NonNull
    public static android.content.Intent intentFor(@NonNull Context context, @NonNull File file) {
        android.content.Intent i = new android.content.Intent(context, EditorActivity.class);
        i.putExtra(EXTRA_PATH, file.getAbsolutePath());
        return i;
    }
}
