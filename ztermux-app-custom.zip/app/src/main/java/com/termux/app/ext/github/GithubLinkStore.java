package com.termux.app.ext.github;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class GithubLinkStore {

    public static final String MODE_GIT = "git";
    public static final String MODE_TOKEN = "token";
    public static final String DEFAULT_EXCLUDES = ".git, node_modules";
    public static final String DEFAULT_MESSAGE = "Update from Termux";

    private static final String PREFS = "github_link";
    private static final String KEY_MODE = "mode";
    private static final String KEY_TOKEN = "token";
    private static final Pattern REPO_IN_URL = Pattern.compile("github\\.com[:/]+([\\w.-]+)/([\\w.-]+?)(?:\\.git)?/?$");
    private static final Pattern REPO_SHORT = Pattern.compile("^([\\w.-]+)/([\\w.-]+)$");

    private final SharedPreferences mPrefs;

    public GithubLinkStore(@NonNull Context context) {
        mPrefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    @NonNull
    public String mode() {
        return mPrefs.getString(KEY_MODE, MODE_GIT);
    }

    public void setMode(@NonNull String mode) {
        mPrefs.edit().putString(KEY_MODE, mode).apply();
    }

    @NonNull
    public String token() {
        return mPrefs.getString(KEY_TOKEN, "");
    }

    public boolean hasToken() {
        return !token().isEmpty();
    }

    public void setToken(@NonNull String token) {
        mPrefs.edit().putString(KEY_TOKEN, token.trim()).apply();
    }

    @NonNull
    public String repoFor(@NonNull File dir) {
        return mPrefs.getString("repo:" + dir.getAbsolutePath(), "");
    }

    public void setRepoFor(@NonNull File dir, @NonNull String repo) {
        mPrefs.edit().putString("repo:" + dir.getAbsolutePath(), repo).apply();
    }

    @NonNull
    public String branchFor(@NonNull File dir) {
        return mPrefs.getString("branch:" + dir.getAbsolutePath(), "main");
    }

    public void setBranchFor(@NonNull File dir, @NonNull String branch) {
        mPrefs.edit().putString("branch:" + dir.getAbsolutePath(), branch).apply();
    }

    @NonNull
    public String excludesFor(@NonNull File dir) {
        return mPrefs.getString("exclude:" + dir.getAbsolutePath(), DEFAULT_EXCLUDES);
    }

    public void setExcludesFor(@NonNull File dir, @NonNull String excludes) {
        mPrefs.edit().putString("exclude:" + dir.getAbsolutePath(), excludes).apply();
    }

    @NonNull
    public String messageFor(@NonNull File dir) {
        return mPrefs.getString("message:" + dir.getAbsolutePath(), DEFAULT_MESSAGE);
    }

    public void setMessageFor(@NonNull File dir, @NonNull String message) {
        mPrefs.edit().putString("message:" + dir.getAbsolutePath(), message).apply();
    }

    @Nullable
    public static String repoFromText(@NonNull String text) {
        String trimmed = text.trim();
        Matcher url = REPO_IN_URL.matcher(trimmed);
        if (url.find()) return url.group(1) + "/" + url.group(2);
        Matcher shortForm = REPO_SHORT.matcher(trimmed);
        if (shortForm.matches()) return trimmed;
        return null;
    }

    @NonNull
    public static String maskedToken(@NonNull String token) {
        if (token.length() <= 8) return "••••";
        return "••••" + token.substring(token.length() - 4);
    }
}
