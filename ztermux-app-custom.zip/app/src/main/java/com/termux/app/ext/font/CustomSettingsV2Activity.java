package com.termux.app.ext.font;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import androidx.appcompat.widget.SwitchCompat;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.termux.R;
import com.termux.app.TermuxActivity;
import com.termux.app.ext.mascot.MascotSettings;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Custom Settings v2: pick a Google Font for the terminal and, separately, for the UI.
 */
public class CustomSettingsV2Activity extends AppCompatActivity {

    private final ExecutorService mIo = Executors.newSingleThreadExecutor();
    private final Handler mMain = new Handler(Looper.getMainLooper());

    private Section mTerminal;
    private Section mUi;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_settings_v2);

        mTerminal = new Section(findViewById(R.id.section_terminal), true);
        mUi = new Section(findViewById(R.id.section_ui), false);

        findViewById(R.id.cs2_back).setOnClickListener(v -> finish());
        TextView changelog = findViewById(R.id.cs2_changelog_row);
        changelog.setText(getString(R.string.cs2_changelog_row, getString(R.string.custom_version_name)));
        changelog.setOnClickListener(v -> startActivity(new Intent(this, ChangelogActivity.class)));
        bindSwitch(R.id.sw_hide_bot, MascotSettings.KEY_HIDE_BOT);
        bindSwitch(R.id.sw_hide_text, MascotSettings.KEY_HIDE_TEXT);
        bindSwitch(R.id.sw_hide_sound, MascotSettings.KEY_HIDE_SOUND);
    }

    private void bindSwitch(int id, String key) {
        SwitchCompat sw = findViewById(id);
        sw.setChecked(MascotSettings.prefs(this).getBoolean(key, false));
        sw.setOnCheckedChangeListener((b, checked) -> MascotSettings.set(this, key, checked));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mIo.shutdownNow();
    }

    /** One font card (terminal or UI). */
    private final class Section {
        final boolean terminal;
        final AutoCompleteTextView family;
        final TextView current, preview, status, apply, reset;
        boolean busy;

        Section(View root, boolean terminal) {
            this.terminal = terminal;
            ((TextView) root.findViewById(R.id.fs_title)).setText(terminal ? R.string.cs2_terminal_title : R.string.cs2_ui_title);
            ((TextView) root.findViewById(R.id.fs_desc)).setText(terminal ? R.string.cs2_terminal_desc : R.string.cs2_ui_desc);
            current = root.findViewById(R.id.fs_current);
            family = root.findViewById(R.id.fs_family);
            preview = root.findViewById(R.id.fs_preview);
            status = root.findViewById(R.id.fs_status);
            apply = root.findViewById(R.id.fs_apply);
            reset = root.findViewById(R.id.fs_reset);

            family.setAdapter(new ArrayAdapter<>(CustomSettingsV2Activity.this,
                android.R.layout.simple_dropdown_item_1line, terminal ? FontManager.MONO_FONTS : FontManager.UI_FONTS));
            family.setThreshold(0);
            family.setOnClickListener(v -> family.showDropDown());
            family.setOnFocusChangeListener((v, hasFocus) -> { if (hasFocus) family.showDropDown(); });
            family.setOnItemClickListener((parent, v, pos, id) -> hideKeyboard());
            family.setOnEditorActionListener((v, actionId, event) -> { hideKeyboard(); return true; });

            if (terminal) preview.setTypeface(FontManager.getTerminalTypeface());

            apply.setOnClickListener(v -> onApply());
            reset.setOnClickListener(v -> onReset());
            refresh();
        }

        void refresh() {
            String name = terminal ? FontManager.getTerminalFamily(CustomSettingsV2Activity.this)
                                   : FontManager.getUiFamily(CustomSettingsV2Activity.this);
            current.setText(name == null ? getString(R.string.cs2_current_default) : getString(R.string.cs2_current, name));
            if (name != null && TextUtils.isEmpty(family.getText())) family.setText(name, false);
        }

        void setStatus(@Nullable String text) {
            status.setVisibility(text == null ? View.GONE : View.VISIBLE);
            status.setText(text);
        }

        void setBusy(boolean b) {
            busy = b;
            apply.setAlpha(b ? 0.5f : 1f);
            reset.setAlpha(b ? 0.5f : 1f);
        }

        void onApply() {
            if (busy) return;
            final String name = family.getText().toString().trim();
            if (name.isEmpty()) { family.setError(getString(R.string.cs2_hint_family)); return; }
            hideKeyboard();
            setBusy(true);
            setStatus(getString(R.string.cs2_downloading, name));

            mIo.execute(() -> {
                try {
                    File font = FontManager.downloadGoogleFont(CustomSettingsV2Activity.this, name);
                    if (terminal) FontManager.applyTerminalFont(CustomSettingsV2Activity.this, name, font);
                    else FontManager.applyUiFont(CustomSettingsV2Activity.this, name, font);
                    final Typeface tf = Typeface.createFromFile(font);
                    mMain.post(() -> {
                        if (isFinishing()) return;
                        if (terminal) {
                            preview.setTypeface(tf);
                            // Tell TermuxActivity to reload font/colors (it ignores this while not visible,
                            // and reloads the font itself on the next start/resume anyway).
                            TermuxActivity.updateTermuxActivityStyling(getApplicationContext(), false);
                        } else {
                            FontManager.applyUi(CustomSettingsV2Activity.this, getWindow().getDecorView());
                        }
                        setBusy(false);
                        setStatus(getString(R.string.cs2_applied, name));
                        refresh();
                    });
                } catch (Exception e) {
                    final String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                    mMain.post(() -> {
                        if (isFinishing()) return;
                        setBusy(false);
                        setStatus(getString(R.string.cs2_failed, msg));
                    });
                }
            });
        }

        void onReset() {
            if (busy) return;
            if (terminal) {
                FontManager.resetTerminalFont(CustomSettingsV2Activity.this);
                preview.setTypeface(Typeface.DEFAULT);
                TermuxActivity.updateTermuxActivityStyling(getApplicationContext(), false);
            } else {
                FontManager.resetUiFont(CustomSettingsV2Activity.this);
                Toast.makeText(CustomSettingsV2Activity.this, R.string.cs2_reset_done, Toast.LENGTH_SHORT).show();
                // The UI font is only removed from views as they are re-created.
                recreate();
                return;
            }
            family.setText("", false);
            setStatus(getString(R.string.cs2_reset_done));
            refresh();
        }
    }

    private void hideKeyboard() {
        View v = getCurrentFocus();
        if (v == null) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }
}
