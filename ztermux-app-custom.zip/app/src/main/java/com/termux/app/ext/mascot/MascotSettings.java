package com.termux.app.ext.mascot;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

/** User switches for the mascot (Custom Settings v2): hide the bot, its speech bubble, or its sound. */
public final class MascotSettings {

    public static final String PREFS = "custom_settings_v2";
    public static final String KEY_HIDE_BOT = "mascot_hide_bot";
    public static final String KEY_HIDE_TEXT = "mascot_hide_text";
    public static final String KEY_HIDE_SOUND = "mascot_hide_sound";

    private MascotSettings() {}

    @NonNull
    public static SharedPreferences prefs(@NonNull Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isBotHidden(@NonNull Context c) { return prefs(c).getBoolean(KEY_HIDE_BOT, false); }
    public static boolean isTextHidden(@NonNull Context c) { return prefs(c).getBoolean(KEY_HIDE_TEXT, false); }
    public static boolean isSoundHidden(@NonNull Context c) { return prefs(c).getBoolean(KEY_HIDE_SOUND, false); }

    public static void set(@NonNull Context c, @NonNull String key, boolean value) {
        prefs(c).edit().putBoolean(key, value).apply();
    }
}
