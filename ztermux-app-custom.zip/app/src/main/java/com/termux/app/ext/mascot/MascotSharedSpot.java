package com.termux.app.ext.mascot;

public final class MascotSharedSpot {

    private static float sFractionX = -1f;
    private static float sFractionY = -1f;

    private MascotSharedSpot() {}

    public static synchronized boolean isKnown() {
        return sFractionX >= 0f && sFractionY >= 0f;
    }

    public static synchronized void remember(float fractionX, float fractionY) {
        sFractionX = clamp(fractionX);
        sFractionY = clamp(fractionY);
    }

    public static synchronized float fractionX() { return sFractionX; }

    public static synchronized float fractionY() { return sFractionY; }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}
