package com.termux.app.ext.github;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButtonToggleGroup;
import com.termux.R;
import com.termux.app.ext.filemanager.StorageAccess;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GithubLogActivity extends AppCompatActivity {

    public static final String EXTRA_REPO = "com.termux.app.ext.github.EXTRA_LOG_REPO";
    public static final String EXTRA_RUN_ID = "com.termux.app.ext.github.EXTRA_LOG_RUN_ID";
    public static final String EXTRA_RUN_NUMBER = "com.termux.app.ext.github.EXTRA_LOG_RUN_NUMBER";
    public static final String EXTRA_ERRORS_FIRST = "com.termux.app.ext.github.EXTRA_LOG_ERRORS_FIRST";

    private static final int SHOWN_CHARS = 300_000;
    private static final int CLIPBOARD_CHARS = 900_000;

    private final ExecutorService mIo = Executors.newSingleThreadExecutor();

    private String mRepo;
    private int mRunNumber;
    private String mFullLog;
    private String mErrorLog;
    private boolean mErrorsMode;
    private TextView mText;
    private ScrollView mScroll;
    private View mLoading;

    @NonNull
    public static Intent intentFor(@NonNull Context context, @NonNull String repo, long runId, int runNumber, boolean errorsFirst) {
        Intent intent = new Intent(context, GithubLogActivity.class);
        intent.putExtra(EXTRA_REPO, repo);
        intent.putExtra(EXTRA_RUN_ID, runId);
        intent.putExtra(EXTRA_RUN_NUMBER, runNumber);
        intent.putExtra(EXTRA_ERRORS_FIRST, errorsFirst);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_github_log);

        mRepo = getIntent().getStringExtra(EXTRA_REPO);
        final long runId = getIntent().getLongExtra(EXTRA_RUN_ID, 0L);
        mRunNumber = getIntent().getIntExtra(EXTRA_RUN_NUMBER, 0);
        mErrorsMode = getIntent().getBooleanExtra(EXTRA_ERRORS_FIRST, false);
        String token = new GithubLinkStore(this).token();
        if (mRepo == null || runId == 0L || token.isEmpty()) { finish(); return; }

        mText = findViewById(R.id.gl_text);
        mScroll = findViewById(R.id.gl_scroll);
        mLoading = findViewById(R.id.gl_loading);
        ((TextView) findViewById(R.id.gl_title)).setText("Run #" + mRunNumber + " · " + mRepo);

        findViewById(R.id.gl_back).setOnClickListener(v -> finish());
        findViewById(R.id.gl_copy).setOnClickListener(v -> copyLog());
        findViewById(R.id.gl_download).setOnClickListener(v -> downloadLog());

        MaterialButtonToggleGroup toggle = findViewById(R.id.gl_toggle);
        toggle.check(mErrorsMode ? R.id.gl_mode_errors : R.id.gl_mode_full);
        toggle.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            mErrorsMode = checkedId == R.id.gl_mode_errors;
            render();
        });

        final GithubRestClient client = new GithubRestClient(token);
        mIo.execute(() -> {
            String full = null;
            String problem = null;
            try {
                full = GithubLogDigest.readZip(client.openDownload("/repos/" + mRepo + "/actions/runs/" + runId + "/logs"));
            } catch (GithubApiException e) {
                problem = (e.status == 404 || e.status == 410) ? "Logs are not available (expired or the run has not started)." : e.getMessage();
            } catch (IOException e) {
                problem = e.getMessage();
            }
            final String loaded = full;
            final String error = problem;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                mLoading.setVisibility(View.GONE);
                if (error != null) { mText.setText(error); return; }
                mFullLog = loaded;
                mErrorLog = GithubLogDigest.errorsOnly(loaded);
                render();
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mIo.shutdownNow();
    }

    private String current() {
        return mErrorsMode ? mErrorLog : mFullLog;
    }

    private void render() {
        String text = current();
        if (text == null) return;
        if (text.length() > SHOWN_CHARS) {
            text = "[Showing the last " + SHOWN_CHARS + " characters. Copy and Download include the whole log.]\n\n"
                + text.substring(text.length() - SHOWN_CHARS);
        }
        mText.setText(text);
        mScroll.post(() -> {
            if (mErrorsMode) mScroll.fullScroll(View.FOCUS_UP); else mScroll.fullScroll(View.FOCUS_DOWN);
        });
    }

    private void copyLog() {
        String text = current();
        if (text == null) return;
        boolean trimmed = text.length() > CLIPBOARD_CHARS;
        if (trimmed) text = text.substring(text.length() - CLIPBOARD_CHARS);
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null) return;
        cm.setPrimaryClip(ClipData.newPlainText("Run " + mRunNumber, text));
        Toast.makeText(this, trimmed ? "Copied the last 900k characters. Use Download for the whole log." : "Log copied", Toast.LENGTH_SHORT).show();
    }

    private void downloadLog() {
        final String text = current();
        if (text == null) return;
        if (!StorageAccess.hasExternalAccess(this)) {
            Toast.makeText(this, "Allow all files access, then try again", Toast.LENGTH_LONG).show();
            StorageAccess.requestExternalAccess(this);
            return;
        }
        final String repoName = mRepo.substring(mRepo.indexOf('/') + 1);
        final String fileName = repoName + "-run" + mRunNumber + (mErrorsMode ? "-errors" : "-full") + ".txt";
        mIo.execute(() -> {
            String message;
            try {
                File saved = GithubDownloadFolder.saveText(fileName, text);
                message = "Saved to Download/" + saved.getName();
            } catch (IOException e) {
                message = "Download failed: " + e.getMessage();
            }
            final String result = message;
            runOnUiThread(() -> Toast.makeText(this, result, Toast.LENGTH_LONG).show());
        });
    }
}
