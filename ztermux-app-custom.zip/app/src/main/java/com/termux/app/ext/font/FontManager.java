package com.termux.app.ext.font;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.termux.app.ext.editor.CodeEditText;
import com.termux.shared.termux.TermuxConstants;
import com.termux.shared.termux.extrakeys.ExtraKeysView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Custom fonts (Google Fonts) for two independent targets:
 * <ul>
 *   <li><b>Terminal</b> (also used by the Editor): the font is copied to {@code ~/.termux/font.ttf}, which the
 *       stock terminal code already loads.</li>
 *   <li><b>UI</b>: the font is stored in the app's private dir and applied to every TextView of every activity.</li>
 * </ul>
 * Fonts are downloaded at runtime from the Google Fonts CSS API (needs internet, no API key).
 */
public final class FontManager {

    private static final String PREFS = "custom_settings_v2";
    private static final String KEY_TERMINAL_FAMILY = "terminal_font_family";
    private static final String KEY_UI_FAMILY = "ui_font_family";

    /** An old User-Agent makes Google Fonts answer with plain .ttf links instead of woff2. */
    private static final String LEGACY_UA = "Mozilla/5.0 (Linux; U; Android 4.0.3; en-us) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30";
    private static final int MAX_FONT_BYTES = 25 * 1024 * 1024;

    public static final String[] MONO_FONTS = {
        "JetBrains Mono", "Fira Code", "Source Code Pro", "Roboto Mono", "Ubuntu Mono", "IBM Plex Mono",
        "Inconsolata", "Space Mono", "Noto Sans Mono", "DM Mono", "Overpass Mono", "Anonymous Pro",
        "Share Tech Mono", "Fira Mono", "Red Hat Mono", "Victor Mono", "Azeret Mono", "Martian Mono",
        "Cousine", "PT Mono", "Courier Prime", "B612 Mono", "Major Mono Display", "Syne Mono"
    };

    public static final String[] UI_FONTS = {
        "Roboto", "Inter", "Poppins", "Nunito", "Open Sans", "Lato", "Montserrat", "Ubuntu", "Noto Sans",
        "Work Sans", "Quicksand", "Rubik", "DM Sans", "Manrope", "Outfit", "Plus Jakarta Sans",
        "Source Sans 3", "Raleway", "Fira Sans", "Cabin", "Comfortaa", "Pacifico", "Space Grotesk", "Sora"
    };

    private static volatile Typeface sUiBase;
    private static volatile String sUiBaseFamily;
    private static volatile Typeface sTerminalCached;
    private static volatile long sTerminalCachedStamp = -1;

    private FontManager() {}

    // ------------------------------------------------------------------ prefs

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    @Nullable public static String getTerminalFamily(Context c) { return prefs(c).getString(KEY_TERMINAL_FAMILY, null); }
    @Nullable public static String getUiFamily(Context c) { return prefs(c).getString(KEY_UI_FAMILY, null); }

    private static File fontsDir(Context c) {
        return c.getApplicationContext().getDir("fonts", Context.MODE_PRIVATE);
    }

    private static File fileFor(Context c, String family) {
        return new File(fontsDir(c), family.trim().toLowerCase().replaceAll("[^a-z0-9]+", "_") + ".ttf");
    }

    // --------------------------------------------------------------- download

    /** Downloads (or returns the cached copy of) a Google Font. Blocking: call from a background thread. */
    @NonNull
    public static File downloadGoogleFont(Context c, String family) throws Exception {
        family = family.trim();
        if (family.isEmpty()) throw new IllegalArgumentException("Font name is empty");

        File target = fileFor(c, family);
        if (target.isFile() && target.length() > 0 && looksLikeFont(target)) return target;

        String cssUrl = "https://fonts.googleapis.com/css?family=" + URLEncoder.encode(family, "UTF-8") + ":400";
        String css = new String(fetch(cssUrl), StandardCharsets.UTF_8);
        String ttfUrl = pickTtfUrl(css);
        if (ttfUrl == null) throw new IllegalStateException("\"" + family + "\" was not found on Google Fonts");

        File tmp = new File(target.getPath() + ".part");
        try (OutputStream out = new FileOutputStream(tmp)) {
            out.write(fetch(ttfUrl));
        }
        if (!looksLikeFont(tmp)) {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
            throw new IllegalStateException("Downloaded file is not a valid font");
        }
        if (target.exists() && !target.delete()) throw new IllegalStateException("Cannot replace cached font");
        if (!tmp.renameTo(target)) throw new IllegalStateException("Cannot save font");
        return target;
    }

    /** Prefers the @font-face block marked "latin"; otherwise the first one. */
    @Nullable
    private static String pickTtfUrl(String css) {
        Pattern url = Pattern.compile("url\\((https://[^)]+?\\.(?:ttf|otf))\\)", Pattern.CASE_INSENSITIVE);
        String first = null;
        for (String block : css.split("@font-face")) {
            Matcher m = url.matcher(block);
            if (!m.find()) continue;
            if (block.contains("/* latin */") || block.contains("/* latin*/")) return m.group(1);
            if (first == null) first = m.group(1);
        }
        return first;
    }

    private static byte[] fetch(String address) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(address).openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(25000);
        conn.setRequestProperty("User-Agent", LEGACY_UA);
        try {
            int code = conn.getResponseCode();
            if (code == 400 || code == 404) throw new IllegalStateException("Font not found on Google Fonts (HTTP " + code + ")");
            if (code != 200) throw new IllegalStateException("Server answered HTTP " + code);
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
                byte[] chunk = new byte[16 * 1024];
                int n;
                while ((n = in.read(chunk)) > 0) {
                    buf.write(chunk, 0, n);
                    if (buf.size() > MAX_FONT_BYTES) throw new IllegalStateException("Font file is too large");
                }
                return buf.toByteArray();
            }
        } finally {
            conn.disconnect();
        }
    }

    private static boolean looksLikeFont(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] h = new byte[4];
            if (in.read(h) != 4) return false;
            String tag = new String(h, StandardCharsets.ISO_8859_1);
            return (h[0] == 0 && h[1] == 1 && h[2] == 0 && h[3] == 0)
                || tag.equals("true") || tag.equals("OTTO") || tag.equals("ttcf");
        } catch (Exception e) {
            return false;
        }
    }

    // --------------------------------------------------------------- terminal

    /** Copies the font to ~/.termux/font.ttf (the stock terminal picks it up on style reload). */
    public static void applyTerminalFont(Context c, String family, File fontFile) throws Exception {
        File dest = TermuxConstants.TERMUX_FONT_FILE;
        File dir = dest.getParentFile();
        if (dir != null && !dir.isDirectory() && !dir.mkdirs()) throw new IllegalStateException("Cannot create ~/.termux");
        copy(fontFile, dest);
        prefs(c).edit().putString(KEY_TERMINAL_FAMILY, family).apply();
        sTerminalCachedStamp = -1;
    }

    public static void resetTerminalFont(Context c) {
        //noinspection ResultOfMethodCallIgnored
        TermuxConstants.TERMUX_FONT_FILE.delete();
        prefs(c).edit().remove(KEY_TERMINAL_FAMILY).apply();
        sTerminalCachedStamp = -1;
    }

    /** The terminal font (also used by the Editor); falls back to monospace. */
    @NonNull
    public static Typeface getTerminalTypeface() {
        File f = TermuxConstants.TERMUX_FONT_FILE;
        if (!f.isFile() || f.length() == 0) return Typeface.MONOSPACE;
        long stamp = f.lastModified() ^ f.length();
        Typeface cached = sTerminalCached;
        if (cached != null && stamp == sTerminalCachedStamp) return cached;
        try {
            Typeface tf = Typeface.createFromFile(f);
            sTerminalCached = tf;
            sTerminalCachedStamp = stamp;
            return tf;
        } catch (Exception e) {
            return Typeface.MONOSPACE;
        }
    }

    private static void copy(File from, File to) throws Exception {
        try (InputStream in = new FileInputStream(from); OutputStream out = new FileOutputStream(to)) {
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    // --------------------------------------------------------------------- UI

    public static void applyUiFont(Context c, String family, File fontFile) {
        prefs(c).edit().putString(KEY_UI_FAMILY, family).apply();
        sUiBase = null;
        sUiBaseFamily = null;
    }

    public static void resetUiFont(Context c) {
        prefs(c).edit().remove(KEY_UI_FAMILY).apply();
        sUiBase = null;
        sUiBaseFamily = null;
    }

    /** The selected UI typeface, or null when the system font should be used. */
    @Nullable
    public static Typeface getUiBase(Context c) {
        String family = getUiFamily(c);
        if (family == null) return null;
        Typeface base = sUiBase;
        if (base != null && family.equals(sUiBaseFamily)) return base;
        File f = fileFor(c, family);
        if (!f.isFile() || f.length() == 0) return null;
        try {
            base = Typeface.createFromFile(f);
            sUiBase = base;
            sUiBaseFamily = family;
            return base;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Applies the UI font to all TextViews under {@code root} (idempotent). Skips the code editor
     * (it uses the terminal font) and the extra-keys row.
     */
    public static void applyUi(Context c, @Nullable View root) {
        if (root == null) return;
        Typeface base = getUiBase(c);
        if (base == null) return;
        apply(root, base);
    }

    private static void apply(View v, Typeface base) {
        if (v instanceof ExtraKeysView || v instanceof CodeEditText) return;
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            Integer key = System.identityHashCode(base);
            if (!key.equals(tv.getTag(com.termux.R.id.font_manager_applied))) {
                Typeface current = tv.getTypeface();
                int style = current != null ? current.getStyle() : Typeface.NORMAL;
                tv.setTypeface(Typeface.create(base, style));
                tv.setTag(com.termux.R.id.font_manager_applied, key);
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) apply(g.getChildAt(i), base);
        }
    }

    /**
     * Applies the UI font to every activity automatically, including views added later
     * (list rows, fragments). Call once from {@code Application.onCreate()}.
     */
    public static void install(Application app) {
        app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity a, Bundle b) {}
            @Override public void onActivityStarted(Activity a) {}
            @Override public void onActivityPaused(Activity a) {}
            @Override public void onActivityStopped(Activity a) {}
            @Override public void onActivitySaveInstanceState(Activity a, Bundle b) {}
            @Override public void onActivityDestroyed(Activity a) {}

            @Override
            public void onActivityResumed(Activity a) {
                final View decor = a.getWindow().getDecorView();
                applyUi(a, decor);
                if (decor.getTag(KEY_TAG) != null) return;
                decor.setTag(KEY_TAG, Boolean.TRUE);
                decor.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override public void onGlobalLayout() { applyUi(a, decor); }
                });
            }
        });
    }

    /** Marks decor views that already have the layout listener (tag keys must be resource ids). */
    private static final int KEY_TAG = com.termux.R.id.font_manager_tag;
}
