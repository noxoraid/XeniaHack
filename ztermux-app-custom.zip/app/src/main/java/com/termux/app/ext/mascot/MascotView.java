package com.termux.app.ext.mascot;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.LinearInterpolator;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.termux.R;

import java.util.Random;

/**
 * Offline, vector-drawn mascot: a black hexagon with expressive eyes (inspired by Rive style UI characters).
 * Everything is drawn on a {@link Canvas}; no assets, no network.
 */
public class MascotView extends View {

    public enum Expression { NEUTRAL, HAPPY, SURPRISED, WINK, SLEEPY, CURIOUS, SAD }

    private final Paint mBodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mRimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mEyePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mEyeStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path mHex = new Path();
    private final RectF mRect = new RectF();
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final Random mRandom = new Random();

    private Expression mExpression = Expression.NEUTRAL;
    private float mBlink;       // 0 = eyes open, 1 = closed
    private float mBob;         // 0..1 phase
    private float mLookX, mLookY; // -1..1
    private ValueAnimator mBobAnimator;
    private ValueAnimator mBlinkAnimator;
    private ValueAnimator mLookAnimator;

    private final Runnable mBlinkRunnable = new Runnable() {
        @Override public void run() {
            blinkOnce();
            mHandler.postDelayed(this, 2400 + mRandom.nextInt(3200));
        }
    };
    private final Runnable mRevertRunnable = () -> setExpressionInternal(Expression.NEUTRAL);
    private final Runnable mLookResetRunnable = () -> animateLook(0f, 0f);

    public MascotView(Context context) { this(context, null); }

    public MascotView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mBodyPaint.setStyle(Paint.Style.FILL);
        mBodyPaint.setColor(ContextCompat.getColor(context, R.color.mascot_body));
        mRimPaint.setStyle(Paint.Style.STROKE);
        mRimPaint.setColor(ContextCompat.getColor(context, R.color.mascot_rim));
        mEyePaint.setStyle(Paint.Style.FILL);
        mEyePaint.setColor(ContextCompat.getColor(context, R.color.mascot_eye));
        mEyeStroke.setStyle(Paint.Style.STROKE);
        mEyeStroke.setStrokeCap(Paint.Cap.ROUND);
        mEyeStroke.setColor(ContextCompat.getColor(context, R.color.mascot_eye));
    }

    // ------------------------------------------------------------------ public

    public Expression getExpression() { return mExpression; }

    /** Show an expression; if {@code holdMs > 0} it reverts to NEUTRAL afterwards. */
    public void setExpression(@NonNull Expression expression, long holdMs) {
        mHandler.removeCallbacks(mRevertRunnable);
        setExpressionInternal(expression);
        if (holdMs > 0 && expression != Expression.NEUTRAL) mHandler.postDelayed(mRevertRunnable, holdMs);
    }

    /** Look in a direction (-1..1 each axis) for a moment, e.g. towards where the mascot is moving. */
    public void lookTo(float x, float y, long holdMs) {
        animateLook(clamp(x), clamp(y));
        mHandler.removeCallbacks(mLookResetRunnable);
        if (holdMs > 0) mHandler.postDelayed(mLookResetRunnable, holdMs);
    }

    /** Squash-and-bounce reaction. */
    public void pulse() {
        animate().cancel();
        setScaleX(1f);
        setScaleY(1f);
        animate().scaleX(1.18f).scaleY(0.86f).setDuration(110).withEndAction(() ->
            animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(new BounceInterpolator()).start()).start();
    }

    // ----------------------------------------------------------------- lifecycle

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        mBobAnimator = ValueAnimator.ofFloat(0f, 1f);
        mBobAnimator.setDuration(2600);
        mBobAnimator.setRepeatCount(ValueAnimator.INFINITE);
        mBobAnimator.setInterpolator(new LinearInterpolator());
        mBobAnimator.addUpdateListener(a -> { mBob = (float) a.getAnimatedValue(); invalidate(); });
        mBobAnimator.start();
        mHandler.postDelayed(mBlinkRunnable, 1800);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (mBobAnimator != null) mBobAnimator.cancel();
        if (mBlinkAnimator != null) mBlinkAnimator.cancel();
        if (mLookAnimator != null) mLookAnimator.cancel();
        animate().cancel();
        mHandler.removeCallbacksAndMessages(null);
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        final float w = getWidth(), h = getHeight();
        final float s = Math.min(w, h);
        if (s <= 0) return;

        final float bob = (float) Math.sin(mBob * 2 * Math.PI) * s * 0.03f;
        final float cx = w / 2f, cy = h / 2f + bob;
        final float r = s * 0.44f;

        // Hexagon (pointy left/right, flat top/bottom) with softly rounded corners.
        mHex.reset();
        for (int i = 0; i < 6; i++) {
            float angle = (float) Math.toRadians(60 * i);
            float x = cx + r * (float) Math.cos(angle);
            float y = cy + r * (float) Math.sin(angle);
            if (i == 0) mHex.moveTo(x, y); else mHex.lineTo(x, y);
        }
        mHex.close();
        mBodyPaint.setPathEffect(new CornerPathEffect(r * 0.22f));
        mRimPaint.setPathEffect(new CornerPathEffect(r * 0.22f));
        mRimPaint.setStrokeWidth(Math.max(1.5f, s * 0.035f));
        canvas.drawPath(mHex, mBodyPaint);
        canvas.drawPath(mHex, mRimPaint);

        // Eyes
        final float eyeDx = r * 0.36f;
        final float ey = cy - r * 0.02f + mLookY * r * 0.10f;
        final float lx = cx - eyeDx + mLookX * r * 0.12f;
        final float rx = cx + eyeDx + mLookX * r * 0.12f;
        mEyeStroke.setStrokeWidth(Math.max(2f, r * 0.11f));

        switch (mExpression) {
            case HAPPY:
                drawArcEye(canvas, lx, ey, r);
                drawArcEye(canvas, rx, ey, r);
                break;
            case WINK:
                drawOvalEye(canvas, lx, ey, r * 0.20f, r * 0.34f, 0f);
                drawArcEye(canvas, rx, ey, r);
                break;
            case SURPRISED:
                drawOvalEye(canvas, lx, ey, r * 0.27f, r * 0.42f, 0f);
                drawOvalEye(canvas, rx, ey, r * 0.27f, r * 0.42f, 0f);
                break;
            case SLEEPY:
                drawLineEye(canvas, lx, ey + r * 0.05f, r);
                drawLineEye(canvas, rx, ey + r * 0.05f, r);
                break;
            case CURIOUS:
                drawOvalEye(canvas, lx, ey, r * 0.15f, r * 0.30f, -24f);
                drawOvalEye(canvas, rx, ey, r * 0.15f, r * 0.30f, 24f);
                break;
            case SAD:
                drawOvalEye(canvas, lx, ey + r * 0.04f, r * 0.17f, r * 0.30f, 20f);
                drawOvalEye(canvas, rx, ey + r * 0.04f, r * 0.17f, r * 0.30f, -20f);
                break;
            case NEUTRAL:
            default:
                drawOvalEye(canvas, lx, ey, r * 0.20f, r * 0.34f, 0f);
                drawOvalEye(canvas, rx, ey, r * 0.20f, r * 0.34f, 0f);
                break;
        }
    }

    private void drawOvalEye(Canvas c, float x, float y, float halfW, float halfH, float rotation) {
        float hh = Math.max(halfH * 0.08f, halfH * (1f - mBlink));
        mRect.set(x - halfW, y - hh, x + halfW, y + hh);
        c.save();
        c.rotate(rotation, x, y);
        c.drawOval(mRect, mEyePaint);
        c.restore();
    }

    private void drawArcEye(Canvas c, float x, float y, float r) {
        float half = r * 0.17f;
        mRect.set(x - half, y - half * 0.6f, x + half, y + half * 1.4f);
        c.drawArc(mRect, 180f, 180f, false, mEyeStroke);
    }

    private void drawLineEye(Canvas c, float x, float y, float r) {
        float half = r * 0.17f;
        c.drawLine(x - half, y, x + half, y, mEyeStroke);
    }

    // ------------------------------------------------------------------ helpers

    private void setExpressionInternal(Expression e) {
        mExpression = e;
        invalidate();
    }

    private void blinkOnce() {
        if (mExpression != Expression.NEUTRAL && mExpression != Expression.SURPRISED
            && mExpression != Expression.CURIOUS && mExpression != Expression.SAD) return;
        if (mBlinkAnimator != null) mBlinkAnimator.cancel();
        mBlinkAnimator = ValueAnimator.ofFloat(0f, 1f, 0f);
        mBlinkAnimator.setDuration(190);
        mBlinkAnimator.addUpdateListener(a -> { mBlink = (float) a.getAnimatedValue(); invalidate(); });
        mBlinkAnimator.start();
    }

    private void animateLook(float toX, float toY) {
        if (mLookAnimator != null) mLookAnimator.cancel();
        final float fromX = mLookX, fromY = mLookY;
        mLookAnimator = ValueAnimator.ofFloat(0f, 1f);
        mLookAnimator.setDuration(200);
        mLookAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        mLookAnimator.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            mLookX = fromX + (toX - fromX) * t;
            mLookY = fromY + (toY - fromY) * t;
            invalidate();
        });
        mLookAnimator.start();
    }

    private static float clamp(float v) { return Math.max(-1f, Math.min(1f, v)); }
}
