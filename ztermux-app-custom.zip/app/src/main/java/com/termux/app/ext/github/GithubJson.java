package com.termux.app.ext.github;

import org.json.JSONException;
import org.json.JSONObject;

final class GithubJson {

    private GithubJson() {}

    static JSONObject of(Object... pairs) {
        JSONObject out = new JSONObject();
        try {
            for (int i = 0; i + 1 < pairs.length; i += 2) out.put((String) pairs[i], pairs[i + 1]);
        } catch (JSONException e) {
            throw new IllegalArgumentException(e);
        }
        return out;
    }

    static JSONObject removal(String path) {
        return of("path", path, "mode", "100644", "type", "blob", "sha", JSONObject.NULL);
    }
}
