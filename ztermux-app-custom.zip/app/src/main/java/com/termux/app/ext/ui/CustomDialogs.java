package com.termux.app.ext.ui;

import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.termux.R;
import com.termux.app.ext.font.FontManager;

import java.util.List;

/**
 * Clean, custom-styled popup dialogs (input / confirm / info / action menu).
 * The same helper serves both the dark drawer ({@code light = false}) and the light File Manager ({@code light = true}).
 */
public final class CustomDialogs {

    public interface OnText { void onText(@NonNull String text); }
    public interface OnPick { void onPick(int index); }

    /** One row of an action menu. */
    public static final class MenuEntry {
        public final String label;
        @DrawableRes public final int icon;
        public final boolean destructive;

        public MenuEntry(String label, @DrawableRes int icon, boolean destructive) {
            this.label = label;
            this.icon = icon;
            this.destructive = destructive;
        }

        public MenuEntry(String label, @DrawableRes int icon) { this(label, icon, false); }
    }

    private static final class Palette {
        final int card, text, textDim, field, accent, accentText, danger;

        Palette(boolean light) {
            if (light) {
                card = 0xFFFFFFFF; text = 0xFF17181C; textDim = 0xFF6B7280; field = 0xFFF1F2F5;
                accent = 0xFF17181C; accentText = 0xFFFFFFFF; danger = 0xFFD93025;
            } else {
                card = 0xFF1A1C21; text = 0xFFF2F3F5; textDim = 0xFF9AA0AB; field = 0xFF262A32;
                accent = 0xFFFFD54A; accentText = 0xFF17181C; danger = 0xFFFF6B6B;
            }
        }
    }

    private static final class Holder {
        Dialog dialog;
        View view;
    }

    private CustomDialogs() {}

    // ------------------------------------------------------------------ input

    public static void input(Context context, boolean light, String title, @Nullable String hint,
                             @Nullable String initial, String positiveLabel, @NonNull OnText onPositive) {
        input(context, light, title, hint, initial, positiveLabel, null, null, onPositive);
    }

    /** Text input popup. {@code neutralLabel}/{@code onNeutral} are optional (e.g. "Failsafe"). */
    public static void input(Context context, boolean light, String title, @Nullable String hint,
                             @Nullable String initial, String positiveLabel,
                             @Nullable String neutralLabel, @Nullable OnText onNeutral,
                             @NonNull OnText onPositive) {
        Palette p = new Palette(light);
        Holder h = create(context, p, title);

        EditText input = h.view.findViewById(R.id.dlg_input);
        input.setVisibility(View.VISIBLE);
        input.setHint(hint);
        input.setTextColor(p.text);
        input.setHintTextColor(p.textDim);
        input.setBackground(round(p.field, dp(context, 12)));
        if (initial != null) {
            input.setText(initial);
            input.setSelection(initial.length());
        }

        final Runnable accept = () -> {
            h.dialog.dismiss();
            onPositive.onText(input.getText().toString());
        };
        styleNegative(h, context, p, context.getString(R.string.dlg_cancel));
        stylePositive(h, context, p, positiveLabel, false, accept);
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) { accept.run(); return true; }
            return false;
        });

        if (neutralLabel != null && onNeutral != null) {
            TextView neutral = h.view.findViewById(R.id.dlg_neutral);
            neutral.setVisibility(View.VISIBLE);
            neutral.setText(neutralLabel);
            neutral.setTextColor(p.textDim);
            neutral.setBackground(ripple(Color.TRANSPARENT, dp(context, 12), p.textDim));
            neutral.setOnClickListener(v -> {
                h.dialog.dismiss();
                onNeutral.onText(input.getText().toString());
            });
        }

        Window window = h.dialog.getWindow();
        if (window != null) {
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        }
        show(h);
        input.requestFocus();
    }

    // ---------------------------------------------------------------- confirm

    public static void confirm(Context context, boolean light, String title, @Nullable String message,
                               String positiveLabel, boolean destructive, @NonNull Runnable onPositive) {
        Palette p = new Palette(light);
        Holder h = create(context, p, title);
        if (message != null) {
            TextView msg = h.view.findViewById(R.id.dlg_message);
            msg.setVisibility(View.VISIBLE);
            msg.setText(message);
            msg.setTextColor(p.textDim);
        }
        styleNegative(h, context, p, context.getString(R.string.dlg_cancel));
        stylePositive(h, context, p, positiveLabel, destructive, () -> {
            h.dialog.dismiss();
            onPositive.run();
        });
        show(h);
    }

    /** Message-only popup with a single button. */
    public static void info(Context context, boolean light, String title, String message) {
        Palette p = new Palette(light);
        Holder h = create(context, p, title);
        TextView msg = h.view.findViewById(R.id.dlg_message);
        msg.setVisibility(View.VISIBLE);
        msg.setText(message);
        msg.setTextColor(p.textDim);
        h.view.findViewById(R.id.dlg_negative).setVisibility(View.GONE);
        stylePositive(h, context, p, context.getString(R.string.dlg_ok), false, h.dialog::dismiss);
        show(h);
    }

    // ------------------------------------------------------------------- menu

    /** Action menu popup (used for the file context menu). */
    public static void menu(Context context, boolean light, @Nullable String title,
                            @NonNull List<MenuEntry> entries, @NonNull OnPick onPick) {
        Palette p = new Palette(light);
        Holder h = create(context, p, title);
        if (title == null) h.view.findViewById(R.id.dlg_title).setVisibility(View.GONE);
        h.view.findViewById(R.id.dlg_buttons).setVisibility(View.GONE);

        LinearLayout content = h.view.findViewById(R.id.dlg_content);
        content.setVisibility(View.VISIBLE);

        ScrollView scroll = new ScrollView(context);
        LinearLayout column = new LinearLayout(context);
        column.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(column, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));

        for (int i = 0; i < entries.size(); i++) {
            final int index = i;
            MenuEntry e = entries.get(i);
            int color = e.destructive ? p.danger : p.text;

            LinearLayout row = new LinearLayout(context);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(context, 8), 0, dp(context, 8), 0);
            row.setBackground(ripple(Color.TRANSPARENT, dp(context, 12), color));
            row.setClickable(true);
            row.setOnClickListener(v -> {
                h.dialog.dismiss();
                onPick.onPick(index);
            });

            if (e.icon != 0) {
                ImageView icon = new ImageView(context);
                icon.setImageResource(e.icon);
                icon.setColorFilter(color);
                row.addView(icon, new LinearLayout.LayoutParams(dp(context, 22), dp(context, 22)));
            }
            TextView label = new TextView(context);
            label.setText(e.label);
            label.setTextColor(color);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMarginStart(dp(context, 14));
            row.addView(label, lp);

            column.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 50)));
        }
        show(h);
    }

    // --------------------------------------------------------------- internals

    private static Holder create(Context context, Palette p, @Nullable String title) {
        Holder h = new Holder();
        h.dialog = new Dialog(context);
        h.dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        h.view = LayoutInflater.from(context).inflate(R.layout.dialog_custom, null, false);
        h.view.setBackground(round(p.card, dp(context, 24)));
        h.dialog.setContentView(h.view);

        TextView titleView = h.view.findViewById(R.id.dlg_title);
        titleView.setText(title);
        titleView.setTextColor(p.text);

        Window window = h.dialog.getWindow();
        if (window != null) window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return h;
    }

    private static void show(Holder h) {
        FontManager.applyUi(h.view.getContext(), h.view);
        h.dialog.show();
        Window window = h.dialog.getWindow();
        if (window != null) {
            int width = (int) (h.view.getResources().getDisplayMetrics().widthPixels * 0.88f);
            window.setLayout(Math.min(width, dp(h.view.getContext(), 420)), WindowManager.LayoutParams.WRAP_CONTENT);
            window.setDimAmount(0.55f);
        }
    }

    private static void styleNegative(Holder h, Context c, Palette p, String label) {
        TextView negative = h.view.findViewById(R.id.dlg_negative);
        negative.setText(label);
        negative.setTextColor(p.textDim);
        negative.setBackground(ripple(Color.TRANSPARENT, dp(c, 12), p.textDim));
        negative.setOnClickListener(v -> h.dialog.dismiss());
    }

    private static void stylePositive(Holder h, Context c, Palette p, String label, boolean destructive, Runnable action) {
        TextView positive = h.view.findViewById(R.id.dlg_positive);
        positive.setText(label);
        positive.setTextColor(destructive ? 0xFFFFFFFF : p.accentText);
        positive.setBackground(ripple(destructive ? p.danger : p.accent, dp(c, 12), 0xFF808080));
        positive.setOnClickListener(v -> action.run());
    }

    private static GradientDrawable round(int color, int radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusPx);
        return d;
    }

    private static RippleDrawable ripple(int fill, int radiusPx, int rippleColor) {
        GradientDrawable content = round(fill, radiusPx);
        GradientDrawable mask = round(0xFFFFFFFF, radiusPx);
        int rc = (rippleColor & 0x00FFFFFF) | 0x33000000;
        return new RippleDrawable(ColorStateList.valueOf(rc), content, mask);
    }

    private static int dp(Context c, int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }
}
