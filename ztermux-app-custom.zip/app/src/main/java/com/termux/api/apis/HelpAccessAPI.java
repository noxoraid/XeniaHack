package com.termux.api.apis;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.JsonWriter;

import androidx.core.content.ContextCompat;

import com.termux.api.TermuxApiReceiver;
import com.termux.api.util.ResultReturner;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HelpAccessAPI {

    private static final String NONE = "NONE";
    private static final String WRITE_SETTINGS = "WRITE_SETTINGS";
    private static final String NOTIFICATION_ACCESS = "NOTIFICATION_ACCESS";
    private static final String STORAGE = "STORAGE";

    private static final String[][] ENTRIES = {
        {"TELEPON", "termux-telephony-call", "telepon sebuah nomor", "CALL_PHONE"},
        {"TELEPON", "termux-telephony-deviceinfo", "info operator dan perangkat", "READ_PHONE_STATE"},
        {"TELEPON", "termux-telephony-cellinfo", "info menara seluler", "ACCESS_COARSE_LOCATION"},

        {"LOKASI & JARINGAN", "termux-location", "posisi GPS / jaringan", "ACCESS_FINE_LOCATION"},
        {"LOKASI & JARINGAN", "termux-wifi-scaninfo", "scan WiFi sekitar", "ACCESS_FINE_LOCATION"},
        {"LOKASI & JARINGAN", "termux-wifi-connectioninfo", "info WiFi yang tersambung", NONE},
        {"LOKASI & JARINGAN", "termux-wifi-enable", "nyalakan / matikan WiFi", NONE},

        {"KAMERA & MIKROFON", "termux-camera-photo", "ambil foto", "CAMERA"},
        {"KAMERA & MIKROFON", "termux-camera-info", "info kamera", NONE},
        {"KAMERA & MIKROFON", "termux-torch", "senter", NONE},
        {"KAMERA & MIKROFON", "termux-microphone-record", "rekam suara", "RECORD_AUDIO"},
        {"KAMERA & MIKROFON", "termux-speech-to-text", "suara jadi teks", "RECORD_AUDIO"},

        {"NOTIFIKASI & LAYAR", "termux-notification", "tampilkan notifikasi", NONE},
        {"NOTIFIKASI & LAYAR", "termux-notification-remove", "hapus notifikasi", NONE},
        {"NOTIFIKASI & LAYAR", "termux-notification-channel", "atur channel notifikasi", NONE},
        {"NOTIFIKASI & LAYAR", "termux-notification-list", "baca semua notifikasi yang masuk", NOTIFICATION_ACCESS},
        {"NOTIFIKASI & LAYAR", "termux-brightness", "atur kecerahan layar", WRITE_SETTINGS},
        {"NOTIFIKASI & LAYAR", "termux-toast", "tampilkan toast", NONE},
        {"NOTIFIKASI & LAYAR", "termux-dialog", "dialog input / pilihan", NONE},
        {"NOTIFIKASI & LAYAR", "termux-wallpaper", "ganti wallpaper", NONE},
        {"NOTIFIKASI & LAYAR", "termux-vibrate", "getarkan HP", NONE},

        {"PENYIMPANAN & FILE", "termux-storage-get", "pilih file lewat picker", NONE},
        {"PENYIMPANAN & FILE", "termux-saf-*", "akses folder pilihan lewat SAF", NONE},
        {"PENYIMPANAN & FILE", "termux-download", "unduh lewat DownloadManager", NONE},
        {"PENYIMPANAN & FILE", "termux-media-scan", "daftarkan file ke galeri", STORAGE},
        {"PENYIMPANAN & FILE", "termux-share", "bagikan file / teks", NONE},
        {"PENYIMPANAN & FILE", "termux-clipboard-get/set", "baca dan isi clipboard", NONE},

        {"PERANGKAT & SENSOR", "termux-battery-status", "status baterai", NONE},
        {"PERANGKAT & SENSOR", "termux-sensor", "baca sensor", NONE},
        {"PERANGKAT & SENSOR", "termux-audio-info", "info audio", NONE},
        {"PERANGKAT & SENSOR", "termux-volume", "atur volume", NONE},
        {"PERANGKAT & SENSOR", "termux-fingerprint", "verifikasi sidik jari", NONE},
        {"PERANGKAT & SENSOR", "termux-keystore", "keystore Android", NONE},
        {"PERANGKAT & SENSOR", "termux-nfc", "baca NFC", NONE},
        {"PERANGKAT & SENSOR", "termux-usb", "perangkat USB", NONE},
        {"PERANGKAT & SENSOR", "termux-infrared-*", "IR blaster", NONE},
        {"PERANGKAT & SENSOR", "termux-job-scheduler", "jadwalkan skrip", NONE},
        {"PERANGKAT & SENSOR", "termux-media-player", "putar audio", NONE},
        {"PERANGKAT & SENSOR", "termux-tts-speak", "text-to-speech", NONE},
    };

    public static void onReceive(TermuxApiReceiver apiReceiver, final Context context, final Intent intent) {
        final boolean json = intent.getBooleanExtra("json", false);
        final boolean color = intent.getBooleanExtra("color", false);

        if (json) {
            ResultReturner.returnData(apiReceiver, intent, new ResultReturner.ResultJsonWriter() {
                @Override
                public void writeJson(JsonWriter out) throws Exception {
                    out.beginArray();
                    for (String[] entry : ENTRIES) {
                        out.beginObject();
                        out.name("group").value(entry[0]);
                        out.name("command").value(entry[1]);
                        out.name("access").value(entry[2]);
                        out.name("permission").value(entry[3]);
                        out.name("granted").value(isGranted(context, entry[3]));
                        out.endObject();
                    }
                    out.endArray();
                }
            });
            return;
        }

        ResultReturner.returnData(apiReceiver, intent, new ResultReturner.ResultWriter() {
            @Override
            public void writeResult(PrintWriter out) {
                writeText(out, context, color);
            }
        });
    }

    private static void writeText(PrintWriter out, Context context, boolean color) {
        String reset = color ? "\u001b[0m" : "";
        String bold = color ? "\u001b[1m" : "";
        String dim = color ? "\u001b[2m" : "";
        String green = color ? "\u001b[32m" : "";
        String red = color ? "\u001b[31m" : "";

        int width = 0;
        for (String[] entry : ENTRIES) width = Math.max(width, entry[1].length());

        Map<String, List<String>> missing = new LinkedHashMap<>();
        String currentGroup = null;
        int granted = 0;
        int total = 0;

        out.println(bold + "TERMUX API - AKSES YANG TERSEDIA" + reset);
        out.println(dim + "OK = sudah diizinkan, -- = belum (popup izin muncul saat perintahnya dipakai)" + reset);

        for (String[] entry : ENTRIES) {
            if (!entry[0].equals(currentGroup)) {
                currentGroup = entry[0];
                out.println();
                out.println(bold + currentGroup + reset);
            }
            boolean ok = isGranted(context, entry[3]);
            total++;
            if (ok) granted++;
            else {
                List<String> commands = missing.get(entry[3]);
                if (commands == null) {
                    commands = new ArrayList<>();
                    missing.put(entry[3], commands);
                }
                commands.add(entry[1]);
            }
            String mark = ok ? green + "OK" + reset : red + "--" + reset;
            StringBuilder line = new StringBuilder("  ").append(mark).append(" ").append(entry[1]);
            for (int i = entry[1].length(); i < width + 2; i++) line.append(' ');
            line.append(dim).append(entry[2]).append(reset);
            out.println(line);
        }

        out.println();
        out.println(bold + "RINGKASAN" + reset);
        out.println("  " + granted + " dari " + total + " perintah siap dipakai");

        if (!missing.isEmpty()) {
            out.println();
            out.println(bold + "BELUM DIIZINKAN" + reset);
            for (Map.Entry<String, List<String>> item : missing.entrySet()) {
                out.println("  " + describe(item.getKey()));
                StringBuilder commands = new StringBuilder("    ");
                for (int i = 0; i < item.getValue().size(); i++) {
                    if (i > 0) commands.append(", ");
                    commands.append(item.getValue().get(i));
                }
                out.println(dim + commands + reset);
            }
        }
    }

    private static String describe(String key) {
        switch (key) {
            case WRITE_SETTINGS:
                return "Ubah pengaturan sistem (Settings > Apps > Termux > Modify system settings)";
            case NOTIFICATION_ACCESS:
                return "Akses notifikasi (Settings > Notification access > Termux)";
            case STORAGE:
                return "Akses penyimpanan (jalankan termux-setup-storage)";
            default:
                return key.replace(",", ", ");
        }
    }

    private static boolean isGranted(Context context, String key) {
        switch (key) {
            case NONE:
                return true;
            case WRITE_SETTINGS:
                return Settings.System.canWrite(context);
            case NOTIFICATION_ACCESS:
                ComponentName cn = new ComponentName(context, NotificationListAPI.NotificationService.class);
                String flat = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
                return flat != null && flat.contains(cn.flattenToString());
            case STORAGE:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return Environment.isExternalStorageManager();
                return check(context, "READ_EXTERNAL_STORAGE");
            default:
                for (String permission : key.split(",")) {
                    if (!check(context, permission)) return false;
                }
                return true;
        }
    }

    private static boolean check(Context context, String permission) {
        return ContextCompat.checkSelfPermission(context, "android.permission." + permission) == PackageManager.PERMISSION_GRANTED;
    }
}
