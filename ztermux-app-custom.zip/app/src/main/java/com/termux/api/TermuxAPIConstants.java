package com.termux.api;

import static com.termux.shared.termux.TermuxConstants.TERMUX_PACKAGE_NAME;

public class TermuxAPIConstants {

    public static final String TERMUX_API_RECEIVER_NAME = "com.termux.api.TermuxApiReceiver";

    public static final String TERMUX_API_FILE_SHARE_URI_AUTHORITY = TERMUX_PACKAGE_NAME + ".sharedfiles";

}
