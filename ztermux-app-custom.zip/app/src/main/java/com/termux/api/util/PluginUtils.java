package com.termux.api.util;

import android.content.Context;
import android.content.SharedPreferences;

public class PluginUtils {

    private static final String PREFS_NAME = "termux_api_bridge";
    private static final String KEY_LAST_REQUEST_CODE = "last_pending_intent_request_code";
    private static final int DEFAULT_REQUEST_CODE = 1000;

    public synchronized static int getLastPendingIntentRequestCode(final Context context) {
        if (context == null) return DEFAULT_REQUEST_CODE;

        SharedPreferences preferences = context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int next = preferences.getInt(KEY_LAST_REQUEST_CODE, DEFAULT_REQUEST_CODE) + 1;
        if (next == Integer.MAX_VALUE || next < 0) next = DEFAULT_REQUEST_CODE;

        preferences.edit().putInt(KEY_LAST_REQUEST_CODE, next).apply();
        return next;
    }

}
