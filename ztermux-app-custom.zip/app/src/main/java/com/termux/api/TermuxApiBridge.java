package com.termux.api;

import android.app.Application;
import android.content.Context;

import com.termux.api.util.ResultReturner;
import com.termux.shared.logger.Logger;
import com.termux.shared.termux.TermuxConstants;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public final class TermuxApiBridge {

    private static final String LOG_TAG = "TermuxApiBridge";

    private static final String[] HELP_SCRIPT_NAMES = {"termux-help-access", "termux-help-acces"};

    private static final String CLIENT_SCRIPT = ""
            + "#!/data/data/com.termux/files/usr/bin/sh\n"
            + "# termux-api client built into the Termux app.\n"
            + "# Talks to the receiver inside com.termux through named pipes: no com.termux.api package, no sockets.\n"
            + "if [ $# -lt 1 ]; then\n"
            + "  echo \"usage: termux-api API_METHOD [am extras...]\" >&2\n"
            + "  exit 2\n"
            + "fi\n"
            + "method=$1\n"
            + "shift\n"
            + "main=$$\n"
            + "tmp=${TMPDIR:-/data/data/com.termux/files/usr/tmp}\n"
            + "mkdir -p \"$tmp\"\n"
            + "base=\"$tmp/nxr-api.$main\"\n"
            + "out=\"$base.out\"\n"
            + "in=\"$base.in\"\n"
            + "ack=\"$out.ack\"\n"
            + "catpid=\n"
            + "inpid=\n"
            + "wdpid=\n"
            + "cleanup() {\n"
            + "  [ -n \"$catpid\" ] && kill \"$catpid\" 2>/dev/null\n"
            + "  [ -n \"$inpid\" ] && kill \"$inpid\" 2>/dev/null\n"
            + "  [ -n \"$wdpid\" ] && kill \"$wdpid\" 2>/dev/null\n"
            + "  rm -f \"$out\" \"$in\" \"$ack\"\n"
            + "}\n"
            + "trap cleanup EXIT\n"
            + "trap 'exit 130' INT TERM HUP\n"
            + "rm -f \"$out\" \"$in\" \"$ack\"\n"
            + "mkfifo \"$out\" \"$in\" || { echo \"termux-api: mkfifo gagal\" >&2; exit 1; }\n"
            + "cat \"$out\" &\n"
            + "catpid=$!\n"
            + "cat <&0 >\"$in\" &\n"
            + "inpid=$!\n"
            + "(\n"
            + "  sleep 10\n"
            + "  if [ ! -e \"$ack\" ]; then\n"
            + "    echo \"termux-api: app Termux tidak menerima perintah (receiver API tidak terpanggil).\" >&2\n"
            + "    kill \"$main\" 2>/dev/null\n"
            + "  fi\n"
            + ") &\n"
            + "wdpid=$!\n"
            + "res=$(am broadcast --user 0 -n com.termux/com.termux.api.TermuxApiReceiver \\\n"
            + "  --es api_method \"$method\" --es socket_output \"fifo:$out\" --es socket_input \"fifo:$in\" \"$@\" 2>&1)\n"
            + "case \"$res\" in\n"
            + "  *Exception*|*\"Error\"*) echo \"$res\" >&2 ;;\n"
            + "esac\n"
            + "wait \"$catpid\"\n";

    /** The package's termux-api-start/stop target com.termux.api/.KeepAliveService, which does not exist here. */
    private static final String KEEP_ALIVE_SCRIPT = "#!" + TermuxConstants.TERMUX_BIN_PREFIX_DIR_PATH + "/sh\n"
            + "echo \"Termux:API sudah menyatu dengan aplikasi Termux; tidak perlu dijalankan terpisah.\"\n";

    private static final String HELP_SCRIPT = "#!" + TermuxConstants.TERMUX_BIN_PREFIX_DIR_PATH + "/sh\n"
            + "API=" + TermuxConstants.TERMUX_LIBEXEC_PREFIX_DIR_PATH + "/termux-api\n"
            + "case \"$1\" in\n"
            + "  -h|--help)\n"
            + "    echo \"usage: termux-help-access [-j|--json]\"\n"
            + "    exit 0\n"
            + "    ;;\n"
            + "esac\n"
            + "if [ ! -x \"$API\" ]; then\n"
            + "  echo \"termux-api belum terpasang. Jalankan: pkg install termux-api\" >&2\n"
            + "  exit 1\n"
            + "fi\n"
            + "json=false\n"
            + "case \"$1\" in\n"
            + "  -j|--json) json=true ;;\n"
            + "esac\n"
            + "color=false\n"
            + "[ -t 1 ] && color=true\n"
            + "if command -v timeout >/dev/null 2>&1; then\n"
            + "  timeout 15 \"$API\" HelpAccess --ez json \"$json\" --ez color \"$color\"\n"
            + "  rc=$?\n"
            + "  if [ \"$rc\" -eq 124 ]; then\n"
            + "    echo \"termux-api tidak merespons dalam 15 detik (Termux belum menjawab socket API).\" >&2\n"
            + "    echo \"Tutup Termux dari recents, buka lagi, lalu coba ulang.\" >&2\n"
            + "  fi\n"
            + "  exit $rc\n"
            + "fi\n"
            + "exec \"$API\" HelpAccess --ez json \"$json\" --ez color \"$color\"\n";

    private static boolean sInitialized = false;

    private TermuxApiBridge() {
    }

    public static synchronized void init(Application application) {
        if (sInitialized) return;
        sInitialized = true;
        ResultReturner.setContext(application);
        SocketListener.createSocketListener(application);
        installScripts();
    }

    /**
     * Installs the built-in {@code termux-api} client over the stock one from the package, and an
     * apt hook that puts it back after every {@code pkg install/upgrade}.
     */
    public static void installScripts() {
        new Thread(() -> {
            try {
                File binDir = new File(TermuxConstants.TERMUX_BIN_PREFIX_DIR_PATH);
                if (!binDir.isDirectory()) return;

                byte[] help = HELP_SCRIPT.getBytes(StandardCharsets.UTF_8);
                for (String name : HELP_SCRIPT_NAMES) {
                    install(new File(binDir, name), help, true);
                }

                byte[] keepAlive = KEEP_ALIVE_SCRIPT.getBytes(StandardCharsets.UTF_8);
                for (String name : new String[]{"termux-api-start", "termux-api-stop"}) {
                    install(new File(binDir, name), keepAlive, true);
                }

                byte[] client = CLIENT_SCRIPT.getBytes(StandardCharsets.UTF_8);
                File keep = new File(TermuxConstants.TERMUX_PREFIX_DIR_PATH + "/share/nxr/termux-api-client");
                File libexecApi = new File(TermuxConstants.TERMUX_LIBEXEC_PREFIX_DIR_PATH + "/termux-api");
                install(keep, client, true);
                install(libexecApi, client, true);

                // In the package libexec/termux-api is a symlink to termux-api-broadcast: remove the link
                // first so the real binary is not overwritten through it.
                String hook = "DPkg::Post-Invoke { \"if [ -f " + keep.getPath() + " ]; then rm -f "
                        + libexecApi.getPath() + "; cp " + keep.getPath() + " " + libexecApi.getPath()
                        + " && chmod 700 " + libexecApi.getPath() + "; fi; true\"; };\n";
                install(new File(TermuxConstants.TERMUX_PREFIX_DIR_PATH + "/etc/apt/apt.conf.d/99-nxr-termux-api"),
                        hook.getBytes(StandardCharsets.UTF_8), false);
            } catch (Exception e) {
                Logger.logStackTraceWithMessage(LOG_TAG, "Failed to install helper scripts", e);
            }
        }, "termux-api-scripts").start();
    }

    private static void install(File target, byte[] content, boolean executable) throws IOException {
        File parent = target.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs()) return;
        if (target.isFile() && (!executable || target.canExecute()) && Arrays.equals(readAll(target), content)) return;
        // A different file (for example the stock termux-api binary) is replaced, not appended to.
        if (target.exists() && !target.delete()) Logger.logError(LOG_TAG, "Could not replace " + target);
        try (FileOutputStream out = new FileOutputStream(target)) {
            out.write(content);
        }
        target.setReadable(true, true);
        target.setWritable(true, true);
        target.setExecutable(executable, true);
    }

    private static byte[] readAll(File file) throws IOException {
        byte[] data = new byte[(int) file.length()];
        try (java.io.FileInputStream in = new java.io.FileInputStream(file)) {
            int offset = 0;
            while (offset < data.length) {
                int read = in.read(data, offset, data.length - offset);
                if (read < 0) break;
                offset += read;
            }
            if (offset < data.length) return Arrays.copyOf(data, offset);
        }
        return data;
    }
}
