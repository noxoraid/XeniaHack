package com.termux.api;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.LocalServerSocket;
import android.net.LocalSocket;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import com.termux.shared.logger.Logger;
import com.termux.shared.termux.TermuxConstants;

import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SocketListener {

    public static final String LISTEN_ADDRESS = TermuxConstants.TERMUX_API_PACKAGE_NAME + "://listen";
    private static final Pattern EXTRA_STRING = Pattern.compile("(-e|--es|--esa) +([^ ]+) +\"(.*?)(?<!\\\\)\"", Pattern.DOTALL);
    private static final Pattern EXTRA_BOOLEAN = Pattern.compile("--ez +([^ ]+) +([^ ]+)");
    private static final Pattern EXTRA_INT = Pattern.compile("--ei +([^ ]+) +(-?[0-9]+)");
    private static final Pattern EXTRA_FLOAT = Pattern.compile("--ef +([^ ]+) +(-?[0-9]+(?:\\.[0-9]+))");
    private static final Pattern EXTRA_INT_LIST = Pattern.compile("--eia +([^ ]+) +(-?[0-9]+(?:,-?[0-9]+)*)");
    private static final Pattern EXTRA_LONG_LIST = Pattern.compile("--ela +([^ ]+) +(-?[0-9]+(?:,-?[0-9]+)*)");
    private static final Pattern EXTRA_UNSUPPORTED = Pattern.compile("--e[^izs ] +[^ ]+ +[^ ]+");
    private static final Pattern ACTION = Pattern.compile("-a *([^ ]+)");
    
    private static final int READ_TIMEOUT_MS = 5000;
    private static final long RETRY_DELAY_MS = 1000;
    private static final ExecutorService WORKERS = Executors.newCachedThreadPool();

    private static Thread listener = null;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static final String LOG_TAG = "SocketListener";

    public static synchronized void createSocketListener(Application app) {
        if (listener != null && listener.isAlive()) return;
        listener = new Thread(() -> runServer(app), "termux-api-listener");
        listener.setDaemon(true);
        listener.start();
    }

    /**
     * Accept loop. Every connection is handled on its own thread so one slow or broken client can
     * never block the others, and the server socket is re-created if it ever dies.
     */
    private static void runServer(Application app) {
        while (true) {
            try (LocalServerSocket listen = new LocalServerSocket(LISTEN_ADDRESS)) {
                Logger.logInfo(LOG_TAG, "Listening on " + LISTEN_ADDRESS);
                while (true) {
                    final LocalSocket con = listen.accept();
                    try {
                        WORKERS.execute(() -> handleConnection(app, con));
                    } catch (RuntimeException t) {
                        try { con.close(); } catch (Exception ignored) { }
                        throw t;
                    }
                }
            }
            catch (Throwable t) {
                // Most common cause: address already in use (the separate Termux:API app is still installed).
                Logger.logStackTraceWithMessage(LOG_TAG, "Listener stopped, retrying", t);
                com.termux.app.ext.diagnostics.TermuxErrorJournal.record("api_listener",
                    "listener stopped: " + t, t);
                SystemClock.sleep(RETRY_DELAY_MS);
            }
        }
    }

    private static void handleConnection(Application app, LocalSocket con) {
        try (LocalSocket socket = con;
             DataInputStream in = new DataInputStream(socket.getInputStream());
             BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))) {
            // A client that connects but never sends its command must not be able to stall anything.
            socket.setSoTimeout(READ_TIMEOUT_MS);
            // only accept connections from Termux programs
            if (socket.getPeerCredentials().getUid() != app.getApplicationInfo().uid) {
                return;
            }
            try {
                //System.out.println("connection");
                int length = in.readUnsignedShort();
                byte[] b = new byte[length];
                in.readFully(b);
                String cmdline = new String(b, StandardCharsets.UTF_8);
        
                Intent intent = new Intent(app.getApplicationContext(), TermuxApiReceiver.class);
                //System.out.println(cmdline.replaceAll("--es socket_input \".*?\"","").replaceAll("--es socket_output \".*?\"",""));
                HashMap<String, String> stringExtras = new HashMap<>();
                HashMap<String, String[]> stringArrayExtras = new HashMap<>();
                HashMap<String, Boolean> booleanExtras = new HashMap<>();
                HashMap<String, Integer> intExtras = new HashMap<>();
                HashMap<String, Float> floatExtras = new HashMap<>();
                HashMap<String, int[]> intArrayExtras = new HashMap<>();
                HashMap<String, long[]> longArrayExtras = new HashMap<>();
                boolean err = false;
        
                // extract and remove the string extras first, so another argument embedded in a string isn't counted as an argument
                Matcher m = EXTRA_STRING.matcher(cmdline);
                while (m.find()) {
                    String option = m.group(1);
                    if ("-e".equals(option) || "--es".equals(option)) {
                        // unescape "
                        stringExtras.put(m.group(2), Objects.requireNonNull(m.group(3)).replaceAll("\\\\\"", "\""));
                    }
                    else {
                        // split the list
                        String[] list = Objects.requireNonNull(m.group(3)).split("(?<!\\\\),");
                        for (int i = 0; i < list.length; i++) {
                            /// unescape the ","
                            list[i] = list[i].replaceFirst("\\\\,", ",");
                        }
                        stringArrayExtras.put(m.group(2), list);
                    }
            
                }
                cmdline = m.replaceAll("");
        
                m = EXTRA_BOOLEAN.matcher(cmdline);
                while (m.find()) {
                    String value = m.group(2);
                    value = value != null ? value.toLowerCase() : null;
                    Boolean arg = null;

                    if ("true".equals(value) || "t".equals(value)) {
                        arg = true;
                    } else if ("false".equals(value) || "f".equals(value)) {
                        arg = false;
                    } else {
                        try {
                            if (value != null)
                                arg = Integer.decode(value) != 0;
                        } catch (NumberFormatException ex) {
                            // Ignore
                        }
                    }
                    if (arg == null) {
                        String msg = "Invalid boolean extra: " + m.group(0) + "\n";
                        Logger.logInfo(LOG_TAG, msg);
                        out.write(msg);
                        err = true;
                        break;
                    }
                    booleanExtras.put(m.group(1), arg);
                }
                cmdline = m.replaceAll("");
        
                m = EXTRA_INT.matcher(cmdline);
                while (m.find()) {
                    try {
                        intExtras.put(m.group(1), Integer.parseInt(Objects.requireNonNull(m.group(2))));
                    }
                    catch (NumberFormatException e) {
                        String msg = "Invalid integer extra: " + m.group(0) + "\n";
                        Logger.logInfo(LOG_TAG, msg);
                        out.write(msg);
                        err = true;
                        break;
                    }
                }
                cmdline = m.replaceAll("");
        
                m = EXTRA_FLOAT.matcher(cmdline);
                while (m.find()) {
                    try {
                        floatExtras.put(m.group(1), Float.parseFloat(Objects.requireNonNull(m.group(2))));
                    }
                    catch (NumberFormatException e) {
                        String msg = "Invalid float extra: " + m.group(0) + "\n";
                        Logger.logInfo(LOG_TAG, msg);
                        out.write(msg);
                        err = true;
                        break;
                    }
                }
                cmdline = m.replaceAll("");
        
                m = EXTRA_INT_LIST.matcher(cmdline);
                while (m.find()) {
                    try {
                        String[] parts = Objects.requireNonNull(m.group(2)).split(",");
                        int[] ints = new int[parts.length];
                        for (int i = 0; i < parts.length; i++) {
                            ints[i] = Integer.parseInt(parts[i]);
                        }
                        intArrayExtras.put(m.group(1), ints);
                    }
                    catch (NumberFormatException e) {
                        String msg = "Invalid int array extra: " + m.group(0) + "\n";
                        Logger.logInfo(LOG_TAG, msg);
                        out.write(msg);
                        err = true;
                        break;
                    }
                }
                cmdline = m.replaceAll("");
        
                m = EXTRA_LONG_LIST.matcher(cmdline);
                while (m.find()) {
                    try {
                        String[] parts = Objects.requireNonNull(m.group(2)).split(",");
                        long[] longs = new long[parts.length];
                        for (int i = 0; i < parts.length; i++) {
                            longs[i] = Long.parseLong(parts[i]);
                        }
                        longArrayExtras.put(m.group(1), longs);
                    }
                    catch (NumberFormatException e) {
                        String msg = "Invalid long array extra: " + m.group(0) + "\n";
                        Logger.logInfo(LOG_TAG, msg);
                        out.write(msg);
                        err = true;
                        break;
                    }
                }
                cmdline = m.replaceAll("");
        
                m = ACTION.matcher(cmdline);
                while (m.find()) {
                    intent.setAction(m.group(1));
                }
                cmdline = m.replaceAll("");
        
                m = EXTRA_UNSUPPORTED.matcher(cmdline);
                if (m.find()) {
                    String msg = "Unsupported argument type: " + m.group(0) + "\n";
                    Logger.logInfo(LOG_TAG, msg);
                    out.write(msg);
                    err = true;
                }
                cmdline = m.replaceAll("");
        
                // check if there are any non-whitespace characters left after parsing all the options
                cmdline = cmdline.replaceAll("\\s", "");
                if (!"".equals(cmdline)) {
                    String msg = "Unsupported options: " + cmdline + "\n";
                    Logger.logInfo(LOG_TAG, msg);
                    out.write(msg);
                    err = true;
                }
        
                if (err) {
                    out.flush();
                    return;
                }
        
                // set the intent extras
                for (Map.Entry<String, String> e : stringExtras.entrySet()) {
                    intent.putExtra(e.getKey(), e.getValue());
                }
                for (Map.Entry<String, String[]> e : stringArrayExtras.entrySet()) {
                    intent.putExtra(e.getKey(), e.getValue());
                }
                for (Map.Entry<String, Integer> e : intExtras.entrySet()) {
                    intent.putExtra(e.getKey(), e.getValue());
                }
                for (Map.Entry<String, Boolean> e : booleanExtras.entrySet()) {
                    intent.putExtra(e.getKey(), e.getValue());
                }
                for (Map.Entry<String, Float> e : floatExtras.entrySet()) {
                    intent.putExtra(e.getKey(), e.getValue());
                }
                for (Map.Entry<String, int[]> e : intArrayExtras.entrySet()) {
                    intent.putExtra(e.getKey(), e.getValue());
                }
                for (Map.Entry<String, long[]> e : longArrayExtras.entrySet()) {
                    intent.putExtra(e.getKey(), e.getValue());
                }
                intent.putExtra("nxr_t0", SystemClock.elapsedRealtime());
                dispatch(app.getApplicationContext(), intent);
                // send a null byte as a sign that the arguments have been successfully received, parsed and the broadcast receiver is called
                socket.getOutputStream().write(0);
                socket.getOutputStream().flush();
            }
            catch (Exception e) {
                Logger.logStackTraceWithMessage(LOG_TAG, "Error parsing arguments", e);
                out.write("Exception in the plugin\n");
                out.flush();
            }
        }
        catch (Throwable e) {
            Logger.logStackTraceWithMessage(LOG_TAG, "Connection error", e);
        }
    }

    private static void dispatch(final Context context, final Intent intent) {
        final boolean posted = MAIN.post(() -> {
            try {
                intent.putExtra("nxr_t1", SystemClock.elapsedRealtime());
                new TermuxApiReceiver().onReceive(context, intent);
            } catch (Throwable t) {
                Logger.logStackTraceWithMessage(LOG_TAG, "Direct dispatch failed", t);
                context.sendOrderedBroadcast(intent, null);
            }
        });
        if (!posted) context.sendOrderedBroadcast(intent, null);
    }

}
