# Custom Termux features. (arm64-v8a)

All new code lives in `app/src/main/java/com/termux/app/ext/` so upstream merges stay easy.

| Feature | Files |
|---|---|
| Custom popups (input / confirm / menu) | `ext/ui/CustomDialogs.java`, `res/layout/dialog_custom.xml` |
| Redesigned drawer (rename / close per session, File Manager entry) | `res/layout/activity_termux.xml`, `res/layout/item_terminal_sessions_list.xml`, `terminal/TermuxSessionsListViewController.java`, `terminal/TermuxTerminalSessionActivityClient.java` (`renameSession`, `closeSession`), `TermuxActivity.java` |
| File Manager (light theme) | `ext/filemanager/*`, `res/layout/activity_file_manager.xml`, `res/layout/item_file_entry.xml`, theme `Theme.TermuxFileManager` in `res/values/themes.xml` |
| Editor with line numbers | `ext/editor/EditorActivity.java`, `ext/editor/CodeEditText.java`, `res/layout/activity_editor.xml` |
| Offline mascot | `ext/mascot/MascotView.java` (canvas drawing), `MascotWidget.java` (roaming, bubble, drag, random chatter), `MascotEvents.java`, `MascotSound.java` (built-in SFX via SoundPool, `res/raw/sfx_*.wav`), `MascotSettings.java` (hide bot / text / sound) |
| Custom fonts (Custom Settings v2) | `ext/font/FontManager.java`, `ext/font/CustomSettingsV2Activity.java`, `res/layout/activity_custom_settings_v2.xml`, `res/layout/view_font_section.xml`, drawer entry in `activity_termux.xml` / `TermuxActivity.java`, `TermuxApplication.java` (`FontManager.install`), `CodeEditText.java` (uses terminal font), `CustomDialogs.java` |
| GitHub integration | `ext/github/*` (Hub, RepoBrowser, FileEdit, Actions, Log activities, GitShell, GithubRestClient, GithubCommitWriter), `res/layout/activity_github_*.xml`, chip in `activity_file_manager.xml` |
| Read mode | `ext/terminal/TerminalReadLock.java`, drawer row in `activity_termux.xml`, gates in `TermuxTerminalViewClient` / `TermuxTerminalSessionActivityClient` |
| Shared mascot spot | `ext/mascot/MascotSharedSpot.java` |
| Termux:API built in | `com/termux/api/*` (receiver, `SocketListener`, `apis/*`, `TermuxApiBridge`), `apis/HelpAccessAPI.java` (`termux-help-access`), `AndroidManifest.xml` (permissions + API components), `res/values/api_styles.xml`, `res/values/api_strings.xml`, `res/layout/dialog_*.xml`, `res/drawable/ic_*_black_24dp.xml`, `app/build.gradle` (biometric, media, documentfile) |
| Build / CI cleanup | `app/build.gradle` (abiFilters `arm64-v8a`, only the aarch64 bootstrap), `terminal-emulator/build.gradle`, `.github/workflows/build.yml` (the only workflow, runs on `main`) |

Storage: Termux home = `/data/data/com.termux/files/home`, shared storage = `/storage/emulated/0`.
The manifest already declares `READ/WRITE_EXTERNAL_STORAGE` and `MANAGE_EXTERNAL_STORAGE`; the File Manager asks for
"All files access" on Android 11+ (runtime permissions below that) when the Shared Storage tab is opened.

Build: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/termux-app_*_arm64-v8a.apk`

Fonts: Drawer -> "Custom Settings v2" picks a Google Font separately for the terminal (+ editor) and for the UI.
Fonts are downloaded at runtime from the Google Fonts CSS API (internet needed once per font).
Terminal font is copied to `~/.termux/font.ttf`; UI font is cached in `/data/data/com.termux/app_fonts/` and applied to all TextViews.

Mascot sound: random lines (EN + ID) with a bubble plus short sound effects (swoosh when it roams, blink, pop, boing on tap, chirp when it chats). No TTS.
Custom Settings v2 has switches: Hide bot / Hide text / Hide sound, and a Back button.
File Manager: top menu has Select / Select all; the selection menu has Select all / Unselect all / Done (works in every storage tab).

Changelog: `app/src/main/assets/CHANGELOG.md`, shown in-app (Custom Settings v2 -> Changelog).
Every update: add a new entry at the top of that file and bump `custom_version_name` in `res/values/strings_ext.xml`.
