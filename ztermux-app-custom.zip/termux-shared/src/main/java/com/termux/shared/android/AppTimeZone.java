package com.termux.shared.android;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * One time zone for the whole app: UI dates, logs, tasks and the TZ variable of new shell sessions.
 * An empty id means "follow the device".
 */
public final class AppTimeZone {

    public static final String PREFS = "app_time_zone";
    public static final String KEY_ID = "zone_id";
    public static final String DEFAULT_ID = "Asia/Jakarta";

    private static volatile String sDeviceId = TimeZone.getDefault().getID();
    private static volatile String sId = "";

    private AppTimeZone() {}

    /** Call once at startup (Application.onCreate) and again after changing the zone. */
    public static void load(@NonNull Context context) {
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sId = prefs.getString(KEY_ID, DEFAULT_ID);
        apply();
    }

    public static void set(@NonNull Context context, @NonNull String id) {
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ID, id).apply();
        sId = id;
        apply();
    }

    private static void apply() {
        TimeZone.setDefault(zone());
    }

    /** Stored id; empty = follow device. */
    @NonNull
    public static String id() {
        return sId;
    }

    public static boolean isValid(@NonNull String id) {
        if (id.isEmpty()) return true;
        for (String known : TimeZone.getAvailableIDs()) if (known.equals(id)) return true;
        return false;
    }

    @NonNull
    public static TimeZone zone() {
        return sId.isEmpty() ? TimeZone.getTimeZone(sDeviceId) : TimeZone.getTimeZone(sId);
    }

    @NonNull
    public static String effectiveId() {
        return sId.isEmpty() ? sDeviceId : sId;
    }

    /** Value for the TZ environment variable of shell sessions. */
    @NonNull
    public static String shellValue(@NonNull Context context) {
        String id = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ID, DEFAULT_ID);
        return id.isEmpty() ? sDeviceId : id;
    }

    @NonNull
    public static String format(long millis, @NonNull String pattern) {
        SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
        f.setTimeZone(zone());
        return f.format(new Date(millis));
    }

    /** "WIB", "CST", "GMT+8"… for the current zone. */
    @NonNull
    public static String shortName() {
        TimeZone zone = zone();
        String id = zone.getID();
        switch (id) {
            case "Asia/Jakarta": case "Asia/Pontianak": return "WIB";
            case "Asia/Makassar": return "WITA";
            case "Asia/Jayapura": return "WIT";
            default:
                return zone.getDisplayName(zone.inDaylightTime(new Date()), TimeZone.SHORT, Locale.US);
        }
    }
}
