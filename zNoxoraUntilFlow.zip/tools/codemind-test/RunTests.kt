import com.untilyflow.app.CodeMindTests

fun main() {
    val cls = CodeMindTests::class.java
    var failed = 0
    var ran = 0
    for (m in cls.declaredMethods.sortedBy { it.name }) {
        if (m.annotations.none { it.annotationClass.simpleName == "Test" }) continue
        ran++
        try {
            m.invoke(cls.getDeclaredConstructor().newInstance())
            println("PASS ${m.name}")
        } catch (e: java.lang.reflect.InvocationTargetException) {
            failed++
            println("FAIL ${m.name}: ${e.targetException}")
            e.targetException.stackTrace.take(4).forEach { println("    at $it") }
        }
    }
    println("ran=$ran failed=$failed")
}
