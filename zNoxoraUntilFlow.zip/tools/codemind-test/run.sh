#!/bin/sh
set -e
cd "$(dirname "$0")"
KOTLINC="${KOTLINC:-kotlinc}"
APP=../../app/src/main/kotlin/com/untilyflow/app
OUT=/tmp/codemind-test
rm -rf "$OUT" && mkdir -p "$OUT"
KT="$(dirname "$(command -v "$KOTLINC")")/../lib/kotlin-test.jar"
PURE="CmJson CodeModel CmLang CodeScan CodeScanFallback CmGlob CodeIndexer CodeQuery ContextPack ContextTrim McpProtocol McpTools CodeAuto"
FILES=""
for f in $PURE; do FILES="$FILES $APP/codemind/$f.kt"; done
"$KOTLINC" $FILES $APP/files/TextGrep.kt ../../app/src/test/kotlin/com/untilyflow/app/*.kt JunitTestStub.kt RunTests.kt -cp "$KT" -include-runtime -d "$OUT/t.jar"
java -cp "$OUT/t.jar:$KT" RunTestsKt
