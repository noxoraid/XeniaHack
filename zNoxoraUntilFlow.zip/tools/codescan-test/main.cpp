#include <cstdio>
#include <cstdlib>
#include <string>

#include "codescan.h"

static int failures = 0;

static std::string scan(const std::string& text, int lang) {
    return nx::codeScan(reinterpret_cast<const uint8_t*>(text.data()), text.size(), lang);
}

static bool has(const std::string& out, const std::string& line) {
    return out.find("\n" + line + "\n") != std::string::npos || out.compare(0, line.size() + 1, line + "\n") == 0;
}

static bool hasSymbol(const std::string& out, const std::string& name) {
    size_t pos = 0;
    while (pos < out.size()) {
        size_t end = out.find('\n', pos);
        if (end == std::string::npos) end = out.size();
        std::string line = out.substr(pos, end - pos);
        if (line.compare(0, 2, "S\t") == 0 && line.find("\t" + name + "\t") != std::string::npos) return true;
        pos = end + 1;
    }
    return false;
}

static void expect(bool ok, const char* what) {
    if (!ok) {
        std::printf("FAIL %s\n", what);
        failures++;
    }
}

int main() {
    {
        std::string out = scan(
            "package a.b\n\nimport a.b.Foo\nimport x.y.*\n\n/* class Fake {\n fun nope() }\n*/\n"
            "data class User(val id: Int)\nsealed interface Shape\nenum class Color { Red }\n"
            "object Store {\n    fun load(path: String): Int = 1\n    private suspend fun <T> List<T>.pick(n: Int) {}\n}\n"
            "class Box {\n    companion object {\n        fun make() {}\n    }\n}\nval s = \"\"\"\nclass InString\n\"\"\"\nfun top() {\n    val x = if (a) 1 else 2\n}\n",
            nx::CodeKotlin);
        expect(has(out, "S\tclass\tUser\t9"), "kotlin data class");
        expect(has(out, "S\tinterface\tShape\t10"), "kotlin interface");
        expect(has(out, "S\tenum\tColor\t11"), "kotlin enum class");
        expect(has(out, "S\tobject\tStore\t12"), "kotlin object");
        expect(has(out, "S\tmethod\tload\t13"), "kotlin method");
        expect(has(out, "S\tmethod\tpick\t14"), "kotlin extension method");
        expect(has(out, "S\tobject\tCompanion\t17"), "kotlin companion");
        expect(has(out, "S\tfunction\ttop\t24"), "kotlin top function");
        expect(!has(out, "S\tclass\tFake\t6"), "kotlin comment ignored");
        expect(!hasSymbol(out, "InString"), "kotlin raw string ignored");
        expect(has(out, "I\ta.b.Foo") && has(out, "I\tx.y.*"), "kotlin imports");
    }
    {
        std::string out = scan(
            "import java.util.List;\nimport static org.junit.Assert.assertEquals;\n\npublic class Auth extends Base {\n"
            "    private int count = foo(1);\n    public static void main(String[] args) {\n        if (x) {\n            run(1);\n        }\n"
            "        Thread t = new Thread(() -> go());\n    }\n    List<String> names(int n) { return null; }\n    abstract void stop();\n}\n"
            "interface Port {}\nenum Mode { A }\nrecord Pair(int a, int b) {}\n",
            nx::CodeJava);
        expect(has(out, "S\tclass\tAuth\t4"), "java class");
        expect(has(out, "S\tmethod\tmain\t6"), "java main");
        expect(has(out, "S\tmethod\tnames\t12"), "java generic method");
        expect(has(out, "S\tmethod\tstop\t13"), "java abstract method");
        expect(has(out, "S\tinterface\tPort\t15") && has(out, "S\tenum\tMode\t16") && has(out, "S\tclass\tPair\t17") == false, "java types");
        expect(has(out, "S\trecord\tPair\t17"), "java record");
        expect(!hasSymbol(out, "foo") && !hasSymbol(out, "run") && !hasSymbol(out, "go"), "java calls ignored");
        expect(has(out, "I\tjava.util.List") && has(out, "I\torg.junit.Assert.assertEquals"), "java imports");
    }
    {
        std::string out = scan(
            "import React from 'react';\nimport './style.css';\nconst fs = require(\"fs\");\nexport * from './util';\n"
            "export default function boot(a) {}\nconst add = (a, b) => a + b;\nlet plain = 5;\nclass Panel {\n  render() {\n    it('x', () => {\n    });\n    return 1;\n  }\n}\n"
            "interface Props { a: number }\ntype Id = string;\nexport enum Kind { A }\nasync function load() {}\n",
            nx::CodeTs);
        expect(has(out, "S\tfunction\tboot\t5"), "ts function");
        expect(has(out, "S\tfunction\tadd\t6"), "ts arrow");
        expect(!hasSymbol(out, "plain"), "ts plain const ignored");
        expect(has(out, "S\tclass\tPanel\t8") && has(out, "S\tmethod\trender\t9"), "ts class method");
        expect(!hasSymbol(out, "it"), "ts callback ignored");
        expect(has(out, "S\tinterface\tProps\t15") && has(out, "S\ttype\tId\t16") && has(out, "S\tenum\tKind\t17") && has(out, "S\tfunction\tload\t18"), "ts types");
        expect(has(out, "I\treact") && has(out, "I\t./style.css") && has(out, "I\tfs") && has(out, "I\t./util"), "ts imports");
    }
    {
        std::string out = scan(
            "import os, sys as s\nfrom pkg.mod import thing\nfrom . import peer\nfrom ..up import x\n\nclass A(B):\n    \"\"\"def hidden():\"\"\"\n"
            "    def run(self):\n        pass\n\nasync def top():\n    # def commented\n    pass\n",
            nx::CodePython);
        expect(has(out, "S\tclass\tA\t6") && has(out, "S\tmethod\trun\t8") && has(out, "S\tfunction\ttop\t11"), "python symbols");
        expect(!hasSymbol(out, "hidden") && !hasSymbol(out, "commented"), "python docstring and comment ignored");
        expect(has(out, "I\tos") && has(out, "I\tsys") && has(out, "I\tpkg.mod") && has(out, "I\t.") && has(out, "I\t..up"), "python imports");
    }
    {
        std::string out = scan(
            "#include <stdio.h>\n#include \"mine.h\"\n\nstruct Node {\n    int v;\n};\n\nstatic int add(int a, int b) {\n    return a + b;\n}\nint proto(void);\n"
            "int main(void) {\n    int x = add(1, 2);\n    printf(\"x\");\n    return x;\n}\n",
            nx::CodeC);
        expect(has(out, "S\tstruct\tNode\t4") && has(out, "S\tfunction\tadd\t8") && has(out, "S\tfunction\tproto\t11") && has(out, "S\tfunction\tmain\t12"), "c symbols");
        expect(!hasSymbol(out, "printf") && !hasSymbol(out, "return"), "c calls ignored");
        expect(has(out, "I\tstdio.h") && has(out, "I\tmine.h"), "c includes");
    }
    {
        std::string out = scan(
            "namespace nx {\nclass Grid {\npublic:\n    Grid();\n    int cell(int x) const;\n};\n}\nGrid::Grid() : a(1) {\n}\nint Grid::cell(int x) const {\n    return x;\n}\n",
            nx::CodeCpp);
        expect(has(out, "S\tnamespace\tnx\t1") && has(out, "S\tclass\tGrid\t2"), "cpp types");
        expect(has(out, "S\tmethod\tcell\t5") && has(out, "S\tfunction\tGrid::Grid\t8") && has(out, "S\tfunction\tGrid::cell\t10"), "cpp methods");
    }
    {
        std::string out = scan("# Title\n\ntext\n```\n# not heading\n```\n## Part two\n####### seven\n", nx::CodeMarkdown);
        expect(has(out, "S\theading\tTitle\t1") && has(out, "S\theading\tPart two\t7"), "markdown headings");
        expect(!hasSymbol(out, "not heading") && !hasSymbol(out, "####### seven") && !hasSymbol(out, "seven"), "markdown fence and depth");
    }
    {
        std::string out = scan("<script src=\"app.js\"></script>\n<link rel=\"stylesheet\" href=\"a/b.css\">\n<a href=\"https://x.y\">\n<a href=\"#top\">\n", nx::CodeHtml);
        expect(has(out, "I\tapp.js") && has(out, "I\ta/b.css") && out.find("x.y") == std::string::npos && out.find("#top") == std::string::npos, "html imports");
        std::string css = scan("@import url(\"base.css\");\n@import 'more.css';\n", nx::CodeCss);
        expect(has(css, "I\tbase.css") && has(css, "I\tmore.css"), "css imports");
    }
    {
        std::string a = scan("fun loadUserProfile() {}\nval authToken = 1\nval authToken2 = 2\n", nx::CodeKotlin);
        expect(a.find("T\tauth\t2") != std::string::npos && a.find("T\tload\t1") != std::string::npos && a.find("T\tprofile\t1") != std::string::npos, "terms split");
        expect(scan("fun loadUserProfile() {}\n", nx::CodeKotlin).substr(0, 2) == "H\t", "header");
        std::string b = scan("fun loadUserProfile() {}\nval authToken = 1\nval authToken2 = 2\n", nx::CodeKotlin);
        expect(a == b, "deterministic");
        expect(scan("", nx::CodeKotlin) == "H\tcbf29ce484222325\t0\n", "empty file");
        expect(scan(std::string("\0\0\xff\xfe class", 10), nx::CodeText).substr(0, 2) == "H\t", "binary safe");
        std::string many;
        for (int i = 0; i < 5000; i++) many += "fun f" + std::to_string(i) + "() {}\n";
        std::string capped = scan(many, nx::CodeKotlin);
        int count = 0;
        for (size_t p = 0; (p = capped.find("\nS\t", p)) != std::string::npos; p++) count++;
        expect(count == 2000, "symbol cap");
        std::string crlf = scan("class A {\r\n}\r\n", nx::CodeJava);
        expect(has(crlf, "S\tclass\tA\t1"), "crlf");
        std::string utf = scan("# Judul \xc3\xa9\n", nx::CodeMarkdown);
        expect(has(utf, "S\theading\tJudul \xc3\xa9\t1"), "utf8 heading");
    }
    {
        std::string full = scan("a\nb\nc", nx::CodeKotlin);
        std::string only = scan("a\nb\nc", -1);
        expect(only.compare(0, full.find('\n'), full, 0, full.find('\n')) == 0 && only.back() == '\n' && only.find('S') == std::string::npos, "hash only");
    }
    if (failures == 0) std::printf("codescan: all ok\n");
    return failures == 0 ? 0 : 1;
}
