# CodeMind V10 di UntilyFlow

## Apa yang ada
- Indeks codebase lokal per proyek (SQLite privat), pencarian teks, simbol, path, import, ranking leksikal deterministik.
- Pemilih konteks untuk sebuah tugas dengan anggaran karakter, alasan per file, batasan tugas dipertahankan, dan daftar informasi yang kurang.
- Optimizer konteks (konservatif dan agresif) dengan ukuran sebelum dan sesudah. Token adalah estimasi karakter/4.
- Server MCP lokal (12 tool) dan integrasi ke agen AI di app: `nx cm index|find|sym|file|deps|ctx|stats`.

## Otomatis
- Saat agen jalan di folder yang belum masuk proyek mana pun, CodeMind mencari root proyek (naik sampai `.git`, `build.gradle(.kts)`, `package.json`, `pom.xml`, `Cargo.toml`, `pyproject.toml`, atau `CMakeLists.txt`), menambahkannya, dan mengindeks di latar belakang. Run pertama itu tanpa brief, run berikutnya dapat. Akar storage, `/`, dan folder media tingkat atas tidak pernah diindeks otomatis.
- Sebelum tiap run, indeks disegarkan bila lebih tua dari 60 detik (lokal) atau 10 menit (Root dan VPS, tanpa menunggu).
- Proyek dengan kurang dari 15 file terindeks tidak diberi brief. Batas dan saklar otomatis ada di tab Settings.
- Dashboard menampilkan ukuran brief tiap run. Token adalah estimasi karakter/4, bukan hitungan penyedia.

## Build
- `./gradlew assembleDebug` membangun APK. `./gradlew testDebugUnitTest` menjalankan tes JVM.
- Tanpa Gradle: `KOTLINC=/path/kotlinc tools/codemind-test/run.sh` dan `tools/codescan-test/run.sh`.

## Memakai
1. Buka CodeMind dari drawer, tab Projects, pilih penyimpanan (Internal, NoxoraStorage, Root, atau VPS yang tersambung), isi path folder, Add and index.
2. Dari terminal HP atau SSH, agen AI otomatis dapat ringkasan proyek dan tool `nx cm` setelah proyek diindeks. Bisa dimatikan di tab Settings.
3. Klien MCP: tab MCP Server, Start, salin URL dan token. Transport Streamable HTTP, header `Authorization: Bearer <token>`.
4. Agen di VPS: sambungkan VPS di Terminal, jalankan server, lalu Forward to VPS. Alamat di VPS: `http://127.0.0.1:<port>/mcp`.

## Keterbatasan yang diketahui
- Simbol diekstrak dengan pencocokan pola per baris, bukan parser/AST. Bahasa lain hanya pencarian teks. Pencarian semantik tidak ada (tanpa model embedding).
- Kode Android (SQLite, UI, server socket, hook agen) belum dikompilasi di lingkungan pembuat karena tidak ada Android SDK. Yang sudah dijalankan: tes C++ dengan ASAN/UBSAN, perbandingan C++ vs cadangan Kotlin, dan 28 tes JVM untuk inti murni.
- Server MCP baru diuji dengan tes mandiri dan tes JVM, belum dengan Claude Code, Codex, atau klien lain. Contoh perintah di UI mengikuti sintaks yang didokumentasikan, belum diverifikasi.
- Android dapat menghentikan proses di latar belakang. Server hidup selama task berjalan dan layanan keep-alive aktif.
- Tidak ada mode LAN. Hanya loopback (dan SSH remote forward ke loopback VPS).
- File UTF-16 dan file dengan byte NUL dianggap biner dan dilewati. File di atas batas ukuran dilewati.
- Penghapusan komentar mode agresif adalah heuristik per baris penuh, dilewati bila blok memuat string mentah.
- Indeks proyek di VPS membaca file lewat SFTP setiap proses karena tidak ada mtime, jadi lebih lambat dari penyimpanan lokal.
- Benchmark sederhana: jalankan Update dua kali di tab Projects. Run kedua menampilkan hit cache dan waktunya.
