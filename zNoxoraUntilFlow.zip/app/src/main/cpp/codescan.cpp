#include "codescan.h"

#include <algorithm>
#include <cstdio>
#include <set>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace nx {

namespace {

const size_t kMaxSymbols = 2000;
const size_t kMaxImports = 500;
const size_t kMaxTerms = 96;
const size_t kMaxName = 120;

bool idStart(unsigned char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '$';
}

bool idChar(unsigned char c) {
    return idStart(c) || (c >= '0' && c <= '9');
}

bool blank(unsigned char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\f' || c == '\v';
}

bool cLike(int lang) {
    return lang == CodeKotlin || lang == CodeJava || lang == CodeJs || lang == CodeTs || lang == CodeC ||
           lang == CodeCpp || lang == CodeCss;
}

std::string trimmed(const std::string& s) {
    size_t a = 0;
    size_t b = s.size();
    while (a < b && blank(static_cast<unsigned char>(s[a]))) a++;
    while (b > a && blank(static_cast<unsigned char>(s[b - 1]))) b--;
    return s.substr(a, b - a);
}

struct Sym {
    std::string kind;
    std::string name;
    int line;
};

struct Scanner {
    int lang;
    bool inBlock = false;
    std::string raw;
    int depth = 0;
    std::vector<Sym> syms;
    std::vector<std::string> imports;
    std::set<std::string> importSeen;
    std::set<std::string> symSeen;
    bool fence = false;

    explicit Scanner(int l) : lang(l) {}

    void addImport(const std::string& target) {
        if (target.empty() || target.size() > 200 || imports.size() >= kMaxImports) return;
        std::string clean;
        for (char c : target) clean.push_back((c == '\t' || c == '\n' || c == '\r') ? ' ' : c);
        if (importSeen.insert(clean).second) imports.push_back(clean);
    }

    void addSym(const std::string& kind, std::string name, int line) {
        if (name.empty() || syms.size() >= kMaxSymbols) return;
        if (name.size() > kMaxName) name.resize(kMaxName);
        for (char& c : name) if (c == '\t' || c == '\n' || c == '\r') c = ' ';
        std::string key = kind + "\x01" + name + "\x01" + std::to_string(line);
        if (!symSeen.insert(key).second) return;
        syms.push_back({kind, name, line});
    }

    std::string sanitize(const std::string& line) {
        std::string out;
        out.reserve(line.size());
        size_t i = 0;
        const size_t n = line.size();
        const bool hash = lang == CodePython;
        const bool slash = cLike(lang);
        while (i < n) {
            if (inBlock) {
                if (i + 1 < n && line[i] == '*' && line[i + 1] == '/') {
                    inBlock = false;
                    out += "  ";
                    i += 2;
                } else {
                    out.push_back(' ');
                    i++;
                }
                continue;
            }
            if (!raw.empty()) {
                if (line.compare(i, raw.size(), raw) == 0) {
                    out.append(raw.size(), ' ');
                    i += raw.size();
                    raw.clear();
                } else {
                    out.push_back(' ');
                    i++;
                }
                continue;
            }
            char c = line[i];
            if (slash && c == '/' && i + 1 < n && line[i + 1] == '/') {
                out.append(n - i, ' ');
                break;
            }
            if (slash && c == '/' && i + 1 < n && line[i + 1] == '*') {
                inBlock = true;
                out += "  ";
                i += 2;
                continue;
            }
            if (hash && c == '#') {
                out.append(n - i, ' ');
                break;
            }
            if ((c == '"' || c == '\'') && (lang == CodeKotlin || lang == CodeJava || lang == CodePython) &&
                line.compare(i, 3, std::string(3, c)) == 0) {
                raw = std::string(3, c);
                out += "   ";
                i += 3;
                continue;
            }
            if (c == '`' && (lang == CodeJs || lang == CodeTs)) {
                raw = "`";
                out.push_back(' ');
                i++;
                continue;
            }
            if (c == '"' || c == '\'') {
                char q = c;
                out.push_back(q);
                i++;
                while (i < n && line[i] != q) {
                    if (line[i] == '\\' && i + 1 < n) {
                        out += "  ";
                        i += 2;
                    } else {
                        out.push_back(' ');
                        i++;
                    }
                }
                if (i < n) {
                    out.push_back(q);
                    i++;
                }
                continue;
            }
            out.push_back(c);
            i++;
        }
        return out;
    }

    static int braceDelta(const std::string& s) {
        int d = 0;
        for (char c : s) {
            if (c == '{') d++;
            else if (c == '}') d--;
        }
        return d;
    }
};

bool inSet(const std::string& w, const char* const* list) {
    for (; *list; ++list) if (w == *list) return true;
    return false;
}

const char* const kModifiers[] = {
    "public", "private", "protected", "internal", "static", "final", "abstract", "open", "override", "sealed",
    "data", "inline", "suspend", "operator", "infix", "tailrec", "lateinit", "const", "external", "actual",
    "expect", "export", "default", "async", "declare", "readonly", "virtual", "constexpr", "extern", "synchronized",
    "native", "transient", "volatile", "strictfp", "value", "annotation", "inner", "noinline", "crossinline",
    "reified", "vararg", "fun", "explicit", "friend", "typename", "template", "companion", nullptr};

const char* const kControl[] = {"if", "for", "while", "switch", "return", "new", "throw", "catch", "try", "else",
                                "do", "case", "sizeof", "delete", "typeof", "await", "yield", "with", "using",
                                "goto", "when", "assert", "synchronized", "elif", "except", "lambda", "print", nullptr};

std::string wordAt(const std::string& s, size_t& i) {
    while (i < s.size() && blank(static_cast<unsigned char>(s[i]))) i++;
    size_t a = i;
    while (i < s.size() && idChar(static_cast<unsigned char>(s[i]))) i++;
    return s.substr(a, i - a);
}

size_t skipParens(const std::string& s, size_t i) {
    int d = 0;
    while (i < s.size()) {
        if (s[i] == '(') d++;
        else if (s[i] == ')') {
            d--;
            if (d == 0) return i + 1;
        }
        i++;
    }
    return i;
}

std::string stripGenerics(const std::string& s) {
    std::string out;
    int d = 0;
    for (char c : s) {
        if (c == '<') d++;
        else if (c == '>' && d > 0) d--;
        else if (d == 0) out.push_back(c);
    }
    return out;
}

bool plainName(const std::string& s) {
    if (s.empty()) return false;
    for (size_t i = 0; i < s.size(); i++) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        if (idChar(c)) continue;
        if (c == ':' || c == '~') continue;
        return false;
    }
    return idStart(static_cast<unsigned char>(s[0])) || s[0] == '~';
}

std::vector<std::string> splitWords(const std::string& s) {
    std::vector<std::string> out;
    size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && blank(static_cast<unsigned char>(s[i]))) i++;
        size_t a = i;
        while (i < s.size() && !blank(static_cast<unsigned char>(s[i]))) i++;
        if (i > a) out.push_back(s.substr(a, i - a));
    }
    return out;
}

void methodOf(Scanner& sc, const std::string& code, int depthBefore, int line) {
    size_t paren = code.find('(');
    if (paren == std::string::npos || code.find(')') == std::string::npos) return;
    std::string head = stripGenerics(code.substr(0, paren));
    if (head.find('=') != std::string::npos && head.find("operator") == std::string::npos) return;
    if (head.find('.') != std::string::npos && sc.lang != CodeTs && sc.lang != CodeJs) return;
    std::vector<std::string> words = splitWords(head);
    if (words.empty()) return;
    if (inSet(words[0], kControl)) return;
    const bool member = sc.lang == CodeJs || sc.lang == CodeTs;
    const bool scoped = sc.lang == CodeCpp && words[0].find("::") != std::string::npos;
    if (words.size() < 2 && !(member && depthBefore >= 1) && !scoped) return;
    if (words.size() < 2 && member) {
        size_t close = skipParens(code, paren);
        if (close > code.size() || close == 0 || code[close - 1] != ')') return;
        std::string after = trimmed(code.substr(close));
        if (after.empty() || (after[0] != '{' && after[0] != ':')) return;
    }
    std::string name = words.back();
    while (!name.empty() && (name[0] == '*' || name[0] == '&')) name.erase(0, 1);
    if (!plainName(name) || inSet(name, kControl)) return;
    int limit = sc.lang == CodeC ? 0 : 2;
    if (depthBefore > limit) return;
    const bool inside = depthBefore >= 1;
    sc.addSym(inside ? "method" : "function", name, line);
}

void declOf(Scanner& sc, const std::string& code, int depthBefore, int indent, int line) {
    size_t i = 0;
    std::vector<std::string> mods;
    std::string w;
    for (;;) {
        while (i < code.size() && blank(static_cast<unsigned char>(code[i]))) i++;
        if (i < code.size() && code[i] == '@') {
            i++;
            wordAt(code, i);
            size_t j = i;
            while (j < code.size() && blank(static_cast<unsigned char>(code[j]))) j++;
            if (j < code.size() && code[j] == '(') i = skipParens(code, j);
            continue;
        }
        w = wordAt(code, i);
        if (w.empty()) return;
        const bool jsConst = w == "const" && (sc.lang == CodeJs || sc.lang == CodeTs);
        if (inSet(w, kModifiers) && !(w == "fun" && sc.lang == CodeKotlin) && !jsConst) {
            mods.push_back(w);
            continue;
        }
        break;
    }
    const bool hasEnum = std::find(mods.begin(), mods.end(), "enum") != mods.end();
    const std::string rest = code.substr(i);
    const bool ended = rest.find('{') == std::string::npos && !rest.empty() && trimmed(rest).back() == ';';
    auto nameAfter = [&](size_t from) {
        size_t j = from;
        while (j < code.size() && (blank(static_cast<unsigned char>(code[j])) || code[j] == '*')) j++;
        size_t a = j;
        while (j < code.size() && (idChar(static_cast<unsigned char>(code[j])) || code[j] == ':')) j++;
        return code.substr(a, j - a);
    };

    if (sc.lang == CodePython) {
        if (w == "def") sc.addSym(indent > 0 ? "method" : "function", nameAfter(i), line);
        else if (w == "class") sc.addSym("class", nameAfter(i), line);
        return;
    }

    if (sc.lang == CodeKotlin && w == "fun") {
        size_t paren = code.find('(', i);
        if (paren == std::string::npos) return;
        std::string head = stripGenerics(code.substr(i, paren - i));
        std::string name = trimmed(head);
        size_t dot = name.rfind('.');
        if (dot != std::string::npos) name = name.substr(dot + 1);
        if (!plainName(name)) return;
        sc.addSym(depthBefore > 0 ? "method" : "function", name, line);
        return;
    }

    const bool typed = sc.lang != CodeC;
    if (w == "class" || w == "interface" || w == "struct" || w == "enum" || w == "union" || w == "trait" ||
        w == "record" || w == "namespace" || w == "object" || w == "typealias" || (w == "type" && typed) ||
        (w == "module" && sc.lang == CodeTs)) {
        if (w == "object" && sc.lang != CodeKotlin) return;
        if (w == "record" && sc.lang != CodeJava) return;
        if (w == "trait" || w == "typealias" || w == "type" || w == "module") {
            if (w == "trait" && sc.lang != CodeKotlin) return;
            if (w == "typealias" && sc.lang != CodeKotlin) return;
            if (w == "type" && sc.lang != CodeTs) return;
        }
        if ((w == "struct" || w == "union") && sc.lang != CodeC && sc.lang != CodeCpp) return;
        if (w == "namespace" && sc.lang != CodeCpp && sc.lang != CodeTs) return;
        if (ended && (sc.lang == CodeC || sc.lang == CodeCpp)) return;
        std::string name = nameAfter(i);
        if (w == "object" && name.empty()) {
            if (std::find(mods.begin(), mods.end(), "companion") != mods.end()) name = "Companion";
        }
        if (w == "enum" && name == "class") {
            size_t j = i;
            wordAt(code, j);
            name = nameAfter(j);
        }
        if (name.empty() || !idStart(static_cast<unsigned char>(name[0]))) return;
        std::string kind = w;
        if (w == "typealias" || w == "type") kind = "type";
        else if (hasEnum) kind = "enum";
        else if (w == "union") kind = "struct";
        else if (w == "module") kind = "namespace";
        sc.addSym(kind, name, line);
        return;
    }

    if (sc.lang == CodeJs || sc.lang == CodeTs) {
        if (w == "function") {
            size_t j = i;
            std::string name = nameAfter(j);
            sc.addSym("function", name, line);
            return;
        }
        if (w == "const" || w == "let" || w == "var") {
            size_t j = i;
            std::string name = wordAt(code, j);
            size_t eq = code.find('=', j);
            if (!name.empty() && eq != std::string::npos) {
                std::string tail = trimmed(code.substr(eq + 1));
                bool fn = tail.compare(0, 8, "function") == 0 || tail.find("=>") != std::string::npos ||
                          tail.compare(0, 5, "async") == 0;
                if (fn) sc.addSym("function", name, line);
            }
            return;
        }
        if (w == "enum") {
            sc.addSym("enum", nameAfter(i), line);
            return;
        }
    }

    if (sc.lang == CodeKotlin) return;
    if ((sc.lang == CodeJava || sc.lang == CodeJs || sc.lang == CodeTs || sc.lang == CodeC || sc.lang == CodeCpp) &&
        w != "import" && w != "package" && w != "using" && w != "typedef") {
        methodOf(sc, code, depthBefore, line);
    }
}

void quotedAfter(Scanner& sc, const std::string& line, size_t from) {
    for (size_t i = from; i < line.size(); i++) {
        if (line[i] == '\'' || line[i] == '"') {
            char q = line[i];
            size_t e = line.find(q, i + 1);
            if (e == std::string::npos) return;
            sc.addImport(line.substr(i + 1, e - i - 1));
            return;
        }
    }
}

void importsOf(Scanner& sc, const std::string& rawLine, const std::string& code) {
    std::string t = trimmed(rawLine);
    switch (sc.lang) {
        case CodeKotlin:
        case CodeJava: {
            if (t.compare(0, 7, "import ") != 0) return;
            std::string rest = trimmed(t.substr(7));
            if (rest.compare(0, 7, "static ") == 0) rest = trimmed(rest.substr(7));
            size_t end = 0;
            while (end < rest.size() && (idChar(static_cast<unsigned char>(rest[end])) || rest[end] == '.' || rest[end] == '*')) end++;
            sc.addImport(rest.substr(0, end));
            break;
        }
        case CodeJs:
        case CodeTs: {
            size_t from = t.find(" from ");
            if ((t.compare(0, 7, "import ") == 0 || t.compare(0, 7, "export ") == 0) && from != std::string::npos) {
                quotedAfter(sc, t, from + 6);
                return;
            }
            if (t.compare(0, 7, "import ") == 0 && (t.size() > 7 && (t[7] == '\'' || t[7] == '"'))) {
                quotedAfter(sc, t, 7);
                return;
            }
            size_t req = t.find("require(");
            if (req != std::string::npos) quotedAfter(sc, t, req + 8);
            size_t dyn = t.find("import(");
            if (dyn != std::string::npos) quotedAfter(sc, t, dyn + 7);
            break;
        }
        case CodePython: {
            if (t.compare(0, 5, "from ") == 0) {
                size_t j = 5;
                while (j < t.size() && blank(static_cast<unsigned char>(t[j]))) j++;
                size_t a = j;
                while (j < t.size() && (idChar(static_cast<unsigned char>(t[j])) || t[j] == '.')) j++;
                sc.addImport(t.substr(a, j - a));
            } else if (t.compare(0, 7, "import ") == 0) {
                std::string rest = t.substr(7);
                size_t i = 0;
                while (i < rest.size()) {
                    size_t a = i;
                    while (i < rest.size() && rest[i] != ',') i++;
                    std::string part = trimmed(rest.substr(a, i - a));
                    size_t as = part.find(" as ");
                    if (as != std::string::npos) part = trimmed(part.substr(0, as));
                    sc.addImport(part);
                    i++;
                }
            }
            break;
        }
        case CodeC:
        case CodeCpp: {
            if (t.empty() || t[0] != '#') return;
            std::string rest = trimmed(t.substr(1));
            if (rest.compare(0, 7, "include") != 0) return;
            rest = trimmed(rest.substr(7));
            if (rest.empty()) return;
            char open = rest[0];
            char close = open == '<' ? '>' : '"';
            if (open != '<' && open != '"') return;
            size_t e = rest.find(close, 1);
            if (e != std::string::npos) sc.addImport(rest.substr(1, e - 1));
            break;
        }
        case CodeHtml: {
            for (const char* attr : {"src=", "href="}) {
                size_t pos = 0;
                while ((pos = t.find(attr, pos)) != std::string::npos) {
                    size_t p = pos + std::string(attr).size();
                    if (p < t.size() && (t[p] == '"' || t[p] == '\'')) {
                        size_t e = t.find(t[p], p + 1);
                        if (e != std::string::npos) {
                            std::string v = t.substr(p + 1, e - p - 1);
                            if (v.find("://") == std::string::npos && !v.empty() && v[0] != '#') sc.addImport(v);
                        }
                    }
                    pos = p;
                }
            }
            break;
        }
        case CodeCss: {
            if (t.compare(0, 7, "@import") != 0) return;
            size_t q = t.find_first_of("\"'");
            if (q != std::string::npos) quotedAfter(sc, t, q);
            break;
        }
        default:
            break;
    }
    (void)code;
}

void markdownOf(Scanner& sc, const std::string& line, int number) {
    std::string t = trimmed(line);
    if (t.compare(0, 3, "```") == 0 || t.compare(0, 3, "~~~") == 0) {
        sc.fence = !sc.fence;
        return;
    }
    if (sc.fence || t.empty() || t[0] != '#') return;
    size_t i = 0;
    while (i < t.size() && t[i] == '#') i++;
    if (i > 6 || i >= t.size() || t[i] != ' ') return;
    sc.addSym("heading", trimmed(t.substr(i)), number);
}

const char* const kStop[] = {"the", "and", "for", "with", "this", "that", "from", "into", "return", "val", "var", "let",
                             "const", "fun", "function", "class", "public", "private", "static", "void", "null", "true",
                             "false", "int", "string", "else", "then", "new", "not", "import", "package", "def", "self",
                             "end", "are", "was", "has", "have", "but", "all", "any", "can", "out", nullptr};

void termsOf(const uint8_t* data, size_t len, std::unordered_map<std::string, int>& freq) {
    std::unordered_set<std::string> stop;
    for (const char* const* p = kStop; *p; ++p) stop.insert(*p);
    size_t i = 0;
    while (i < len) {
        if (!idStart(data[i]) || data[i] == '$') {
            i++;
            continue;
        }
        size_t a = i;
        while (i < len && idChar(data[i]) && data[i] != '$') i++;
        size_t n = i - a;
        if (n < 3 || n > 64) continue;
        std::string cur;
        for (size_t k = a; k < i; k++) {
            unsigned char c = data[k];
            bool upper = c >= 'A' && c <= 'Z';
            bool prevLower = k > a && ((data[k - 1] >= 'a' && data[k - 1] <= 'z') || (data[k - 1] >= '0' && data[k - 1] <= '9'));
            bool nextLower = k + 1 < i && data[k + 1] >= 'a' && data[k + 1] <= 'z';
            bool prevUpper = k > a && data[k - 1] >= 'A' && data[k - 1] <= 'Z';
            if (c == '_') {
                if (cur.size() >= 3 && !stop.count(cur) && freq.size() < 20000) freq[cur]++;
                cur.clear();
                continue;
            }
            if (upper && (prevLower || (prevUpper && nextLower))) {
                if (cur.size() >= 3 && !stop.count(cur) && freq.size() < 20000) freq[cur]++;
                cur.clear();
            }
            cur.push_back(static_cast<char>(upper ? c + 32 : c));
        }
        if (cur.size() >= 3 && !stop.count(cur) && freq.size() < 20000) freq[cur]++;
    }
}

uint64_t fnv(const uint8_t* data, size_t len) {
    uint64_t h = 14695981039346656037ULL;
    for (size_t i = 0; i < len; i++) {
        h ^= data[i];
        h *= 1099511628211ULL;
    }
    return h;
}

}

std::string codeScan(const uint8_t* data, size_t len, int lang) {
    if (lang < 0) {
        int count = 0;
        for (size_t i = 0; i < len; i++) if (data[i] == '\n') count++;
        if (len > 0 && data[len - 1] != '\n') count++;
        char only[64];
        std::snprintf(only, sizeof only, "H\t%016llx\t%d\n", static_cast<unsigned long long>(fnv(data, len)), count);
        return only;
    }
    Scanner sc(lang);
    int lines = 0;
    size_t pos = 0;
    const bool decl = lang == CodeKotlin || lang == CodeJava || lang == CodeJs || lang == CodeTs ||
                      lang == CodePython || lang == CodeC || lang == CodeCpp;
    while (pos < len) {
        size_t end = pos;
        while (end < len && data[end] != '\n') end++;
        size_t stop = end;
        if (stop > pos && data[stop - 1] == '\r') stop--;
        std::string line(reinterpret_cast<const char*>(data) + pos, stop - pos);
        lines++;
        if (lang == CodeMarkdown) {
            markdownOf(sc, line, lines);
        } else if (decl) {
            bool wasBlock = sc.inBlock;
            bool wasRaw = !sc.raw.empty();
            std::string code = sc.sanitize(line);
            importsOf(sc, wasBlock || wasRaw ? std::string() : line, code);
            std::string t = trimmed(code);
            int indent = 0;
            while (indent < static_cast<int>(code.size()) && blank(static_cast<unsigned char>(code[static_cast<size_t>(indent)]))) indent++;
            if (!wasBlock && !wasRaw && !t.empty()) {
                while (!t.empty() && t[0] == '}') t = trimmed(t.substr(1));
                if (!t.empty() && t[0] != '#') declOf(sc, t, sc.depth, indent, lines);
            }
            sc.depth += Scanner::braceDelta(code);
            if (sc.depth < 0) sc.depth = 0;
        } else {
            importsOf(sc, line, line);
        }
        pos = end + 1;
    }

    std::unordered_map<std::string, int> freq;
    termsOf(data, len, freq);
    std::vector<std::pair<std::string, int>> top(freq.begin(), freq.end());
    std::sort(top.begin(), top.end(), [](const std::pair<std::string, int>& a, const std::pair<std::string, int>& b) {
        if (a.second != b.second) return a.second > b.second;
        return a.first < b.first;
    });
    if (top.size() > kMaxTerms) top.resize(kMaxTerms);

    char head[64];
    std::snprintf(head, sizeof head, "H\t%016llx\t%d\n", static_cast<unsigned long long>(fnv(data, len)), lines);
    std::string out = head;
    for (const Sym& s : sc.syms) out += "S\t" + s.kind + "\t" + s.name + "\t" + std::to_string(s.line) + "\n";
    for (const std::string& imp : sc.imports) out += "I\t" + imp + "\n";
    for (const auto& t : top) out += "T\t" + t.first + "\t" + std::to_string(t.second) + "\n";
    return out;
}

}
