#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

namespace nx {

enum CodeLang {
    CodeText = 0,
    CodeKotlin = 1,
    CodeJava = 2,
    CodeJs = 3,
    CodeTs = 4,
    CodePython = 5,
    CodeC = 6,
    CodeCpp = 7,
    CodeHtml = 8,
    CodeCss = 9,
    CodeJson = 10,
    CodeXml = 11,
    CodeMarkdown = 12,
};

std::string codeScan(const uint8_t* data, size_t len, int lang);

}
