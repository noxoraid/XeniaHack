#include <jni.h>

#include <string>
#include <vector>

#include "codescan.h"

extern "C" {

JNIEXPORT jbyteArray JNICALL
Java_com_untilyflow_app_CodeScan_nativeScan(JNIEnv* env, jobject, jbyteArray data, jint len, jint lang) {
    if (!data || len < 0) return env->NewByteArray(0);
    jsize have = env->GetArrayLength(data);
    jsize size = len < have ? len : have;
    std::vector<jbyte> buf(static_cast<size_t>(size > 0 ? size : 0));
    if (size > 0) env->GetByteArrayRegion(data, 0, size, buf.data());
    std::string out = nx::codeScan(reinterpret_cast<const uint8_t*>(buf.data()), buf.size(), lang);
    jbyteArray result = env->NewByteArray(static_cast<jsize>(out.size()));
    if (!out.empty()) env->SetByteArrayRegion(result, 0, static_cast<jsize>(out.size()), reinterpret_cast<const jbyte*>(out.data()));
    return result;
}

}
