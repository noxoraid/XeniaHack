package com.untilyflow.app

import android.content.Context
import android.graphics.Typeface
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.res.ResourcesCompat

class FontChoice(val key: String, val label: String, val family: FontFamily, private val res: Int = 0) {
    fun typeface(ctx: Context): Typeface =
        (if (res != 0) ResourcesCompat.getFont(ctx, res) else null) ?: Typeface.MONOSPACE
}

private fun duo(regular: Int, bold: Int) = FontFamily(Font(regular, FontWeight.Normal), Font(bold, FontWeight.Bold))

private val poppins = FontFamily(
    Font(R.font.poppins_regular, FontWeight.Normal),
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_bold, FontWeight.SemiBold),
    Font(R.font.poppins_bold, FontWeight.Bold),
    Font(R.font.poppins_bold, FontWeight.ExtraBold),
)

object NxFonts {
    val ui = listOf(
        FontChoice("poppins", "Poppins", poppins),
        FontChoice("instrument", "Instrument Sans", duo(R.font.instrument_sans_regular, R.font.instrument_sans_bold)),
        FontChoice("work", "Work Sans", duo(R.font.work_sans_regular, R.font.work_sans_bold)),
        FontChoice("outfit", "Outfit", duo(R.font.outfit_regular, R.font.outfit_bold)),
        FontChoice("bricolage", "Bricolage Grotesque", duo(R.font.bricolage_regular, R.font.bricolage_bold)),
        FontChoice("system", "System", FontFamily.SansSerif),
    )

    val mono = listOf(
        FontChoice("jetbrains", "JetBrains Mono", duo(R.font.jetbrains_mono_regular, R.font.jetbrains_mono_bold), R.font.jetbrains_mono_regular),
        FontChoice("geist", "Geist Mono", duo(R.font.geist_mono_regular, R.font.geist_mono_bold), R.font.geist_mono_regular),
        FontChoice("plex", "IBM Plex Mono", duo(R.font.ibm_plex_mono_regular, R.font.ibm_plex_mono_bold), R.font.ibm_plex_mono_regular),
        FontChoice("dm", "DM Mono", FontFamily(Font(R.font.dm_mono_regular)), R.font.dm_mono_regular),
        FontChoice("system", "System", FontFamily.Monospace),
    )
}

object FontPrefs {
    private const val FILE = "noxora_ui"

    var ui by mutableStateOf(NxFonts.ui[0])
        private set
    var mono by mutableStateOf(NxFonts.mono[0])
        private set

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        ui = NxFonts.ui.firstOrNull { it.key == p.getString("ui", null) } ?: NxFonts.ui[0]
        mono = NxFonts.mono.firstOrNull { it.key == p.getString("mono", null) } ?: NxFonts.mono[0]
    }

    fun pickUi(ctx: Context, choice: FontChoice) {
        ui = choice
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("ui", choice.key).apply()
    }

    fun pickMono(ctx: Context, choice: FontChoice) {
        mono = choice
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("mono", choice.key).apply()
    }
}
