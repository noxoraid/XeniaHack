package com.untilyflow.app

import kotlin.math.ln

class CmPage<T>(val items: List<T>, val offset: Int, val more: Boolean)

class CmTextHit(val path: String, val line: Int, val text: String)

class CmDeps(val imports: List<String>, val resolved: List<String>, val importedBy: List<String>)

class CmRanked(val path: String, val score: Double, val reasons: List<String>, val terms: Set<String>)

class CmResolver(paths: List<String>) {
    private val all = HashSet(paths)
    private val byStem = HashMap<String, MutableList<String>>()
    private val exts = listOf(".ts", ".tsx", ".js", ".jsx", ".mjs", ".json", ".css", ".kt", ".java", ".py", ".h", ".hpp")

    init {
        for (p in paths) {
            val name = p.substringAfterLast('/')
            val dot = name.lastIndexOf('.')
            val stem = if (dot > 0) name.substring(0, dot) else name
            byStem.getOrPut(stem) { ArrayList() }.add(p)
        }
    }

    private fun normalize(path: String): String {
        val out = ArrayList<String>()
        for (seg in path.split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> if (out.isNotEmpty()) out.removeAt(out.size - 1)
                else -> out.add(seg)
            }
        }
        return out.joinToString("/")
    }

    private fun candidates(base: String): List<String> {
        val out = ArrayList<String>()
        if (base in all) out.add(base)
        for (e in exts) if ((base + e) in all) out.add(base + e)
        for (e in exts) if ((base + "/index" + e) in all) out.add(base + "/index" + e)
        return out
    }

    fun resolve(from: String, target: String): List<String> {
        val dir = from.substringBeforeLast('/', "")
        if (target.startsWith("./") || target.startsWith("../")) {
            return candidates(normalize(if (dir.isEmpty()) target else "$dir/$target"))
        }
        if (target.startsWith(".") && from.endsWith(".py")) {
            var dots = 0
            while (dots < target.length && target[dots] == '.') dots++
            var base = dir
            repeat(dots - 1) { base = base.substringBeforeLast('/', "") }
            val rest = target.substring(dots).replace('.', '/')
            val joined = listOf(base, rest).filter { it.isNotEmpty() }.joinToString("/")
            return candidates(joined) + (if ((joined + "/__init__.py") in all) listOf(joined + "/__init__.py") else emptyList())
        }
        if (target.contains('/') || (target.contains('.') && target.substringAfterLast('.').length <= 3 && target.substringAfterLast('.').all { it.isLetter() } && !target.substringBeforeLast('.').contains('.'))) {
            val local = candidates(normalize(if (dir.isEmpty()) target else "$dir/$target"))
            if (local.isNotEmpty()) return local
            val suffix = "/" + target
            val stem = target.substringAfterLast('/').substringBeforeLast('.')
            return (byStem[stem] ?: emptyList()).filter { it == target || it.endsWith(suffix) }
        }
        if (target.contains('.') || target.all { it.isLetterOrDigit() || it == '_' }) {
            val wildcard = target.endsWith(".*")
            val dotted = if (wildcard) target.removeSuffix(".*") else target
            val tries = ArrayList<String>()
            tries.add(dotted)
            if (!wildcard && dotted.contains('.')) tries.add(dotted.substringBeforeLast('.'))
            for (t in tries) {
                val rel = t.replace('.', '/')
                if (wildcard) {
                    val found = all.filter { val d = it.substringBeforeLast('/', ""); d == rel || d.endsWith("/$rel") }
                    if (found.isNotEmpty()) return found.sorted()
                    continue
                }
                val stem = rel.substringAfterLast('/')
                val hits = (byStem[stem] ?: emptyList()).filter {
                    val noExt = it.substringBeforeLast('.')
                    noExt == rel || noExt.endsWith("/$rel")
                }
                if (hits.isNotEmpty()) return hits.sorted()
                val pkg = listOf("$rel/__init__.py", "$rel.py").filter { it in all }
                if (pkg.isNotEmpty()) return pkg
            }
        }
        return emptyList()
    }
}

object CodeQuery {
    private val stopWords = setOf(
        "the", "and", "for", "with", "this", "that", "from", "into", "not", "are", "was", "has", "have", "but", "all",
        "any", "can", "fix", "bug", "make", "use", "add", "change", "update", "please", "without", "dont", "don",
        "yang", "dan", "di", "ke", "dari", "pada", "untuk", "dengan", "jangan", "perbaiki", "ubah", "tambah", "tambahkan",
        "atau", "itu", "ini", "agar", "supaya", "bisa", "tidak", "harus", "saja", "juga", "sudah", "belum", "buat", "buatkan",
        "tolong", "mengubah",
    )

    fun tokens(text: String): List<String> {
        val out = LinkedHashSet<String>()
        var i = 0
        while (i < text.length) {
            if (!(text[i].isLetter() || text[i] == '_')) {
                i++
                continue
            }
            val a = i
            while (i < text.length && (text[i].isLetterOrDigit() || text[i] == '_')) i++
            val word = text.substring(a, i)
            val cur = StringBuilder()
            fun flush() {
                val t = cur.toString().lowercase()
                if (t.length >= 3 && t !in stopWords) out.add(t)
                cur.setLength(0)
            }
            for (k in word.indices) {
                val c = word[k]
                if (c == '_') {
                    flush()
                    continue
                }
                val prevLower = k > 0 && (word[k - 1].isLowerCase() || word[k - 1].isDigit())
                val prevUpper = k > 0 && word[k - 1].isUpperCase()
                val nextLower = k + 1 < word.length && word[k + 1].isLowerCase()
                if (c.isUpperCase() && (prevLower || (prevUpper && nextLower))) flush()
                cur.append(c)
            }
            flush()
        }
        return out.toList()
    }

    fun symbols(index: CodeIndex, query: String, kind: String?, limit: Int, offset: Int): CmPage<CmSymbol> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return CmPage(emptyList(), offset, false)
        val found = index.findSymbols(q, 2000).filter { kind == null || it.kind == kind }
        fun rankOf(s: CmSymbol): Int {
            val n = s.name.lowercase()
            val tail = n.substringAfterLast("::")
            return when {
                n == q || tail == q -> 0
                n.startsWith(q) || tail.startsWith(q) -> 1
                tokens(s.name).contains(q) -> 2
                else -> 3
            }
        }
        val sorted = found.sortedWith(compareBy<CmSymbol>({ rankOf(it) }, { it.name.length }, { it.file }, { it.line }))
        val end = minOf(sorted.size, offset + limit)
        val slice = if (offset >= sorted.size) emptyList() else sorted.subList(offset, end)
        return CmPage(slice, offset, end < sorted.size)
    }

    fun paths(index: CodeIndex, query: String, limit: Int, offset: Int): CmPage<String> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return CmPage(emptyList(), offset, false)
        val glob = q.contains('*') || q.contains('?')
        val found = index.paths().filter { if (glob) CmGlob.match(q, it) || CmGlob.match(q, it.substringAfterLast('/')) else it.lowercase().contains(q) }
        fun rankOf(p: String): Int {
            val name = p.substringAfterLast('/').lowercase()
            return when {
                glob -> 0
                name == q -> 0
                name.startsWith(q) -> 1
                name.contains(q) -> 2
                else -> 3
            }
        }
        val sorted = found.sortedWith(compareBy<String>({ rankOf(it) }, { it.length }, { it }))
        val end = minOf(sorted.size, offset + limit)
        val slice = if (offset >= sorted.size) emptyList() else sorted.subList(offset, end)
        return CmPage(slice, offset, end < sorted.size)
    }

    fun text(
        index: CodeIndex,
        source: CodeSource,
        root: String,
        query: String,
        caseSensitive: Boolean,
        regex: Boolean,
        glob: String?,
        limit: Int,
        offset: Int,
        maxFiles: Int = 4000,
        maxBytes: Int = 524288,
        stopped: () -> Boolean = { false },
    ): CmPage<CmTextHit> {
        if (query.isEmpty()) return CmPage(emptyList(), offset, false)
        val pattern = if (regex) Regex(query, if (caseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE)) else null
        val want = offset + limit + 1
        val hits = ArrayList<CmTextHit>()
        var scanned = 0
        for (path in index.paths()) {
            if (stopped()) throw CmStopped()
            if (glob != null && glob.isNotBlank() && !CmGlob.match(glob, path) && !CmGlob.match(glob, path.substringAfterLast('/'))) continue
            if (scanned >= maxFiles) break
            scanned++
            val data = try {
                source.read(CodeIndexer.join(root, path), maxBytes)
            } catch (_: CmStopped) {
                throw CmStopped()
            } catch (_: Exception) {
                continue
            }
            if (TextGrep.binary(data, data.size)) continue
            val lines = if (pattern != null) TextGrep.pattern(data, data.size, pattern, want - hits.size)
            else TextGrep.literal(data, data.size, query, !caseSensitive, want - hits.size)
            for (l in lines) hits.add(CmTextHit(path, l.number, l.text.trim().take(240)))
            if (hits.size >= want) break
        }
        val end = minOf(hits.size, offset + limit)
        val slice = if (offset >= hits.size) emptyList() else hits.subList(offset, end)
        return CmPage(slice, offset, hits.size > end)
    }

    fun dependencies(index: CodeIndex, path: String): CmDeps {
        val resolver = CmResolver(index.paths())
        val imports = index.importsOf(path)
        val resolved = LinkedHashSet<String>()
        for (t in imports) for (r in resolver.resolve(path, t)) if (r != path) resolved.add(r)
        val by = LinkedHashSet<String>()
        for ((from, target) in index.allImports()) {
            if (from == path) continue
            if (resolver.resolve(from, target).contains(path)) by.add(from)
        }
        return CmDeps(imports, resolved.toList(), by.toList().sorted())
    }

    fun isTest(path: String): Boolean {
        val p = path.lowercase()
        return p.contains("/test/") || p.contains("/tests/") || p.contains("/androidtest/") || p.contains("__tests__") ||
            p.substringAfterLast('/').let { it.contains("test") || it.contains("spec") } || p.startsWith("test/") || p.startsWith("tests/")
    }

    fun isConfig(path: String): Boolean {
        val n = path.substringAfterLast('/').lowercase()
        return n in CONFIG_NAMES || n.endsWith(".gradle") || n.endsWith(".gradle.kts") || n.endsWith(".properties") ||
            n.endsWith(".yml") || n.endsWith(".yaml") || n.endsWith(".toml") || n == "androidmanifest.xml"
    }

    val CONFIG_NAMES = setOf(
        "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "androidmanifest.xml", "package.json",
        "pom.xml", "cargo.toml", "pyproject.toml", "requirements.txt", "cmakelists.txt", "tsconfig.json", "gradle.properties",
    )

    fun rank(index: CodeIndex, task: String, limit: Int, excludes: List<String>): List<CmRanked> {
        val terms = tokens(task).take(24)
        if (terms.isEmpty() || index.fileCount() == 0) return emptyList()
        val total = maxOf(1, index.fileCount())
        val df = index.docFreq(terms)
        fun idf(t: String): Double = ln(1.0 + total.toDouble() / (1.0 + (df[t] ?: 0)))
        val score = HashMap<String, Double>()
        val matched = HashMap<String, MutableMap<String, Int>>()
        val symbolsFound = HashMap<String, MutableSet<String>>()
        val pathFound = HashSet<String>()
        for (h in index.termHits(terms)) {
            if (CmGlob.any(excludes, h.file)) continue
            score[h.file] = (score[h.file] ?: 0.0) + idf(h.term) * (1.0 + ln(h.count.toDouble()))
            matched.getOrPut(h.file) { LinkedHashMap() }[h.term] = h.count
        }
        for (t in terms) {
            for (s in index.findSymbols(t, 300)) {
                if (CmGlob.any(excludes, s.file)) continue
                val parts = tokens(s.name)
                val bonus = if (parts.contains(t)) 6.0 else 4.0
                score[s.file] = (score[s.file] ?: 0.0) + bonus * idf(t)
                symbolsFound.getOrPut(s.file) { LinkedHashSet() }.add(s.name)
            }
        }
        val lowered = index.paths().map { it to it.lowercase() }
        for (t in terms) {
            for ((p, lower) in lowered) {
                if (!lower.contains(t)) continue
                if (CmGlob.any(excludes, p)) continue
                val base = lower.substringAfterLast('/')
                score[p] = (score[p] ?: 0.0) + (if (base.contains(t)) 5.0 else 3.0) * idf(t)
                pathFound.add(p)
            }
        }
        val out = score.entries.map { (p, raw) ->
            val s = if (isTest(p)) raw * 0.85 else raw
            val reasons = ArrayList<String>()
            matched[p]?.let { m -> reasons.add("content: " + m.entries.take(5).joinToString(", ") { it.key + "x" + it.value }) }
            symbolsFound[p]?.let { reasons.add("symbol: " + it.take(3).joinToString(", ")) }
            if (p in pathFound) reasons.add("path")
            CmRanked(p, s, reasons, matched[p]?.keys ?: emptySet())
        }.sortedWith(compareByDescending<CmRanked> { it.score }.thenBy { it.path })
        return out.take(limit)
    }
}
