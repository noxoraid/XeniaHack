package com.untilyflow.app

object CodeRoot {
    val MARKERS = listOf(".git", "build.gradle", "build.gradle.kts", "package.json", "pom.xml", "Cargo.toml", "pyproject.toml", "CMakeLists.txt")
    const val MAX_CLIMB = 8

    private val broadExact = setOf(
        "/", "/storage", "/storage/emulated", "/storage/self", "/storage/self/primary", "/sdcard", "/mnt", "/mnt/sdcard",
        "/data", "/data/data", "/data/user", "/home", "/root", "/usr", "/var", "/etc", "/opt", "/tmp", "/sys", "/proc", "/dev",
    )

    private val mediaFolders = setOf("android", "dcim", "download", "downloads", "documents", "movies", "music", "pictures", "podcasts", "ringtones", "alarms", "notifications")

    fun clean(path: String): String {
        val out = ArrayList<String>()
        for (seg in path.trim().replace('\\', '/').split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> if (out.isNotEmpty()) out.removeAt(out.size - 1)
                else -> out.add(seg)
            }
        }
        return "/" + out.joinToString("/")
    }

    fun parent(path: String): String {
        val p = clean(path)
        val cut = p.lastIndexOf('/')
        return if (cut <= 0) "/" else p.substring(0, cut)
    }

    fun join(dir: String, name: String): String = if (dir == "/") "/$name" else "$dir/$name"

    fun tooBroad(path: String): Boolean {
        val p = clean(path)
        if (p in broadExact) return true
        val seg = p.trim('/').split('/')
        if (seg[0] == "storage") {
            if (seg.size == 2) return true
            if (seg.size == 3 && (seg[1] == "emulated" || seg[1] == "self")) return true
            if (seg.size == 4 && seg[1] == "emulated" && seg[3].lowercase() in mediaFolders) return true
        }
        if (seg[0] == "home" && seg.size == 2) return true
        if (seg[0] == "data" && seg.size == 3 && seg[1] == "user") return true
        if (seg[0] == "data" && seg.size >= 3 && seg[seg.size - 2] == "files" && seg.last() == "home") return true
        return false
    }

    private fun has(source: CodeSource, path: String): Boolean = try {
        source.exists(path)
    } catch (_: Exception) {
        false
    }

    fun find(source: CodeSource, cwd: String, maxClimb: Int = MAX_CLIMB): String? {
        var dir = clean(cwd)
        var steps = 0
        while (steps <= maxClimb) {
            if (tooBroad(dir)) return null
            for (m in MARKERS) if (has(source, join(dir, m))) return dir
            if (dir == "/") return null
            dir = parent(dir)
            steps++
        }
        return null
    }

    fun autoRoot(source: CodeSource, cwd: String): String? {
        val start = clean(cwd)
        val root = find(source, start) ?: start
        return if (tooBroad(root)) null else root
    }
}

object CodeAuto {
    const val LOCAL_REFRESH_MS = 60_000L
    const val REMOTE_REFRESH_MS = 600_000L
    const val LOCAL_WAIT_MS = 2_500L
    const val MIN_FILES = 15

    fun refreshDue(local: Boolean, lastAt: Long, now: Long): Boolean {
        if (lastAt <= 0L || now < lastAt) return true
        return now - lastAt >= if (local) LOCAL_REFRESH_MS else REMOTE_REFRESH_MS
    }

    fun briefWorth(files: Int, minFiles: Int): Boolean = files >= minFiles

    fun estTokens(chars: Int): Int = (chars + 3) / 4
}

class CmOnce {
    private val seen = HashSet<String>()

    @Synchronized
    fun first(key: String): Boolean = seen.add(key)

    @Synchronized
    fun clear() = seen.clear()
}

class CmBriefNote(val at: Long, val project: String, val chars: Int, val files: Int, val outcome: String) {
    val tokens: Int get() = CodeAuto.estTokens(chars)

    fun encode(): String =
        listOf(at.toString(), project.replace('\t', ' ').replace('\n', ' '), chars.toString(), files.toString(), outcome).joinToString("\t")

    companion object {
        fun decode(line: String): CmBriefNote? {
            val p = line.split('\t')
            if (p.size != 5) return null
            val at = p[0].toLongOrNull() ?: return null
            val chars = p[2].toIntOrNull() ?: return null
            val files = p[3].toIntOrNull() ?: return null
            return CmBriefNote(at, p[1], chars, files, p[4])
        }
    }
}
