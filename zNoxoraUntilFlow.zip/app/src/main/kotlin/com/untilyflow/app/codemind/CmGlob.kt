package com.untilyflow.app

object CmGlob {
    fun match(pattern: String, text: String): Boolean {
        val p = pattern.lowercase()
        val t = text.lowercase()
        var pi = 0
        var ti = 0
        var star = -1
        var mark = 0
        while (ti < t.length) {
            if (pi < p.length && (p[pi] == '?' || p[pi] == t[ti])) {
                pi++
                ti++
            } else if (pi < p.length && p[pi] == '*') {
                star = pi++
                mark = ti
            } else if (star >= 0) {
                pi = star + 1
                ti = ++mark
            } else {
                return false
            }
        }
        while (pi < p.length && p[pi] == '*') pi++
        return pi == p.length
    }

    fun any(patterns: List<String>, path: String): Boolean {
        if (patterns.isEmpty()) return false
        val name = path.substringAfterLast('/')
        for (raw in patterns) {
            val p = raw.trim().trimEnd('/')
            if (p.isEmpty()) continue
            if (match(p, name) || match(p, path)) return true
            if (!p.contains('*') && !p.contains('?') && (path == p || path.startsWith("$p/") || path.contains("/$p/"))) return true
        }
        return false
    }
}
