package com.untilyflow.app

class CmPicked(val path: String, val role: String, val reason: String)

class CmPack(
    val text: String,
    val picked: List<CmPicked>,
    val omitted: List<String>,
    val missing: List<String>,
    val constraints: List<String>,
)

object ContextPack {
    private val markers = listOf(
        "jangan", "tanpa", "tidak boleh", "dilarang", "tetap", "harus", "wajib", "don't", "do not", "dont", "without",
        "never", "must", "keep", "only", "avoid", "should not", "shouldn't",
    )

    fun constraintsOf(task: String): List<String> {
        val parts = task.split(Regex("(?<=[.!?;\\n])\\s+|,\\s+(?=(?:dan|and|tapi|but)\\s)"))
        val out = ArrayList<String>()
        for (raw in parts) {
            val s = raw.trim()
            if (s.isEmpty()) continue
            val low = s.lowercase()
            if (markers.any { low.contains(it) }) out.add(s.take(240))
        }
        return out.distinct().take(8)
    }

    private fun nearestBuild(index: CodeIndex, path: String): String? {
        var dir = path.substringBeforeLast('/', "")
        while (true) {
            for (name in listOf("build.gradle.kts", "build.gradle", "package.json", "pom.xml", "Cargo.toml", "pyproject.toml", "CMakeLists.txt")) {
                val p = if (dir.isEmpty()) name else "$dir/$name"
                if (index.file(p) != null) return p
            }
            if (dir.isEmpty()) return null
            dir = dir.substringBeforeLast('/', "")
        }
    }

    private fun lineSlice(data: ByteArray, from: Int, count: Int): String {
        val text = String(data, Charsets.UTF_8).lines()
        val a = (from - 1).coerceIn(0, maxOf(0, text.size - 1))
        val b = minOf(text.size, a + count)
        val out = StringBuilder()
        for (i in a until b) out.append(i + 1).append(": ").append(text[i].take(200)).append('\n')
        return out.toString().trimEnd()
    }

    private fun snippetOf(index: CodeIndex, source: CodeSource, root: String, path: String, terms: Set<String>, tokens: List<String>): String {
        val syms = index.symbolsOf(path).filter { s -> CodeQuery.tokens(s.name).any { it in tokens } }.take(2)
        val data = try {
            source.read(CodeIndexer.join(root, path), 262144)
        } catch (_: CmStopped) {
            throw CmStopped()
        } catch (_: Exception) {
            return ""
        }
        if (syms.isNotEmpty()) return syms.joinToString("\n...\n") { lineSlice(data, it.line, 24) }
        val term = terms.firstOrNull() ?: tokens.firstOrNull() ?: return ""
        val hit = TextGrep.literal(data, data.size, term, true, 1).firstOrNull() ?: return ""
        return lineSlice(data, maxOf(1, hit.number - 4), 12)
    }

    fun build(
        index: CodeIndex,
        source: CodeSource,
        root: String,
        name: String,
        task: String,
        budget: Int,
        excludes: List<String>,
    ): CmPack {
        val limit = budget.coerceIn(500, 200000)
        val constraints = constraintsOf(task)
        val missing = ArrayList<String>()
        val header = StringBuilder()
        header.append("# Context for task\n")
        header.append("Task: ").append(task.trim().take(600)).append('\n')
        if (constraints.isNotEmpty()) {
            header.append("Constraints (keep these):\n")
            for (c in constraints) header.append("- ").append(c).append('\n')
        }
        if (index.fileCount() == 0) {
            missing.add("The project is not indexed yet. Index the folder first.")
            header.append("\n## Missing\n- ").append(missing[0]).append('\n')
            return CmPack(header.toString().take(limit), emptyList(), emptyList(), missing, constraints)
        }
        val tokens = CodeQuery.tokens(task)
        val ranked = CodeQuery.rank(index, task, 60, excludes)
        val primary = ranked.filter { !CodeQuery.isTest(it.path) && !CodeQuery.isConfig(it.path) }.take(8)
        val picks = LinkedHashMap<String, CmPicked>()
        fun reasonOf(r: CmRanked): String = r.reasons.joinToString("; ").ifEmpty { "ranked" }
        for (r in primary) picks[r.path] = CmPicked(r.path, "primary", reasonOf(r))
        val paths = index.paths()
        var tests = 0
        for (r in ranked.filter { CodeQuery.isTest(it.path) }.take(2)) {
            if (picks.putIfAbsent(r.path, CmPicked(r.path, "test", reasonOf(r))) == null) tests++
        }
        for (r in primary.take(3)) {
            if (tests >= 3) break
            val stem = r.path.substringAfterLast('/').substringBeforeLast('.').lowercase()
            val match = paths.firstOrNull { CodeQuery.isTest(it) && it.lowercase().contains(stem) && !CmGlob.any(excludes, it) }
            if (match != null && picks.putIfAbsent(match, CmPicked(match, "test", "tests for " + r.path.substringAfterLast('/'))) == null) tests++
        }
        primary.firstOrNull()?.let { top ->
            nearestBuild(index, top.path)?.let { picks.putIfAbsent(it, CmPicked(it, "config", "build file of " + top.path.substringBeforeLast('/', "/"))) }
        }
        for (r in ranked.filter { CodeQuery.isConfig(it.path) }.take(2)) picks.putIfAbsent(r.path, CmPicked(r.path, "config", reasonOf(r)))
        val resolver = CmResolver(paths)
        var related = 0
        for (r in primary.take(3)) {
            for (t in index.importsOf(r.path)) {
                for (hit in resolver.resolve(r.path, t)) {
                    if (related >= 4) break
                    if (CmGlob.any(excludes, hit)) continue
                    if (picks.putIfAbsent(hit, CmPicked(hit, "related", "imported by " + r.path.substringAfterLast('/'))) == null) related++
                }
            }
        }
        if (picks.isEmpty()) {
            missing.add("No indexed file matches the task terms (" + tokens.take(8).joinToString(", ") + "). Name a class, function or file, or index more folders.")
        }
        val named = Regex("[A-Za-z0-9_\\-]+\\.[A-Za-z]{1,5}\\b").findAll(task).map { it.value }.distinct()
        for (f in named) {
            if (paths.none { it.endsWith("/$f") || it == f }) missing.add("File '$f' is mentioned in the task but is not in the index.")
        }
        val out = StringBuilder(header)
        out.append("Project: ").append(name).append(", ").append(index.fileCount()).append(" indexed files\n")
        val picked = ArrayList<CmPicked>()
        val omitted = ArrayList<String>()
        out.append("\n## Files\n")
        for (p in picks.values) {
            val file = index.file(p.path) ?: continue
            val syms = index.symbolsOf(p.path).take(10).joinToString(", ") { it.kind + " " + it.name + ":" + it.line }
            val compact = StringBuilder()
            compact.append("### ").append(p.path).append(" [").append(p.role).append("] ").append(p.reason).append('\n')
            compact.append(file.summary).append('\n')
            if (syms.isNotEmpty()) compact.append("Symbols: ").append(syms).append('\n')
            val full = StringBuilder(compact)
            if (p.role == "primary" || (p.role == "test" && picked.none { it.role == "test" })) {
                val snip = snippetOf(index, source, root, p.path, picksTerms(ranked, p.path), tokens)
                if (snip.isNotEmpty()) full.append("```\n").append(snip).append("\n```\n")
            }
            val room = limit - out.length - 120
            when {
                full.length <= room -> {
                    out.append(full).append('\n')
                    picked.add(p)
                }
                compact.length <= room -> {
                    out.append(compact).append('\n')
                    picked.add(p)
                }
                else -> omitted.add(p.path)
            }
        }
        if (omitted.isNotEmpty()) out.append("## Not included (budget)\n").append(omitted.joinToString("\n") { "- $it" }).append('\n')
        if (missing.isNotEmpty()) out.append("## Missing\n").append(missing.joinToString("\n") { "- $it" }).append('\n')
        var text = out.toString()
        if (text.length > limit) text = text.substring(0, text.lastIndexOf('\n', limit).let { if (it < 0) limit else it })
        return CmPack(text, picked, omitted, missing, constraints)
    }

    private fun picksTerms(ranked: List<CmRanked>, path: String): Set<String> = ranked.firstOrNull { it.path == path }?.terms ?: emptySet()
}
