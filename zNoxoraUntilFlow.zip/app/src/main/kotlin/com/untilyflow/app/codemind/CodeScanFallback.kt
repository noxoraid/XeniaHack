package com.untilyflow.app

object CodeScanFallback {
    private const val MAX_SYMBOLS = 2000
    private const val MAX_IMPORTS = 500
    private const val MAX_TERMS = 96
    private const val MAX_NAME = 120

    private val modifiers = setOf(
        "public", "private", "protected", "internal", "static", "final", "abstract", "open", "override", "sealed",
        "data", "inline", "suspend", "operator", "infix", "tailrec", "lateinit", "const", "external", "actual",
        "expect", "export", "default", "async", "declare", "readonly", "virtual", "constexpr", "extern", "synchronized",
        "native", "transient", "volatile", "strictfp", "value", "annotation", "inner", "noinline", "crossinline",
        "reified", "vararg", "fun", "explicit", "friend", "typename", "template", "companion",
    )

    private val control = setOf(
        "if", "for", "while", "switch", "return", "new", "throw", "catch", "try", "else", "do", "case", "sizeof",
        "delete", "typeof", "await", "yield", "with", "using", "goto", "when", "assert", "synchronized", "elif",
        "except", "lambda", "print",
    )

    private val stop = setOf(
        "the", "and", "for", "with", "this", "that", "from", "into", "return", "val", "var", "let", "const", "fun",
        "function", "class", "public", "private", "static", "void", "null", "true", "false", "int", "string", "else",
        "then", "new", "not", "import", "package", "def", "self", "end", "are", "was", "has", "have", "but", "all",
        "any", "can", "out",
    )

    private fun idStart(c: Char): Boolean = (c in 'a'..'z') || (c in 'A'..'Z') || c == '_' || c == '$'

    private fun idChar(c: Char): Boolean = idStart(c) || (c in '0'..'9')

    private fun blank(c: Char): Boolean = c == ' ' || c == '\t' || c == '\r' || c == '\u000c' || c == '\u000b'

    private fun trimmed(s: String): String {
        var a = 0
        var b = s.length
        while (a < b && blank(s[a])) a++
        while (b > a && blank(s[b - 1])) b--
        return s.substring(a, b)
    }

    private fun cLike(lang: Int): Boolean =
        lang == CmLang.KOTLIN || lang == CmLang.JAVA || lang == CmLang.JS || lang == CmLang.TS ||
            lang == CmLang.C || lang == CmLang.CPP || lang == CmLang.CSS

    private class Sym(val kind: String, val name: String, val line: Int)

    private class State(val lang: Int) {
        var inBlock = false
        var raw = ""
        var depth = 0
        var fence = false
        val syms = ArrayList<Sym>()
        val imports = ArrayList<String>()
        val importSeen = HashSet<String>()
        val symSeen = HashSet<String>()

        fun addImport(target: String) {
            if (target.isEmpty() || target.length > 200 || imports.size >= MAX_IMPORTS) return
            val clean = target.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')
            if (importSeen.add(clean)) imports.add(clean)
        }

        fun addSym(kind: String, name0: String, line: Int) {
            if (name0.isEmpty() || syms.size >= MAX_SYMBOLS) return
            var name = if (name0.length > MAX_NAME) name0.substring(0, MAX_NAME) else name0
            name = name.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')
            if (!symSeen.add("$kind\u0001$name\u0001$line")) return
            syms.add(Sym(kind, name, line))
        }

        fun sanitize(line: String): String {
            val out = StringBuilder(line.length)
            var i = 0
            val n = line.length
            val hash = lang == CmLang.PYTHON
            val slash = cLike(lang)
            while (i < n) {
                if (inBlock) {
                    if (i + 1 < n && line[i] == '*' && line[i + 1] == '/') {
                        inBlock = false
                        out.append("  ")
                        i += 2
                    } else {
                        out.append(' ')
                        i++
                    }
                    continue
                }
                if (raw.isNotEmpty()) {
                    if (line.startsWith(raw, i)) {
                        repeat(raw.length) { out.append(' ') }
                        i += raw.length
                        raw = ""
                    } else {
                        out.append(' ')
                        i++
                    }
                    continue
                }
                val c = line[i]
                if (slash && c == '/' && i + 1 < n && line[i + 1] == '/') {
                    repeat(n - i) { out.append(' ') }
                    break
                }
                if (slash && c == '/' && i + 1 < n && line[i + 1] == '*') {
                    inBlock = true
                    out.append("  ")
                    i += 2
                    continue
                }
                if (hash && c == '#') {
                    repeat(n - i) { out.append(' ') }
                    break
                }
                if ((c == '"' || c == '\'') && (lang == CmLang.KOTLIN || lang == CmLang.JAVA || lang == CmLang.PYTHON) &&
                    line.startsWith(c.toString().repeat(3), i)
                ) {
                    raw = c.toString().repeat(3)
                    out.append("   ")
                    i += 3
                    continue
                }
                if (c == '`' && (lang == CmLang.JS || lang == CmLang.TS)) {
                    raw = "`"
                    out.append(' ')
                    i++
                    continue
                }
                if (c == '"' || c == '\'') {
                    out.append(c)
                    i++
                    while (i < n && line[i] != c) {
                        if (line[i] == '\\' && i + 1 < n) {
                            out.append("  ")
                            i += 2
                        } else {
                            out.append(' ')
                            i++
                        }
                    }
                    if (i < n) {
                        out.append(c)
                        i++
                    }
                    continue
                }
                out.append(c)
                i++
            }
            return out.toString()
        }
    }

    private fun braceDelta(s: String): Int {
        var d = 0
        for (c in s) {
            if (c == '{') d++ else if (c == '}') d--
        }
        return d
    }

    private fun wordAt(s: String, pos: IntArray): String {
        var i = pos[0]
        while (i < s.length && blank(s[i])) i++
        val a = i
        while (i < s.length && idChar(s[i])) i++
        pos[0] = i
        return s.substring(a, i)
    }

    private fun skipParens(s: String, from: Int): Int {
        var d = 0
        var i = from
        while (i < s.length) {
            if (s[i] == '(') d++
            else if (s[i] == ')') {
                d--
                if (d == 0) return i + 1
            }
            i++
        }
        return i
    }

    private fun stripGenerics(s: String): String {
        val out = StringBuilder()
        var d = 0
        for (c in s) {
            if (c == '<') d++
            else if (c == '>' && d > 0) d--
            else if (d == 0) out.append(c)
        }
        return out.toString()
    }

    private fun plainName(s: String): Boolean {
        if (s.isEmpty()) return false
        for (c in s) {
            if (idChar(c) || c == ':' || c == '~') continue
            return false
        }
        return idStart(s[0]) || s[0] == '~'
    }

    private fun splitWords(s: String): List<String> {
        val out = ArrayList<String>()
        var i = 0
        while (i < s.length) {
            while (i < s.length && blank(s[i])) i++
            val a = i
            while (i < s.length && !blank(s[i])) i++
            if (i > a) out.add(s.substring(a, i))
        }
        return out
    }

    private fun methodOf(sc: State, code: String, depthBefore: Int, line: Int) {
        val paren = code.indexOf('(')
        if (paren < 0 || code.indexOf(')') < 0) return
        val head = stripGenerics(code.substring(0, paren))
        if (head.indexOf('=') >= 0 && head.indexOf("operator") < 0) return
        if (head.indexOf('.') >= 0 && sc.lang != CmLang.TS && sc.lang != CmLang.JS) return
        val words = splitWords(head)
        if (words.isEmpty()) return
        if (words[0] in control) return
        val member = sc.lang == CmLang.JS || sc.lang == CmLang.TS
        val scoped = sc.lang == CmLang.CPP && words[0].indexOf("::") >= 0
        if (words.size < 2 && !(member && depthBefore >= 1) && !scoped) return
        if (words.size < 2 && member) {
            val close = skipParens(code, paren)
            if (close > code.length || close == 0 || code[close - 1] != ')') return
            val after = trimmed(code.substring(close))
            if (after.isEmpty() || (after[0] != '{' && after[0] != ':')) return
        }
        var name = words.last()
        while (name.isNotEmpty() && (name[0] == '*' || name[0] == '&')) name = name.substring(1)
        if (!plainName(name) || name in control) return
        val limit = if (sc.lang == CmLang.C) 0 else 2
        if (depthBefore > limit) return
        sc.addSym(if (depthBefore >= 1) "method" else "function", name, line)
    }

    private fun nameAfter(code: String, from: Int): String {
        var j = from
        while (j < code.length && (blank(code[j]) || code[j] == '*')) j++
        val a = j
        while (j < code.length && (idChar(code[j]) || code[j] == ':')) j++
        return code.substring(a, j)
    }

    private fun declOf(sc: State, code: String, depthBefore: Int, indent: Int, line: Int) {
        val pos = intArrayOf(0)
        val mods = ArrayList<String>()
        var w: String
        while (true) {
            while (pos[0] < code.length && blank(code[pos[0]])) pos[0]++
            if (pos[0] < code.length && code[pos[0]] == '@') {
                pos[0]++
                wordAt(code, pos)
                var j = pos[0]
                while (j < code.length && blank(code[j])) j++
                if (j < code.length && code[j] == '(') pos[0] = skipParens(code, j)
                continue
            }
            w = wordAt(code, pos)
            if (w.isEmpty()) return
            val jsConst = w == "const" && (sc.lang == CmLang.JS || sc.lang == CmLang.TS)
            if (w in modifiers && !(w == "fun" && sc.lang == CmLang.KOTLIN) && !jsConst) {
                mods.add(w)
                continue
            }
            break
        }
        val i = pos[0]
        val hasEnum = "enum" in mods
        val rest = code.substring(i)
        val ended = !rest.contains('{') && rest.isNotEmpty() && trimmed(rest).lastOrNull() == ';'

        if (sc.lang == CmLang.PYTHON) {
            if (w == "def") sc.addSym(if (indent > 0) "method" else "function", nameAfter(code, i), line)
            else if (w == "class") sc.addSym("class", nameAfter(code, i), line)
            return
        }

        if (sc.lang == CmLang.KOTLIN && w == "fun") {
            val paren = code.indexOf('(', i)
            if (paren < 0) return
            var name = trimmed(stripGenerics(code.substring(i, paren)))
            val dot = name.lastIndexOf('.')
            if (dot >= 0) name = name.substring(dot + 1)
            if (!plainName(name)) return
            sc.addSym(if (depthBefore > 0) "method" else "function", name, line)
            return
        }

        val typed = sc.lang != CmLang.C
        if (w == "class" || w == "interface" || w == "struct" || w == "enum" || w == "union" || w == "trait" ||
            w == "record" || w == "namespace" || w == "object" || w == "typealias" || (w == "type" && typed) ||
            (w == "module" && sc.lang == CmLang.TS)
        ) {
            if (w == "object" && sc.lang != CmLang.KOTLIN) return
            if (w == "record" && sc.lang != CmLang.JAVA) return
            if (w == "trait" && sc.lang != CmLang.KOTLIN) return
            if (w == "typealias" && sc.lang != CmLang.KOTLIN) return
            if (w == "type" && sc.lang != CmLang.TS) return
            if ((w == "struct" || w == "union") && sc.lang != CmLang.C && sc.lang != CmLang.CPP) return
            if (w == "namespace" && sc.lang != CmLang.CPP && sc.lang != CmLang.TS) return
            if (ended && (sc.lang == CmLang.C || sc.lang == CmLang.CPP)) return
            var name = nameAfter(code, i)
            if (w == "object" && name.isEmpty() && "companion" in mods) name = "Companion"
            if (w == "enum" && name == "class") {
                val skip = intArrayOf(i)
                wordAt(code, skip)
                name = nameAfter(code, skip[0])
            }
            if (name.isEmpty() || !idStart(name[0])) return
            val kind = when {
                w == "typealias" || w == "type" -> "type"
                hasEnum -> "enum"
                w == "union" -> "struct"
                w == "module" -> "namespace"
                else -> w
            }
            sc.addSym(kind, name, line)
            return
        }

        if (sc.lang == CmLang.JS || sc.lang == CmLang.TS) {
            if (w == "function") {
                sc.addSym("function", nameAfter(code, i), line)
                return
            }
            if (w == "const" || w == "let" || w == "var") {
                val at = intArrayOf(i)
                val name = wordAt(code, at)
                val eq = code.indexOf('=', at[0])
                if (name.isNotEmpty() && eq >= 0) {
                    val tail = trimmed(code.substring(eq + 1))
                    val fn = tail.startsWith("function") || tail.contains("=>") || tail.startsWith("async")
                    if (fn) sc.addSym("function", name, line)
                }
                return
            }
            if (w == "enum") {
                sc.addSym("enum", nameAfter(code, i), line)
                return
            }
        }

        if (sc.lang == CmLang.KOTLIN) return
        if (w != "import" && w != "package" && w != "using" && w != "typedef") methodOf(sc, code, depthBefore, line)
    }

    private fun quotedAfter(sc: State, line: String, from: Int) {
        var i = from
        while (i < line.length) {
            if (line[i] == '\'' || line[i] == '"') {
                val e = line.indexOf(line[i], i + 1)
                if (e < 0) return
                sc.addImport(line.substring(i + 1, e))
                return
            }
            i++
        }
    }

    private fun importsOf(sc: State, rawLine: String) {
        val t = trimmed(rawLine)
        when (sc.lang) {
            CmLang.KOTLIN, CmLang.JAVA -> {
                if (!t.startsWith("import ")) return
                var rest = trimmed(t.substring(7))
                if (rest.startsWith("static ")) rest = trimmed(rest.substring(7))
                var end = 0
                while (end < rest.length && (idChar(rest[end]) || rest[end] == '.' || rest[end] == '*')) end++
                sc.addImport(rest.substring(0, end))
            }
            CmLang.JS, CmLang.TS -> {
                val from = t.indexOf(" from ")
                if ((t.startsWith("import ") || t.startsWith("export ")) && from >= 0) {
                    quotedAfter(sc, t, from + 6)
                    return
                }
                if (t.startsWith("import ") && t.length > 7 && (t[7] == '\'' || t[7] == '"')) {
                    quotedAfter(sc, t, 7)
                    return
                }
                val req = t.indexOf("require(")
                if (req >= 0) quotedAfter(sc, t, req + 8)
                val dyn = t.indexOf("import(")
                if (dyn >= 0) quotedAfter(sc, t, dyn + 7)
            }
            CmLang.PYTHON -> {
                if (t.startsWith("from ")) {
                    var j = 5
                    while (j < t.length && blank(t[j])) j++
                    val a = j
                    while (j < t.length && (idChar(t[j]) || t[j] == '.')) j++
                    sc.addImport(t.substring(a, j))
                } else if (t.startsWith("import ")) {
                    val rest = t.substring(7)
                    var i = 0
                    while (i < rest.length) {
                        val a = i
                        while (i < rest.length && rest[i] != ',') i++
                        var part = trimmed(rest.substring(a, i))
                        val alias = part.indexOf(" as ")
                        if (alias >= 0) part = trimmed(part.substring(0, alias))
                        sc.addImport(part)
                        i++
                    }
                }
            }
            CmLang.C, CmLang.CPP -> {
                if (t.isEmpty() || t[0] != '#') return
                var rest = trimmed(t.substring(1))
                if (!rest.startsWith("include")) return
                rest = trimmed(rest.substring(7))
                if (rest.isEmpty()) return
                val open = rest[0]
                val close = if (open == '<') '>' else '"'
                if (open != '<' && open != '"') return
                val e = rest.indexOf(close, 1)
                if (e >= 0) sc.addImport(rest.substring(1, e))
            }
            CmLang.HTML -> {
                for (attr in listOf("src=", "href=")) {
                    var pos = 0
                    while (true) {
                        pos = t.indexOf(attr, pos)
                        if (pos < 0) break
                        val p = pos + attr.length
                        if (p < t.length && (t[p] == '"' || t[p] == '\'')) {
                            val e = t.indexOf(t[p], p + 1)
                            if (e >= 0) {
                                val v = t.substring(p + 1, e)
                                if (!v.contains("://") && v.isNotEmpty() && v[0] != '#') sc.addImport(v)
                            }
                        }
                        pos = p
                    }
                }
            }
            CmLang.CSS -> {
                if (!t.startsWith("@import")) return
                val q = t.indexOfFirst { it == '"' || it == '\'' }
                if (q >= 0) quotedAfter(sc, t, q)
            }
            else -> {}
        }
    }

    private fun markdownOf(sc: State, line: String, number: Int) {
        val t = trimmed(line)
        if (t.startsWith("```") || t.startsWith("~~~")) {
            sc.fence = !sc.fence
            return
        }
        if (sc.fence || t.isEmpty() || t[0] != '#') return
        var i = 0
        while (i < t.length && t[i] == '#') i++
        if (i > 6 || i >= t.length || t[i] != ' ') return
        sc.addSym("heading", trimmed(t.substring(i)), number)
    }

    private fun termsOf(data: ByteArray, len: Int): List<Pair<String, Int>> {
        val freq = HashMap<String, Int>()
        fun bump(cur: String) {
            if (cur.length >= 3 && cur !in stop && freq.size < 20000) freq[cur] = (freq[cur] ?: 0) + 1
        }
        fun at(k: Int): Int = data[k].toInt() and 0xff
        fun isStart(c: Int): Boolean = (c in 97..122) || (c in 65..90) || c == 95 || c == 36
        fun isChar(c: Int): Boolean = isStart(c) || (c in 48..57)
        var i = 0
        while (i < len) {
            if (!isStart(at(i)) || at(i) == 36) {
                i++
                continue
            }
            val a = i
            while (i < len && isChar(at(i)) && at(i) != 36) i++
            val n = i - a
            if (n < 3 || n > 64) continue
            val cur = StringBuilder()
            for (k in a until i) {
                val c = at(k)
                val upper = c in 65..90
                val prevLower = k > a && (at(k - 1) in 97..122 || at(k - 1) in 48..57)
                val nextLower = k + 1 < i && at(k + 1) in 97..122
                val prevUpper = k > a && at(k - 1) in 65..90
                if (c == 95) {
                    bump(cur.toString())
                    cur.setLength(0)
                    continue
                }
                if (upper && (prevLower || (prevUpper && nextLower))) {
                    bump(cur.toString())
                    cur.setLength(0)
                }
                cur.append((if (upper) c + 32 else c).toChar())
            }
            bump(cur.toString())
        }
        val top = freq.entries.map { it.key to it.value }
            .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })
        return if (top.size > MAX_TERMS) top.subList(0, MAX_TERMS) else top
    }

    private fun fnv(data: ByteArray, len: Int): String {
        var h = -3750763034362895579L
        for (i in 0 until len) {
            h = h xor (data[i].toLong() and 0xff)
            h *= 1099511628211L
        }
        return java.lang.Long.toHexString(h).padStart(16, '0')
    }

    fun pack(data: ByteArray, len0: Int, lang: Int): String {
        val len = minOf(len0, data.size).coerceAtLeast(0)
        if (lang < 0) {
            var count = 0
            for (i in 0 until len) if (data[i] == '\n'.code.toByte()) count++
            if (len > 0 && data[len - 1] != '\n'.code.toByte()) count++
            return "H\t${fnv(data, len)}\t$count\n"
        }
        val sc = State(lang)
        var lines = 0
        var pos = 0
        val decl = lang == CmLang.KOTLIN || lang == CmLang.JAVA || lang == CmLang.JS || lang == CmLang.TS ||
            lang == CmLang.PYTHON || lang == CmLang.C || lang == CmLang.CPP
        while (pos < len) {
            var end = pos
            while (end < len && data[end] != '\n'.code.toByte()) end++
            var stopAt = end
            if (stopAt > pos && data[stopAt - 1] == '\r'.code.toByte()) stopAt--
            val line = String(data, pos, stopAt - pos, Charsets.ISO_8859_1)
            lines++
            if (lang == CmLang.MARKDOWN) {
                markdownOf(sc, line, lines)
            } else if (decl) {
                val wasBlock = sc.inBlock
                val wasRaw = sc.raw.isNotEmpty()
                val code = sc.sanitize(line)
                importsOf(sc, if (wasBlock || wasRaw) "" else line)
                var t = trimmed(code)
                var indent = 0
                while (indent < code.length && blank(code[indent])) indent++
                if (!wasBlock && !wasRaw && t.isNotEmpty()) {
                    while (t.isNotEmpty() && t[0] == '}') t = trimmed(t.substring(1))
                    if (t.isNotEmpty() && t[0] != '#') declOf(sc, t, sc.depth, indent, lines)
                }
                sc.depth += braceDelta(code)
                if (sc.depth < 0) sc.depth = 0
            } else {
                importsOf(sc, line)
            }
            pos = end + 1
        }
        val out = StringBuilder()
        out.append("H\t").append(fnv(data, len)).append('\t').append(lines).append('\n')
        for (s in sc.syms) out.append("S\t").append(s.kind).append('\t').append(s.name).append('\t').append(s.line).append('\n')
        for (imp in sc.imports) out.append("I\t").append(imp).append('\n')
        for ((term, n) in termsOf(data, len)) out.append("T\t").append(term).append('\t').append(n).append('\n')
        return String(out.toString().toByteArray(Charsets.ISO_8859_1), Charsets.UTF_8)
    }
}
