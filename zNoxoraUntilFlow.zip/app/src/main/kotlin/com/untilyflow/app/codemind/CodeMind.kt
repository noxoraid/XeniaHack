package com.untilyflow.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.SecureRandom

object CmPrefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("nx_cm", Context.MODE_PRIVATE)

    fun agents(ctx: Context): Boolean = p(ctx).getBoolean("agents", true)

    fun setAgents(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("agents", v).apply()

    fun autoIndex(ctx: Context): Boolean = p(ctx).getBoolean("auto_index", true)

    fun setAutoIndex(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("auto_index", v).apply()

    fun minFiles(ctx: Context): Int = p(ctx).getInt("min_files", CodeAuto.MIN_FILES)

    fun setMinFiles(ctx: Context, v: Int) = p(ctx).edit().putInt("min_files", v.coerceIn(0, 1000)).apply()

    fun maxKb(ctx: Context): Int = p(ctx).getInt("max_kb", 512)

    fun setMaxKb(ctx: Context, v: Int) = p(ctx).edit().putInt("max_kb", v.coerceIn(16, 4096)).apply()

    fun maxFiles(ctx: Context): Int = p(ctx).getInt("max_files", 20000)

    fun setMaxFiles(ctx: Context, v: Int) = p(ctx).edit().putInt("max_files", v.coerceIn(100, 100000)).apply()

    fun excludes(ctx: Context): String = p(ctx).getString("excludes", CmConfig.DEFAULT_EXCLUDES.joinToString(", ")) ?: ""

    fun setExcludes(ctx: Context, v: String) = p(ctx).edit().putString("excludes", v).apply()

    fun capMb(ctx: Context): Int = p(ctx).getInt("cap_mb", 200)

    fun setCapMb(ctx: Context, v: Int) = p(ctx).edit().putInt("cap_mb", v.coerceIn(5, 4000)).apply()

    fun keepDays(ctx: Context): Int = p(ctx).getInt("keep_days", 0)

    fun setKeepDays(ctx: Context, v: Int) = p(ctx).edit().putInt("keep_days", v.coerceIn(0, 3650)).apply()

    fun port(ctx: Context): Int = p(ctx).getInt("port", 8765)

    fun setPort(ctx: Context, v: Int) = p(ctx).edit().putInt("port", v).apply()

    fun mcpWrite(ctx: Context): Boolean = p(ctx).getBoolean("mcp_write", true)

    fun setMcpWrite(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("mcp_write", v).apply()

    fun active(ctx: Context): String = p(ctx).getString("active", "") ?: ""

    fun setActive(ctx: Context, v: String) = p(ctx).edit().putString("active", v).apply()

    fun token(ctx: Context): String {
        val have = p(ctx).getString("token", "") ?: ""
        if (have.length >= 32) return have
        return resetToken(ctx)
    }

    fun resetToken(ctx: Context): String {
        val bytes = ByteArray(24)
        SecureRandom().nextBytes(bytes)
        val value = bytes.joinToString("") { String.format("%02x", it) }
        p(ctx).edit().putString("token", value).apply()
        return value
    }
}

class CmProjectRec(val id: String, var name: String, val backend: String, val root: String, val created: Long, var used: Long)

class FsSource(private val fs: FsBackend) : CodeSource {
    override fun list(dir: String): List<CmEntry> = fs.list(dir).map { CmEntry(it.name, it.dir, it.size) }

    override fun read(path: String, max: Int): ByteArray {
        fs.open(path).use { input ->
            val out = ByteArrayOutputStream(minOf(max, 16384))
            val buf = ByteArray(8192)
            while (out.size() < max) {
                val got = input.read(buf, 0, minOf(buf.size, max - out.size()))
                if (got < 0) break
                out.write(buf, 0, got)
            }
            return out.toByteArray()
        }
    }

    override fun stamp(path: String): Long = if (isLocal(fs)) File(path).lastModified() else -1L

    override fun exists(path: String): Boolean = fs.kind(path) != 0
}

class UnavailableSource(private val why: String) : CodeSource {
    override fun list(dir: String): List<CmEntry> = throw java.io.IOException(why)

    override fun read(path: String, max: Int): ByteArray = throw java.io.IOException(why)

    override fun stamp(path: String): Long = -1L

    override fun exists(path: String): Boolean = false
}

class CmView(
    val rec: CmProjectRec,
    val project: CmProject,
    val stats: CmStats,
    val meta: Map<String, String>,
)

object CodeMind : CodeMindApi {
    private const val BRIEF_KEEP = 200

    val projects = mutableStateListOf<CmProjectRec>()
    val running = mutableStateMapOf<String, CmProgress>()
    val activity = mutableStateListOf<String>()
    var activeId by mutableStateOf("")
    var version by mutableStateOf(0)
        private set
    var lastReduction by mutableStateOf("")

    private var app: Context? = null
    private val stores = HashMap<String, SqlIndex>()
    private val autoTried = CmOnce()
    private val kicked = HashMap<String, Long>()
    val briefs = mutableStateListOf<CmBriefNote>()
    private var tools: List<McpTool> = emptyList()

    @Synchronized
    fun attach(ctx: Context) {
        if (app != null) return
        val context = ctx.applicationContext
        app = context
        tools = McpTools.build(this)
        try {
            val f = registryFile(context)
            if (f.isFile) {
                val list = CmJson.parse(f.readText()) as? List<*> ?: emptyList<Any?>()
                for (o in list) {
                    val m = o as? Map<*, *> ?: continue
                    projects.add(
                        CmProjectRec(
                            m["id"] as String, m["name"] as String, m["backend"] as String, m["root"] as String,
                            (m["created"] as? Number)?.toLong() ?: 0L, (m["used"] as? Number)?.toLong() ?: 0L,
                        ),
                    )
                }
            }
        } catch (e: Exception) {
            ErrorLog.report(ErrorText("CodeMind project list"), e)
        }
        try {
            val f = briefFile(context)
            if (f.isFile) f.readLines().takeLast(BRIEF_KEEP).mapNotNull { CmBriefNote.decode(it) }.forEach { briefs.add(it) }
        } catch (_: Exception) {
        }
        activeId = CmPrefs.active(context).takeIf { id -> projects.any { it.id == id } } ?: projects.firstOrNull()?.id ?: ""
        prune(context)
    }

    fun mcpTools(): List<McpTool> = tools

    fun snapshot(rec: CmProjectRec): CmView {
        val s = storeOf(rec)
        val keys = listOf("run.at", "run.millis", "run.scanned", "run.indexed", "run.skipped", "run.hits", "run.misses", "run.errors", "run.removed", "run.full", "total.hits", "total.misses", "warn")
        val meta = HashMap<String, String>()
        for (k in keys) s.meta(k)?.let { meta[k] = it }
        return CmView(rec, project(rec), s.stats(), meta)
    }

    fun exportContext(text: String): File {
        val dir = File(AppFolder.dir("codemind"), "exports").also { it.mkdirs() }
        val f = File(dir, "context-" + java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US).format(java.util.Date()) + ".md")
        AppFolder.writeAtomic(f, text)
        return f
    }

    fun wipeAll(ctx: Context) {
        for (rec in projects.toList()) {
            if (running.containsKey(rec.id)) throw Exception(tr("Indexing is running"))
        }
        for (rec in projects.toList()) remove(rec)
        synchronized(this) { briefs.clear() }
        briefFile(ctx).delete()
        autoTried.clear()
        CmPrefs.resetToken(ctx)
    }

    fun specLine(): String = if (app?.let { CmPrefs.agents(it) } == true) CodeMindTool.spec() + "\n" else ""

    private fun context(): Context = app ?: throw CmToolError("CodeMind is not ready")

    private fun dir(ctx: Context): File = File(ctx.filesDir, "codemind").also { it.mkdirs() }

    private fun registryFile(ctx: Context): File = File(dir(ctx), "projects.json")

    private fun briefFile(ctx: Context): File = File(dir(ctx), "briefs.tsv")

    @Synchronized
    private fun logBrief(rec: CmProjectRec, chars: Int, files: Int, outcome: String) {
        val ctx = app ?: return
        briefs.add(CmBriefNote(System.currentTimeMillis(), rec.name, chars, files, outcome))
        while (briefs.size > BRIEF_KEEP) briefs.removeAt(0)
        try {
            AppFolder.writeAtomic(briefFile(ctx), briefs.joinToString("\n") { it.encode() })
        } catch (_: Exception) {
        }
    }

    private fun save() {
        val ctx = app ?: return
        try {
            val rows = projects.map { linkedMapOf("id" to it.id, "name" to it.name, "backend" to it.backend, "root" to it.root, "created" to it.created, "used" to it.used) }
            AppFolder.writeAtomic(registryFile(ctx), CmJson.write(rows))
        } catch (e: Exception) {
            ErrorLog.report(ErrorText("CodeMind project list"), e)
        }
    }

    private fun prune(ctx: Context) {
        val days = CmPrefs.keepDays(ctx)
        if (days <= 0) return
        val limit = System.currentTimeMillis() - days * 86_400_000L
        for (rec in projects.toList()) {
            if (rec.used in 1 until limit && !running.containsKey(rec.id)) storeOf(rec).wipe()
        }
    }

    fun note(text: String) {
        activity.add(0, java.text.SimpleDateFormat("HH:mm:ss", Lang.locale()).format(java.util.Date()) + "  " + text)
        while (activity.size > 30) activity.removeAt(activity.size - 1)
        version++
    }

    fun keyOf(fs: FsBackend): String = when {
        fs === InternalFs -> "internal"
        fs === NoxoraFs -> "noxora"
        fs === RootFs -> "root"
        fs is VpsFs -> "vps:" + fs.vps.profile.name
        else -> ""
    }

    fun fsFor(rec: CmProjectRec): FsBackend? = when {
        rec.backend == "internal" -> InternalFs
        rec.backend == "noxora" -> NoxoraFs
        rec.backend == "root" -> if (RootFs.available()) RootFs else null
        rec.backend.startsWith("vps:") -> Hub.vps?.takeIf { it.profile.name == rec.backend.substring(4) }?.let { VpsFs(it) }
        else -> null
    }

    fun placeOf(rec: CmProjectRec): String = when {
        rec.backend == "internal" -> "Internal"
        rec.backend == "noxora" -> "NoxoraStorage"
        rec.backend == "root" -> "Root"
        else -> rec.backend.removePrefix("vps:")
    }

    private fun sourceOf(rec: CmProjectRec): CodeSource =
        fsFor(rec)?.let { FsSource(it) } ?: UnavailableSource("Storage of this project is not connected (" + placeOf(rec) + ")")

    @Synchronized
    fun storeOf(rec: CmProjectRec): SqlIndex = stores.getOrPut(rec.id) { SqlIndex(File(dir(context()), rec.id + ".db")) }

    fun active(): CmProjectRec? = projects.firstOrNull { it.id == activeId } ?: projects.firstOrNull()

    fun select(ctx: Context, id: String) {
        activeId = id
        CmPrefs.setActive(ctx, id)
    }

    fun add(ctx: Context, fs: FsBackend, root: String): CmProjectRec {
        attach(ctx)
        val key = keyOf(fs)
        if (key.isEmpty()) throw Exception(tr("This storage cannot be indexed"))
        val clean = fixPath(root, "/")
        if (fs.kind(clean) != 2) throw Exception(tr("Folder not found"))
        projects.firstOrNull { it.backend == key && it.root == clean }?.let { return it }
        val id = Integer.toHexString((key + "\u0000" + clean).hashCode()) + clean.length.toString(16)
        var name = clean.substringAfterLast('/').ifEmpty { "root" }
        if (projects.any { it.name.equals(name, true) }) name = name + " (" + key.removePrefix("vps:") + ")"
        val rec = CmProjectRec(id, name, key, clean, System.currentTimeMillis(), 0L)
        projects.add(rec)
        if (activeId.isEmpty()) select(ctx, id)
        save()
        note("Added project $name")
        return rec
    }

    fun remove(rec: CmProjectRec) {
        val open = synchronized(this) { stores.remove(rec.id) }
        if (open != null) {
            open.delete()
        } else {
            for (suffix in listOf("", "-wal", "-shm", "-journal")) File(dir(context()).path + "/" + rec.id + ".db" + suffix).delete()
        }
        projects.remove(rec)
        if (activeId == rec.id) activeId = projects.firstOrNull()?.id ?: ""
        CmPrefs.setActive(context(), activeId)
        save()
        note("Deleted index of ${rec.name}")
    }

    fun clear(rec: CmProjectRec) {
        if (running.containsKey(rec.id)) throw Exception(tr("Indexing is running"))
        storeOf(rec).wipe()
        note("Cleared index of ${rec.name}")
    }

    fun stateOf(rec: CmProjectRec): String {
        if (running.containsKey(rec.id)) return "indexing"
        val s = storeOf(rec)
        if (s.fileCount() == 0 && s.meta("state") == null) return "empty"
        return when (val st = s.meta("state")) {
            "indexing" -> "interrupted"
            null -> "ready"
            else -> st
        }
    }

    fun project(rec: CmProjectRec): CmProject {
        val s = storeOf(rec)
        return CmProject(rec.id, rec.name, rec.root, placeOf(rec), stateOf(rec), s.fileCount(), s.meta("run.at")?.toLongOrNull() ?: 0L)
    }

    private fun configOf(ctx: Context): CmConfig = CmConfig(
        CmPrefs.maxKb(ctx) * 1024, CmPrefs.maxFiles(ctx),
        CmPrefs.excludes(ctx).split(',', '\n').map { it.trim() }.filter { it.isNotEmpty() },
    )

    fun startIndex(rec: CmProjectRec, force: Boolean = false, only: List<String>? = null): TaskRun? {
        val ctx = context()
        synchronized(this) { if (running.containsKey(rec.id)) return null }
        val fs = fsFor(rec) ?: throw Exception(tr("Storage of this project is not connected"))
        val progress = CmProgress()
        running[rec.id] = progress
        note("Indexing ${rec.name}")
        return TaskBoard.start(TaskKind.Index, rec.name) { run ->
            var tick = 0
            val stopped = {
                if (++tick % 6 == 0) {
                    run.total = progress.total
                    run.done = progress.done
                    run.skipped = progress.skipped
                    run.bytes = progress.bytes
                    run.detail = progress.detail
                    TaskBoard.publish()
                }
                run.stop
            }
            try {
                val store = storeOf(rec)
                val result = CodeIndexer.run(FsSource(fs), store, rec.root, configOf(ctx), progress, stopped, only, force)
                run.total = progress.total
                run.done = progress.done
                run.skipped = progress.skipped
                run.detail = summaryOf(rec.name, result)
                rec.used = System.currentTimeMillis()
                val size = store.stats().storeBytes
                val cap = CmPrefs.capMb(ctx) * 1024L * 1024L
                if (size > cap) {
                    store.setMeta("warn", "Index size " + humanSize(size) + " is over the limit of " + humanSize(cap))
                } else {
                    store.setMeta("warn", "")
                }
                save()
                note(summaryOf(rec.name, result))
            } catch (e: CmStopped) {
                note("Stopped indexing ${rec.name}")
                throw TaskStopped()
            } finally {
                running.remove(rec.id)
                version++
            }
        }
    }

    fun summaryOf(name: String, r: CmRun): String =
        "Indexed $name: scanned ${r.scanned} files, analyzed ${r.misses}, reused ${r.hits}, skipped ${r.skipped}, errors ${r.errors}, removed ${r.removed}, ${r.millis} ms"

    fun indexBlocking(rec: CmProjectRec, force: Boolean, only: List<String>?, waitMs: Long, stopped: () -> Boolean = { false }): String {
        val run = startIndex(rec, force, only) ?: return "Indexing of ${rec.name} is already running."
        val end = System.currentTimeMillis() + waitMs
        while (run.state == TaskState.Running) {
            if (stopped()) {
                run.stop = true
                break
            }
            if (System.currentTimeMillis() > end) {
                return "Indexing continues in the background (${run.done}/${run.total}). Call get_index_statistics to follow it."
            }
            Thread.sleep(120)
        }
        return when (run.state) {
            TaskState.Done -> run.detail.ifEmpty { "Indexed ${rec.name}" }
            TaskState.Stopped -> "Indexing was stopped. Run it again to continue from the cache."
            else -> "Indexing failed: " + (run.error ?: "unknown error")
        }
    }

    override fun projects(): List<CmProject> = projects.map { project(it) }

    override fun open(ref: String?): CmCtx {
        context()
        val rec = if (ref.isNullOrBlank()) active() else projects.firstOrNull { it.id == ref || it.name.equals(ref, true) }
        if (rec == null) {
            if (!ref.isNullOrBlank()) throw CmToolError("Unknown project '$ref'. Known: " + projects.joinToString(", ") { it.name }.ifEmpty { "none" })
            throw CmToolError("No project is indexed yet. In the app open CodeMind > Projects, add a folder and index it.")
        }
        rec.used = System.currentTimeMillis()
        return CmCtx(project(rec), storeOf(rec), sourceOf(rec))
    }

    override fun canUpdate(): Boolean = app?.let { CmPrefs.mcpWrite(it) } ?: false

    override fun update(ctx: CmCtx, paths: List<String>, force: Boolean): String {
        val rec = projects.firstOrNull { it.id == ctx.project.id } ?: throw CmToolError("Project is gone")
        return indexBlocking(rec, force, paths.ifEmpty { null }, 20_000)
    }

    fun recFor(target: AgentTarget): CmProjectRec? {
        val key = keyOf(target.source)
        val cwd = target.cwd
        return projects.filter { it.backend == key && (cwd == it.root || cwd.startsWith(it.root.trimEnd('/') + "/")) }.maxByOrNull { it.root.length }
    }

    fun callTool(name: String, args: Map<String, Any?>): String {
        val tool = tools.firstOrNull { it.name == name } ?: throw CmToolError("Unknown action")
        val problem = McpSchema.validate(tool.schema, args)
        if (problem != null) throw CmToolError(problem)
        return tool.run(args)
    }

    private fun autoPrepare(target: AgentTarget) {
        val ctx = app ?: return
        if (!CmPrefs.autoIndex(ctx)) return
        val fs = target.source
        val key = keyOf(fs)
        if (key.isEmpty()) return
        if (key.startsWith("vps:") && Hub.vps?.let { it.profile.name } != key.removePrefix("vps:")) return
        val cwd = target.cwd
        if (!autoTried.first(key + "\u0000" + cwd)) return
        Thread({
            try {
                val root = CodeRoot.autoRoot(FsSource(fs), cwd)
                if (root == null) {
                    note(tr("Auto-index skipped, folder is too broad: {0}", cwd))
                } else {
                    val rec = add(ctx, fs, root)
                    synchronized(kicked) { kicked[rec.id] = System.currentTimeMillis() }
                    startIndex(rec)
                }
            } catch (e: Exception) {
                note(tr("Auto-index failed: {0}", e.message ?: e.toString()))
            }
        }, "codemind-auto").apply {
            isDaemon = true
            start()
        }
    }

    private fun refreshFor(rec: CmProjectRec) {
        val ctx = app ?: return
        if (!CmPrefs.autoIndex(ctx)) return
        if (running.containsKey(rec.id)) return
        val fs = fsFor(rec) ?: return
        val local = isLocal(fs)
        val now = System.currentTimeMillis()
        val last = maxOf(storeOf(rec).meta("run.at")?.toLongOrNull() ?: 0L, synchronized(kicked) { kicked[rec.id] ?: 0L })
        if (!CodeAuto.refreshDue(local, last, now)) return
        synchronized(kicked) { kicked[rec.id] = now }
        if (local) indexBlocking(rec, false, null, CodeAuto.LOCAL_WAIT_MS) else startIndex(rec)
    }

    fun brief(target: AgentTarget, task: String): String {
        val ctx = app ?: return ""
        if (!CmPrefs.agents(ctx)) return ""
        val rec = recFor(target)
        if (rec == null) {
            autoPrepare(target)
            return ""
        }
        try {
            refreshFor(rec)
        } catch (_: Exception) {
        }
        return try {
            val store = storeOf(rec)
            val files = store.fileCount()
            if (files == 0) {
                logBrief(rec, 0, 0, "empty")
                return ""
            }
            if (!CodeAuto.briefWorth(files, CmPrefs.minFiles(ctx))) {
                logBrief(rec, 0, files, "small")
                return ""
            }
            val ranked = CodeQuery.rank(store, task, 12, emptyList()).filter { !CodeQuery.isConfig(it.path) }.take(6)
            val out = StringBuilder()
            out.append("CodeMind memory of project ").append(rec.name).append(" (").append(rec.root).append("), ").append(files).append(" files indexed")
            if (stateOf(rec) != "ready") out.append(" [").append(stateOf(rec)).append(']')
            out.append(".\nTools: nx cm find <text> | sym <name> | file <path> | deps <path> | ctx <task> | index\n")
            if (ranked.isNotEmpty()) {
                out.append("Files likely relevant to the request (lexical ranking, verify before relying on it):\n")
                for (r in ranked) out.append("- ").append(r.path).append(" (").append(r.reasons.joinToString("; ")).append(")\n")
            }
            val text = out.toString().take(1600).trimEnd()
            logBrief(rec, text.length, files, "sent")
            text
        } catch (_: Exception) {
            ""
        }
    }
}
