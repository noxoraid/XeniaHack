package com.untilyflow.app

class CmMeasure(val chars: Int, val lines: Int, val tokens: Int) {
    companion object {
        fun of(text: String): CmMeasure {
            val lines = if (text.isEmpty()) 0 else text.count { it == '\n' } + (if (text.endsWith("\n")) 0 else 1)
            return CmMeasure(text.length, lines, (text.length + 3) / 4)
        }
    }
}

class CmTrimStep(val name: String, val count: Int, val chars: Int)

class CmTrim(val text: String, val before: CmMeasure, val after: CmMeasure, val steps: List<CmTrimStep>, val aggressive: Boolean) {
    val percent: Double
        get() = if (before.chars == 0) 0.0 else (before.chars - after.chars).toDouble() / before.chars * 100.0

    fun report(): String {
        val out = StringBuilder()
        out.append("Mode: ").append(if (aggressive) "aggressive" else "conservative").append('\n')
        out.append("Characters: ").append(before.chars).append(" -> ").append(after.chars).append('\n')
        out.append("Lines: ").append(before.lines).append(" -> ").append(after.lines).append('\n')
        out.append("Tokens (estimate, chars/4): ").append(before.tokens).append(" -> ").append(after.tokens).append('\n')
        out.append("Reduction: ").append(String.format(java.util.Locale.US, "%.1f", percent)).append("% of characters\n")
        if (before.chars <= after.chars) out.append("No measurable reduction. The text was left unchanged.\n")
        for (s in steps) if (s.count > 0) out.append("- ").append(s.name).append(": ").append(s.count).append(" (").append(s.chars).append(" chars)\n")
        out.append("Method: character count; tokens are an estimate, not a model tokenizer. Real provider token use can differ.")
        return out.toString()
    }
}

object ContextTrim {
    private val safeLangs = setOf(
        "kotlin", "kt", "java", "js", "javascript", "ts", "typescript", "tsx", "jsx", "c", "cpp", "h", "hpp", "css", "json",
        "xml", "html", "rust", "go", "swift", "cs", "dart", "kts", "gradle",
    )
    private val metaLine = Regex("^\\s*(?:[-*]\\s+)?[A-Za-z][A-Za-z0-9 _/.-]{0,40}:\\s+\\S.*$")
    private val decor = Regex("^\\s*([=\\-*_#~])\\1{4,}\\s*$")
    private val header = Regex("^(#{1,4})\\s+(\\S+)")

    private class Block(val fence: Boolean, val lang: String, val lines: MutableList<String>)

    private fun split(text: String): List<Block> {
        val out = ArrayList<Block>()
        var cur: Block? = null
        var inFence = false
        for (line in text.split('\n')) {
            val t = line.trim()
            if (t.startsWith("```")) {
                if (!inFence) {
                    cur?.let { out.add(it) }
                    cur = Block(true, t.removePrefix("```").trim().lowercase(), arrayListOf(line))
                    inFence = true
                } else {
                    cur!!.lines.add(line)
                    out.add(cur)
                    cur = null
                    inFence = false
                }
                continue
            }
            if (inFence) {
                cur!!.lines.add(line)
            } else {
                if (cur == null) cur = Block(false, "", ArrayList())
                cur.lines.add(line)
            }
        }
        cur?.let { out.add(it) }
        return out
    }

    private fun join(blocks: List<Block>): String = blocks.joinToString("\n") { it.lines.joinToString("\n") }

    private fun dropSections(blocks: List<Block>, excludes: List<String>): Pair<List<Block>, Int> {
        if (excludes.isEmpty()) return blocks to 0
        var removed = 0
        val out = ArrayList<Block>()
        var skipLevel = 0
        for (b in blocks) {
            if (b.fence) {
                if (skipLevel == 0) out.add(b)
                continue
            }
            val kept = ArrayList<String>()
            for (line in b.lines) {
                val m = header.find(line)
                if (m != null) {
                    val level = m.groupValues[1].length
                    if (skipLevel > 0 && level <= skipLevel) skipLevel = 0
                    val title = m.groupValues[2]
                    if (skipLevel == 0 && (title.contains('/') || title.contains('.')) && CmGlob.any(excludes, title)) {
                        skipLevel = level
                        removed++
                        continue
                    }
                }
                if (skipLevel == 0) kept.add(line)
            }
            if (kept.isNotEmpty()) out.add(Block(false, "", kept))
        }
        return out to removed
    }

    private fun collapseBlank(blocks: List<Block>): Pair<List<Block>, Int> {
        var n = 0
        for (b in blocks) {
            if (b.fence) continue
            val out = ArrayList<String>()
            var blanks = 0
            for (line in b.lines) {
                if (line.isBlank()) {
                    blanks++
                    if (blanks >= 2) {
                        n++
                        continue
                    }
                    out.add("")
                } else {
                    blanks = 0
                    out.add(line)
                }
            }
            b.lines.clear()
            b.lines.addAll(out)
        }
        return blocks to n
    }

    private fun dedupe(blocks: List<Block>): Triple<List<Block>, Int, Int> {
        val seenPara = HashSet<String>()
        val seenFence = HashSet<String>()
        var paras = 0
        var fences = 0
        val out = ArrayList<Block>()
        for (b in blocks) {
            if (b.fence) {
                val key = b.lang + "\u0000" + b.lines.joinToString("\n")
                if (b.lines.size > 3 && !seenFence.add(key)) {
                    fences++
                    continue
                }
                out.add(b)
                continue
            }
            val kept = ArrayList<String>()
            val para = ArrayList<String>()
            fun flush() {
                if (para.isEmpty()) return
                val key = para.joinToString(" ") { it.trim() }.replace(Regex("\\s+"), " ")
                val first = para[0]
                if (key.length >= 24 && !header.containsMatchIn(first) && !seenPara.add(key)) {
                    paras++
                } else {
                    kept.addAll(para)
                }
                para.clear()
            }
            for (line in b.lines) {
                if (line.isBlank()) {
                    flush()
                    kept.add(line)
                } else {
                    para.add(line)
                }
            }
            flush()
            out.add(Block(false, "", kept))
        }
        return Triple(out, paras, fences)
    }

    private fun mergeMeta(blocks: List<Block>): Pair<List<Block>, Int> {
        var n = 0
        val seen = HashSet<String>()
        for (b in blocks) {
            if (b.fence) continue
            val out = ArrayList<String>()
            for (line in b.lines) {
                if (header.containsMatchIn(line)) seen.clear()
                if (metaLine.matches(line)) {
                    if (!seen.add(line.trim())) {
                        n++
                        continue
                    }
                }
                out.add(line)
            }
            b.lines.clear()
            b.lines.addAll(out)
        }
        return blocks to n
    }

    private fun aggressiveProse(blocks: List<Block>): Pair<Int, Int> {
        var trailing = 0
        var rules = 0
        for (b in blocks) {
            if (b.fence) continue
            val out = ArrayList<String>()
            for (line in b.lines) {
                if (decor.matches(line)) {
                    rules++
                    continue
                }
                val t = line.trimEnd()
                if (t.length != line.length) trailing++
                out.add(t)
            }
            b.lines.clear()
            b.lines.addAll(out)
        }
        return trailing to rules
    }

    private fun aggressiveCode(blocks: List<Block>): Triple<Int, Int, Int> {
        var blanks = 0
        var comments = 0
        var licenses = 0
        for (b in blocks) {
            if (!b.fence || b.lang !in safeLangs || b.lines.size < 3) continue
            val body = b.lines.subList(1, b.lines.size - 1).toMutableList()
            val raw = body.any { it.contains("\"\"\"") || it.contains('`') || it.contains("R\"") }
            if (body.isNotEmpty() && body[0].trim().startsWith("/*")) {
                var end = 0
                while (end < body.size && !body[end].contains("*/")) end++
                if (end < body.size) {
                    val head = body.subList(0, end + 1).joinToString("\n").lowercase()
                    if (head.contains("copyright") || head.contains("license")) {
                        repeat(end + 1) { body.removeAt(0) }
                        licenses++
                    }
                }
            }
            val out = ArrayList<String>()
            for (line in body) {
                val t = line.trim()
                if (t.isEmpty() && b.lang != "json") {
                    blanks++
                    continue
                }
                if (!raw && b.lang != "json" && b.lang != "html" && b.lang != "xml" && (t.startsWith("//") || (t.startsWith("/*") && t.endsWith("*/")))) {
                    comments++
                    continue
                }
                out.add(line)
            }
            val rebuilt = ArrayList<String>()
            rebuilt.add(b.lines.first())
            rebuilt.addAll(out)
            rebuilt.add(b.lines.last())
            b.lines.clear()
            b.lines.addAll(rebuilt)
        }
        return Triple(blanks, comments, licenses)
    }

    fun run(input: String, aggressive: Boolean, excludes: List<String>): CmTrim {
        val before = CmMeasure.of(input)
        val steps = ArrayList<CmTrimStep>()
        var blocks = split(input.replace("\r\n", "\n"))
        fun size(): Int = join(blocks).length
        var last = size()
        fun note(name: String, count: Int) {
            val now = size()
            steps.add(CmTrimStep(name, count, maxOf(0, last - now)))
            last = now
        }
        val dropped = dropSections(blocks, excludes)
        blocks = dropped.first
        note("Excluded file sections", dropped.second)
        note("Collapsed blank-line runs", collapseBlank(blocks).second)
        val dd = dedupe(blocks)
        blocks = dd.first
        note("Identical paragraphs removed", dd.second)
        note("Identical code blocks removed", dd.third)
        note("Repeated metadata lines merged", mergeMeta(blocks).second)
        if (aggressive) {
            val prose = aggressiveProse(blocks)
            note("Trailing whitespace trimmed", prose.first)
            note("Decorative rule lines removed", prose.second)
            val code = aggressiveCode(blocks)
            note("Blank lines removed in code", code.first)
            note("Whole-line comments removed in code (heuristic, not AST)", code.second)
            note("License headers removed", code.third)
        }
        val text = join(blocks)
        val after = CmMeasure.of(text)
        if (after.chars >= before.chars) return CmTrim(input, before, before, steps, aggressive)
        return CmTrim(text, before, after, steps, aggressive)
    }
}
