package com.untilyflow.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class CmHit(val line: String, val path: String?, val size: Long)

private fun copyPlain(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    toast(ctx, tr("Copied"))
}

private fun when_(ms: Long): String =
    if (ms <= 0) "-" else java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT, Lang.locale()).format(java.util.Date(ms))

@Composable
private fun Kv(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.weight(0.42f), fontSize = 12.sp, color = NxDim)
        Text(value, Modifier.weight(0.58f), fontFamily = FontPrefs.mono.family, fontSize = 12.sp)
    }
}

@Composable
private fun Note(text: String, danger: Boolean = false) {
    Text(text, Modifier.padding(top = 6.dp), fontSize = 12.sp, color = if (danger) NxDanger else NxDim)
}

@Composable
private fun StatTile(value: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    NxCard(modifier) {
        NxIconBox(icon, box = 36.dp)
        Text(value, Modifier.padding(top = 10.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, fontSize = 12.sp, color = NxDim, maxLines = 1)
    }
}

@Composable
private fun Flag(label: String, on: Boolean, onTap: () -> Unit) {
    NxButton(if (on) tr("{0}: On", label) else tr("{0}: Off", label), tone = if (on) Tone.Accent else Tone.Quiet, wide = true, onTap = onTap)
}

private fun stateText(state: String): String = when (state) {
    "ready" -> tr("Ready")
    "indexing" -> tr("Indexing")
    "interrupted" -> tr("Interrupted")
    "empty" -> tr("Not indexed")
    else -> state
}

@Composable
fun CodeMindScreen() {
    val ctx = LocalContext.current
    var ready by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    val busy = CodeMind.running.isNotEmpty()

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { CodeMind.attach(ctx) }
        ready = true
    }
    LaunchedEffect(busy, McpServer.running) {
        while (busy || McpServer.running) {
            delay(600)
            tick++
        }
    }

    Column(Modifier.fillMaxSize()) {
        NxFlow(Modifier.fillMaxWidth().padding(start = 16.dp, top = 10.dp, end = 16.dp)) {
            val names = listOf(tr("Dashboard"), tr("Projects"), tr("Search"), tr("Optimizer"), tr("MCP Server"), tr("Settings"))
            names.forEachIndexed { i, n -> NxChip(n, hot = tab == i, onTap = { tab = i }) }
        }
        if (!ready) return@Column
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
            when (tab) {
                0 -> DashboardTab(ctx, tick) { tab = it }
                1 -> ProjectsTab(ctx, tick)
                2 -> SearchTab(ctx)
                3 -> OptimizerTab(ctx)
                4 -> ServerTab(ctx, tick)
                else -> SettingsTab(ctx)
            }
        }
    }
}

@Composable
private fun viewOf(rec: CmProjectRec?, tick: Int): CmView? {
    val v by produceState<CmView?>(null, rec?.id, CodeMind.version, tick / 3) {
        value = if (rec == null) null else withContext(Dispatchers.IO) { try { CodeMind.snapshot(rec) } catch (_: Exception) { null } }
    }
    return v
}

@Composable
private fun ProgressBlock(rec: CmProjectRec, tick: Int) {
    val p = CodeMind.running[rec.id] ?: return
    val frac = if (p.total > 0) p.done.toFloat() / p.total else 0f
    if (tick >= 0) {
        NxMeter(frac, Modifier.fillMaxWidth().padding(top = 10.dp))
        Text(
            (if (p.phase == "scan") tr("Scanning folders") else "${p.done}/${p.total}") + "  " + p.detail,
            Modifier.padding(top = 6.dp), fontFamily = FontPrefs.mono.family, fontSize = 11.sp, color = NxDim, maxLines = 2,
        )
        Text(tr("cache hits {0}, analyzed {1}, skipped {2}, errors {3}", p.hits, p.misses, p.skipped, p.errors), Modifier.padding(top = 2.dp), fontSize = 11.sp, color = NxDim)
    }
}

@Composable
private fun DashboardTab(ctx: Context, tick: Int, go: (Int) -> Unit) {
    val scope = rememberCoroutineScope()
    val rec = CodeMind.active()
    val view = viewOf(rec, tick)
    NxCard(Modifier.fillMaxWidth(), hot = McpServer.running) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("MCP server"), Modifier.weight(1f), fontWeight = FontWeight.Bold)
            NxChip(if (McpServer.running) tr("Running") else tr("Stopped"), hot = McpServer.running)
        }
        Text(if (McpServer.running) McpServer.address() else tr("Not running"), Modifier.padding(top = 6.dp), fontFamily = FontPrefs.mono.family, fontSize = 12.sp)
        if (McpServer.running) Note(tr("requests {0}, refused {1}", McpServer.requests, McpServer.rejected))
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (McpServer.running) NxButton(tr("Stop"), tone = Tone.Danger, compact = true) { McpServer.stop() }
            else NxButton(tr("Start"), tone = Tone.Accent, compact = true) { scope.launch(Dispatchers.IO) { McpServer.start(ctx, CmPrefs.port(ctx)) } }
            NxButton(tr("Details"), compact = true) { go(4) }
        }
        McpServer.error?.let { Note(it, true) }
    }
    if (view != null) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(view.stats.files.toString(), tr("Files indexed"), NxIcon.File, Modifier.weight(1f))
            StatTile(view.stats.symbols.toString(), tr("Symbols"), NxIcon.Bolt, Modifier.weight(1f))
            StatTile(humanSize(view.stats.storeBytes), tr("Index size"), NxIcon.Database, Modifier.weight(1f))
        }
    }
    NxSection(tr("Active project"))
    if (rec == null) {
        NxCard(Modifier.fillMaxWidth()) {
            Text(tr("No project yet"), fontWeight = FontWeight.Bold)
            Note(tr("Add a folder in Projects, then index it."))
            NxButton(tr("Add project"), Modifier.padding(top = 10.dp), icon = NxIcon.FolderPlus, tone = Tone.Accent, compact = true) { go(1) }
        }
    } else {
        NxCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NxIconBox(NxIcon.Database, box = 36.dp)
                Text(rec.name, Modifier.weight(1f).padding(horizontal = 10.dp), fontWeight = FontWeight.Bold)
                NxChip(stateText(view?.project?.state ?: "..."), hot = view?.project?.state == "ready")
            }
            Text(CodeMind.placeOf(rec) + "  " + rec.root, Modifier.padding(top = 4.dp), fontFamily = FontPrefs.mono.family, fontSize = 11.sp, color = NxDim)
            ProgressBlock(rec, tick)
            if (view != null) {
                val m = view.meta
                Column(Modifier.padding(top = 10.dp)) {
                    Kv(tr("Last run cache"), tr("{0} hits, {1} misses", m["run.hits"] ?: "-", m["run.misses"] ?: "-"))
                    Kv(tr("All runs cache"), tr("{0} hits, {1} misses", m["total.hits"] ?: "0", m["total.misses"] ?: "0"))
                    Kv(tr("Last indexing"), when_(m["run.at"]?.toLongOrNull() ?: 0L) + "  " + (m["run.millis"]?.let { "$it ms" } ?: ""))
                    Kv(tr("Context reduction"), CodeMind.lastReduction.ifEmpty { tr("not measured yet") })
                }
                m["warn"]?.takeIf { it.isNotEmpty() }?.let { Note(it, true) }
                if (view.project.state == "interrupted") Note(tr("The last run was interrupted. Index again to continue from the cache."), true)
            }
        }
    }
    NxSection(tr("Agent briefs"))
    NxCard(Modifier.fillMaxWidth()) {
        val recent = CodeMind.briefs.takeLast(8).reversed()
        if (recent.isEmpty()) Note(tr("Nothing yet")) else {
            recent.forEach {
                val what = when (it.outcome) {
                    "sent" -> tr("{0} chars, about {1} tokens (estimate)", it.chars, it.tokens)
                    "small" -> tr("No brief, {0} files is below the minimum", it.files)
                    else -> tr("No brief, nothing indexed yet")
                }
                Text(when_(it.at) + "  " + it.project + "  " + what, Modifier.padding(vertical = 2.dp), fontFamily = FontPrefs.mono.family, fontSize = 11.sp, maxLines = 2)
            }
            Note(tr("Size of the text added to the agent prompt on each run. Tokens are chars/4, not what the provider counted."))
        }
    }
    NxSection(tr("Last activity"))
    NxCard(Modifier.fillMaxWidth()) {
        if (CodeMind.activity.isEmpty()) Note(tr("Nothing yet")) else CodeMind.activity.take(8).forEach {
            Text(it, Modifier.padding(vertical = 2.dp), fontFamily = FontPrefs.mono.family, fontSize = 11.sp, maxLines = 3)
        }
    }
}

@Composable
private fun ProjectsTab(ctx: Context, tick: Int) {
    val scope = rememberCoroutineScope()
    var path by remember { mutableStateOf("/storage/emulated/0") }
    var place by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf<CmProjectRec?>(null) }
    NxSection(tr("Add project"))
    NxCard(Modifier.fillMaxWidth()) {
        val names = ArrayList<String>()
        names.add("Internal")
        names.add("NoxoraStorage")
        names.add("Root")
        Hub.vps?.let { names.add(it.profile.name) }
        NxFlow {
            names.forEachIndexed { i, n -> NxChip(n, hot = place == i, onTap = { place = i }) }
        }
        Spacer8()
        NxField(path, { path = it }, tr("Folder path"), mono = true)
        NxButton(tr("Add and index"), icon = NxIcon.FolderPlus, tone = Tone.Accent, wide = true) {
            val chosen = place
            val folder = path
            scope.launch(Dispatchers.IO) {
                try {
                    val fs: FsBackend = when (chosen) {
                        0 -> InternalFs
                        1 -> NoxoraFs
                        2 -> RootFs
                        else -> VpsFs(Hub.vps ?: throw Exception(tr("Terminal is not connected")))
                    }
                    val rec = CodeMind.add(ctx, fs, folder)
                    CodeMind.select(ctx, rec.id)
                    CodeMind.startIndex(rec)
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { toast(ctx, e.message ?: e.toString()) }
                }
            }
        }
        Note(tr("Only folders you add here are read. Source files are never changed or uploaded."))
    }
    NxSection(tr("Projects"))
    if (CodeMind.projects.isEmpty()) NxCard(Modifier.fillMaxWidth()) { Note(tr("No projects yet")) }
    for (rec in CodeMind.projects.toList()) {
        val view = viewOf(rec, tick)
        NxCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), hot = rec.id == CodeMind.activeId) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NxIconBox(NxIcon.Folder, box = 36.dp)
                Text(rec.name, Modifier.weight(1f).padding(horizontal = 10.dp), fontWeight = FontWeight.Bold)
                NxChip(stateText(view?.project?.state ?: "..."), hot = view?.project?.state == "ready")
            }
            Text(CodeMind.placeOf(rec) + "  " + rec.root, Modifier.padding(top = 4.dp), fontFamily = FontPrefs.mono.family, fontSize = 11.sp, color = NxDim)
            if (view != null) Note(tr("{0} files, {1} symbols, {2}", view.stats.files, view.stats.symbols, humanSize(view.stats.storeBytes)))
            ProgressBlock(rec, tick)
            NxFlow(Modifier.padding(top = 10.dp)) {
                if (rec.id != CodeMind.activeId) NxButton(tr("Use"), compact = true) { CodeMind.select(ctx, rec.id) }
                if (CodeMind.running.containsKey(rec.id)) {
                    NxButton(tr("Stop"), tone = Tone.Danger, compact = true) {
                        TaskBoard.runs.firstOrNull { it.kind == TaskKind.Index && it.title == rec.name && it.state == TaskState.Running }?.stop = true
                    }
                } else {
                    NxButton(tr("Update"), icon = NxIcon.Refresh, tone = Tone.Accent, compact = true) {
                        scope.launch(Dispatchers.IO) { try { CodeMind.startIndex(rec) } catch (e: Exception) { withContext(Dispatchers.Main) { toast(ctx, e.message ?: e.toString()) } } }
                    }
                    NxButton(tr("Rebuild"), compact = true) {
                        scope.launch(Dispatchers.IO) { try { CodeMind.startIndex(rec, force = true) } catch (e: Exception) { withContext(Dispatchers.Main) { toast(ctx, e.message ?: e.toString()) } } }
                    }
                    NxButton(tr("Clear"), compact = true) {
                        scope.launch(Dispatchers.IO) { try { CodeMind.clear(rec) } catch (e: Exception) { withContext(Dispatchers.Main) { toast(ctx, e.message ?: e.toString()) } } }
                    }
                    NxButton(tr("Delete"), icon = NxIcon.Trash, tone = Tone.Danger, compact = true) { confirm = rec }
                }
            }
        }
    }
    confirm?.let { rec ->
        NxDialog(tr("Delete index"), { confirm = null }, tr("Delete"), {
            confirm = null
            scope.launch(Dispatchers.IO) { CodeMind.remove(rec) }
        }) {
            Text(tr("The index of {0} is removed from this phone. The source files stay untouched.", rec.name), fontSize = 13.sp)
        }
    }
}

@Composable
private fun Spacer8() {
    androidx.compose.foundation.layout.Spacer(Modifier.padding(top = 8.dp))
}

@Composable
private fun SearchTab(ctx: Context) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var mode by remember { mutableIntStateOf(0) }
    var exact by remember { mutableStateOf(false) }
    val hits = remember { mutableStateListOf<CmHit>() }
    var more by remember { mutableStateOf(false) }
    var offset by remember { mutableIntStateOf(0) }
    var took by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }

    fun run(from: Int) {
        val q = query.trim()
        if (q.isEmpty() || working) return
        working = true
        scope.launch(Dispatchers.IO) {
            val started = System.currentTimeMillis()
            try {
                val c = CodeMind.open(null)
                val rows = ArrayList<CmHit>()
                var next = false
                when (mode) {
                    0 -> {
                        val page = CodeQuery.text(c.index, c.source, c.project.root, q, exact, false, null, 30, from)
                        for (h in page.items) rows.add(CmHit(h.path + ":" + h.line + "  " + h.text, h.path, c.index.file(h.path)?.size ?: 0L))
                        next = page.more
                    }
                    1 -> {
                        val page = CodeQuery.symbols(c.index, q, null, 30, from)
                        for (s in page.items) rows.add(CmHit(s.kind + " " + s.name + "  " + s.file + ":" + s.line, s.file, c.index.file(s.file)?.size ?: 0L))
                        next = page.more
                    }
                    2 -> {
                        val page = CodeQuery.paths(c.index, q, 30, from)
                        for (p in page.items) rows.add(CmHit(p, p, c.index.file(p)?.size ?: 0L))
                        next = page.more
                    }
                    else -> {
                        val path = q.trim('/')
                        if (c.index.file(path) == null) throw CmToolError(tr("File not in the index"))
                        val d = CodeQuery.dependencies(c.index, path)
                        rows.add(CmHit(tr("Imports") + ": " + d.imports.joinToString(", ").ifEmpty { "-" }, null, 0L))
                        for (r in d.resolved) rows.add(CmHit("-> $r", r, c.index.file(r)?.size ?: 0L))
                        for (r in d.importedBy) rows.add(CmHit("<- $r", r, c.index.file(r)?.size ?: 0L))
                    }
                }
                val ms = System.currentTimeMillis() - started
                withContext(Dispatchers.Main) {
                    if (from == 0) hits.clear()
                    hits.addAll(rows)
                    more = next
                    offset = from + rows.size
                    took = tr("{0} ms", ms)
                    message = if (hits.isEmpty()) tr("No results") else ""
                    working = false
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    message = e.message ?: e.toString()
                    working = false
                }
            }
        }
    }

    NxSection(tr("Code search"))
    NxFlow {
        listOf(tr("Text"), tr("Symbols"), tr("Files"), tr("Imports")).forEachIndexed { i, n ->
            NxChip(n, hot = mode == i, onTap = { mode = i })
        }
    }
    Spacer8()
    NxField(query, { query = it }, when (mode) { 3 -> tr("File path"); else -> tr("Search") }, mono = true)
    if (mode == 0) Flag(tr("Match case"), exact) { exact = !exact }
    NxButton(if (working) tr("Searching…") else tr("Search"), Modifier.padding(top = 8.dp), icon = NxIcon.Search, tone = Tone.Accent, wide = true) { run(0) }
    if (took.isNotEmpty()) Note(took)
    if (message.isNotEmpty()) Note(message, true)
    Spacer8()
    val rec = CodeMind.active()
    for (h in hits) {
        NxCard(Modifier.fillMaxWidth().padding(bottom = 6.dp), onTap = h.path?.let { p ->
            {
                val fs = rec?.let { CodeMind.fsFor(it) }
                if (rec != null && fs != null) FileOpen.start(ctx, fs, CodeIndexer.join(rec.root, p), h.size, true)
                else toast(ctx, tr("Storage of this project is not connected"))
            }
        }) {
            Text(h.line, fontFamily = FontPrefs.mono.family, fontSize = 11.sp, maxLines = 4)
        }
    }
    if (more) NxButton(tr("More"), Modifier.padding(top = 6.dp), wide = true) { run(offset) }
}

@Composable
private fun OptimizerTab(ctx: Context) {
    val scope = rememberCoroutineScope()
    var task by remember { mutableStateOf("") }
    var pasted by remember { mutableStateOf("") }
    var budget by remember { mutableStateOf("8000") }
    var exclude by remember { mutableStateOf("") }
    var aggressive by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var problem by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }

    NxSection(tr("Context optimizer"))
    NxCard(Modifier.fillMaxWidth()) {
        NxField(task, { task = it }, tr("Task for the AI"), lines = 3)
        NxField(pasted, { pasted = it }, tr("Or paste text to optimize"), mono = true, lines = 4)
        NxField(budget, { budget = it.filter(Char::isDigit).take(6) }, tr("Budget in characters"), mono = true)
        NxField(exclude, { exclude = it }, tr("Exclude files or patterns, comma separated"), mono = true)
        Flag(tr("Aggressive mode"), aggressive) { aggressive = !aggressive }
        Note(if (aggressive) tr("Also trims whitespace and whole-line comments inside code blocks. Heuristic, not a parser.") else tr("Only removes identical blocks, blank runs and repeated metadata."))
        NxButton(if (working) tr("Working…") else tr("Optimize"), Modifier.padding(top = 10.dp), icon = NxIcon.Bolt, tone = Tone.Accent, wide = true) {
            if (working) return@NxButton
            if (task.isBlank() && pasted.isBlank()) {
                problem = tr("Write a task or paste text")
                return@NxButton
            }
            working = true
            problem = ""
            val skip = exclude.split(',', '\n').map { it.trim() }.filter { it.isNotEmpty() }
            val limit = (budget.toIntOrNull() ?: 8000).coerceIn(500, 200000)
            val text = pasted
            val job = task
            val hard = aggressive
            scope.launch(Dispatchers.IO) {
                try {
                    val source = if (text.isNotBlank()) text else {
                        val c = CodeMind.open(null)
                        ContextPack.build(c.index, c.source, c.project.root, c.project.name, job, limit, skip).text
                    }
                    val trim = ContextTrim.run(source, hard, skip)
                    withContext(Dispatchers.Main) {
                        report = trim.report()
                        output = trim.text
                        CodeMind.lastReduction = String.format(java.util.Locale.US, "%.1f%% (%d -> %d chars)", trim.percent, trim.before.chars, trim.after.chars)
                        working = false
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        problem = e.message ?: e.toString()
                        working = false
                    }
                }
            }
        }
        if (problem.isNotEmpty()) Note(problem, true)
    }
    if (output.isNotEmpty()) {
        NxSection(tr("Result"))
        NxCard(Modifier.fillMaxWidth()) {
            Text(report, fontFamily = FontPrefs.mono.family, fontSize = 11.sp)
            NxFlow(Modifier.padding(top = 10.dp)) {
                NxButton(tr("Copy"), icon = NxIcon.Copy, compact = true) { copyPlain(ctx, "context", output) }
                NxButton(tr("Save as Markdown"), icon = NxIcon.File, compact = true) {
                    scope.launch(Dispatchers.IO) {
                        val f = try { CodeMind.exportContext(output) } catch (e: Exception) { null }
                        withContext(Dispatchers.Main) { toast(ctx, if (f != null) f.path else tr("Could not save")) }
                    }
                }
            }
        }
        NxCard(Modifier.fillMaxWidth().padding(top = 10.dp)) {
            Text(output.take(6000) + if (output.length > 6000) "\n…" else "", fontFamily = FontPrefs.mono.family, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ServerTab(ctx: Context, tick: Int) {
    val scope = rememberCoroutineScope()
    var port by remember { mutableStateOf(CmPrefs.port(ctx).toString()) }
    var show by remember { mutableStateOf(false) }
    var remote by remember { mutableStateOf("") }
    var write by remember { mutableStateOf(CmPrefs.mcpWrite(ctx)) }
    val token = remember(tick / 1000000, McpServer.running) { CmPrefs.token(ctx) }
    var shownToken by remember { mutableStateOf(token) }
    val vps = Hub.vps

    NxSection(tr("MCP server"))
    NxCard(Modifier.fillMaxWidth(), hot = McpServer.running) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Status"), Modifier.weight(1f), fontWeight = FontWeight.Bold)
            NxChip(if (McpServer.running) tr("Running") else tr("Stopped"), hot = McpServer.running)
        }
        Kv(tr("Transport"), "Streamable HTTP (MCP 2025-06-18, 2025-03-26, 2024-11-05)")
        Kv(tr("Address"), if (McpServer.running) McpServer.address() else tr("Not running"))
        Kv(tr("Access"), tr("This phone only (127.0.0.1)"))
        Kv(tr("Requests"), tr("{0} served, {1} refused", McpServer.requests, McpServer.rejected))
        NxField(port, { port = it.filter(Char::isDigit).take(5) }, tr("Port, 0 picks a free one"), mono = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (McpServer.running) {
                NxButton(tr("Stop"), tone = Tone.Danger, compact = true) { McpServer.stop() }
            } else {
                NxButton(tr("Start"), tone = Tone.Accent, compact = true) {
                    val n = port.toIntOrNull()
                    if (n == null || n !in 0..65535 || (n in 1..1023)) {
                        toast(ctx, tr("Port must be 0 or 1024 to 65535"))
                    } else {
                        CmPrefs.setPort(ctx, n)
                        scope.launch(Dispatchers.IO) { McpServer.start(ctx, n) }
                    }
                }
            }
            NxButton(tr("Test connection"), compact = true) { McpServer.selfTest(ctx) }
        }
        McpServer.error?.let { Note(it, true) }
        if (McpServer.testResult.isNotEmpty()) Note(McpServer.testResult)
        Note(tr("Android can stop the app in the background. Keep a task running or the app open while a client uses the server."))
    }

    NxSection(tr("Authentication"))
    NxCard(Modifier.fillMaxWidth()) {
        Text(if (show) shownToken else "•".repeat(24), fontFamily = FontPrefs.mono.family, fontSize = 12.sp)
        NxFlow(Modifier.padding(top = 10.dp)) {
            NxButton(if (show) tr("Hide") else tr("Show"), compact = true) { show = !show }
            NxButton(tr("Copy"), icon = NxIcon.Copy, compact = true) { copyPlain(ctx, "token", shownToken) }
            NxButton(tr("New token"), compact = true) {
                shownToken = CmPrefs.resetToken(ctx)
                toast(ctx, tr("Old token no longer works"))
            }
        }
        Note(tr("Every request needs this token. Other apps on the phone can reach 127.0.0.1, so it is always required."))
        Spacer8()
        Flag(tr("Clients may update the index"), write) {
            write = !write
            CmPrefs.setMcpWrite(ctx, write)
        }
    }

    NxSection(tr("Connect a client"))
    NxCard(Modifier.fillMaxWidth()) {
        val url = if (McpServer.running) McpServer.address() else "http://127.0.0.1:${port.ifEmpty { "8765" }}/mcp"
        Text(tr("Use these settings in an MCP client that supports Streamable HTTP:"), fontSize = 12.sp, color = NxDim)
        Text("URL: $url\nAuthorization: Bearer <token>", Modifier.padding(top = 6.dp), fontFamily = FontPrefs.mono.family, fontSize = 11.sp)
        val cli = "claude mcp add --transport http codemind $url --header \"Authorization: Bearer $shownToken\""
        NxButton(tr("Copy example command"), Modifier.padding(top = 10.dp), icon = NxIcon.Copy, compact = true) { copyPlain(ctx, "mcp", cli) }
        Note(tr("The example follows Claude Code's documented syntax. CodeMind has only been tested with its own built-in test, not with external clients."))
        Note(tr("Without a client on this phone, use the AI agent in UntilyFlow, or export context from Optimizer."))
    }

    NxSection(tr("Use from a VPS over SSH"))
    NxCard(Modifier.fillMaxWidth()) {
        if (vps == null) {
            Note(tr("Connect a VPS in Terminal first."))
        } else {
            Text(vps.profile.name, fontWeight = FontWeight.Bold)
            if (McpServer.exposed > 0) {
                Text("http://127.0.0.1:${McpServer.exposed}/mcp", Modifier.padding(top = 6.dp), fontFamily = FontPrefs.mono.family, fontSize = 12.sp)
                Note(tr("Programs on the VPS can reach the server at this address. It is bound to the VPS loopback only."))
                NxButton(tr("Stop forwarding"), Modifier.padding(top = 10.dp), tone = Tone.Danger, compact = true) {
                    val n = McpServer.exposed
                    scope.launch(Dispatchers.IO) {
                        vps.unforwardLoopback(n)
                        McpServer.exposed = 0
                    }
                }
            } else {
                NxField(remote, { remote = it.filter(Char::isDigit).take(5) }, tr("Port on the VPS"), mono = true)
                NxButton(tr("Forward to VPS"), tone = Tone.Accent, wide = true) {
                    if (!McpServer.running) {
                        toast(ctx, tr("Start the server first"))
                        return@NxButton
                    }
                    val n = remote.toIntOrNull() ?: McpServer.port
                    if (n !in 1024..65535) {
                        toast(ctx, tr("Port must be 1024 to 65535"))
                        return@NxButton
                    }
                    scope.launch(Dispatchers.IO) {
                        try {
                            vps.forwardLoopback(n, McpServer.port)
                            McpServer.exposed = n
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) { toast(ctx, e.message ?: e.toString()) }
                        }
                    }
                }
                Note(tr("Uses an SSH remote forward. Closing the SSH connection ends it. The VPS server must allow remote forwarding."))
            }
        }
    }

    NxSection(tr("Connection log"))
    NxCard(Modifier.fillMaxWidth()) {
        if (McpServer.log.isEmpty()) Note(tr("Nothing yet")) else McpServer.log.take(25).forEach {
            Text(it, Modifier.padding(vertical = 2.dp), fontFamily = FontPrefs.mono.family, fontSize = 11.sp, maxLines = 2)
        }
    }
}

@Composable
private fun SettingsTab(ctx: Context) {
    var maxKb by remember { mutableStateOf(CmPrefs.maxKb(ctx).toString()) }
    var maxFiles by remember { mutableStateOf(CmPrefs.maxFiles(ctx).toString()) }
    var excludes by remember { mutableStateOf(CmPrefs.excludes(ctx)) }
    var cap by remember { mutableStateOf(CmPrefs.capMb(ctx).toString()) }
    var keep by remember { mutableStateOf(CmPrefs.keepDays(ctx).toString()) }
    var agents by remember { mutableStateOf(CmPrefs.agents(ctx)) }
    var auto by remember { mutableStateOf(CmPrefs.autoIndex(ctx)) }
    var minFiles by remember { mutableStateOf(CmPrefs.minFiles(ctx).toString()) }
    var wipe by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    NxSection(tr("Settings"))
    NxCard(Modifier.fillMaxWidth()) {
        Flag(tr("Use in AI agents"), agents) {
            agents = !agents
            CmPrefs.setAgents(ctx, agents)
        }
        Note(tr("Adds the nx cm tools and a short project brief to the terminal and SSH AI."))
        Spacer8()
        Flag(tr("Index projects automatically"), auto) {
            auto = !auto
            CmPrefs.setAutoIndex(ctx, auto)
        }
        Note(tr("Finds the project folder from the agent's folder, indexes it once in the background and refreshes it before runs. Never indexes the storage root. On a VPS only while connected."))
        Spacer8()
        NxField(minFiles, { minFiles = it.filter(Char::isDigit).take(4) }, tr("Smallest project that gets a brief, files"), mono = true)
        NxField(maxKb, { maxKb = it.filter(Char::isDigit).take(4) }, tr("Largest file to index, KB"), mono = true)
        NxField(maxFiles, { maxFiles = it.filter(Char::isDigit).take(6) }, tr("Most files per project"), mono = true)
        NxField(excludes, { excludes = it }, tr("Excluded names and patterns"), mono = true, lines = 2)
        NxField(cap, { cap = it.filter(Char::isDigit).take(4) }, tr("Index size warning, MB"), mono = true)
        NxField(keep, { keep = it.filter(Char::isDigit).take(4) }, tr("Clear unused indexes after days, 0 keeps them"), mono = true)
        NxButton(tr("Save"), icon = NxIcon.Refresh, tone = Tone.Accent, wide = true) {
            CmPrefs.setMaxKb(ctx, maxKb.toIntOrNull() ?: 512)
            CmPrefs.setMaxFiles(ctx, maxFiles.toIntOrNull() ?: 20000)
            CmPrefs.setExcludes(ctx, excludes)
            CmPrefs.setCapMb(ctx, cap.toIntOrNull() ?: 200)
            CmPrefs.setKeepDays(ctx, keep.toIntOrNull() ?: 0)
            CmPrefs.setMinFiles(ctx, minFiles.toIntOrNull() ?: CodeAuto.MIN_FILES)
            toast(ctx, tr("Saved"))
        }
    }
    NxSection(tr("Privacy"))
    NxCard(Modifier.fillMaxWidth()) {
        Note(tr("The index stays in this app's private storage. It holds file names, symbols, short summaries and word counts, not full source. Nothing is uploaded."))
        NxButton(tr("Delete all CodeMind data"), Modifier.padding(top = 10.dp), icon = NxIcon.Trash, tone = Tone.Danger, wide = true) { wipe = true }
    }
    if (wipe) {
        NxDialog(tr("Delete all CodeMind data"), { wipe = false }, tr("Delete"), {
            wipe = false
            scope.launch(Dispatchers.IO) {
                try {
                    CodeMind.wipeAll(ctx)
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { toast(ctx, e.message ?: e.toString()) }
                }
            }
        }) { Text(tr("All project indexes and the access token are removed. Source files stay untouched."), fontSize = 13.sp) }
    }
}
