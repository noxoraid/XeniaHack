package com.untilyflow.app

class CmFile(
    val path: String,
    val lang: String,
    val size: Long,
    val mtime: Long,
    val hash: String,
    val lines: Int,
    val summary: String,
    val indexedAt: Long,
)

class CmSymbol(val file: String, val name: String, val kind: String, val line: Int)

class CmTermHit(val file: String, val term: String, val count: Int)

class CmStats(
    val files: Int,
    val symbols: Int,
    val imports: Int,
    val terms: Int,
    val sourceBytes: Long,
    val storeBytes: Long,
    val byLang: Map<String, Int>,
)

class CmEntry(val name: String, val dir: Boolean, val size: Long)

interface CodeSource {
    fun list(dir: String): List<CmEntry>

    fun read(path: String, max: Int): ByteArray

    fun stamp(path: String): Long

    fun exists(path: String): Boolean
}

interface CodeIndex {
    fun fileCount(): Int

    fun file(path: String): CmFile?

    fun files(prefix: String, offset: Int, limit: Int): List<CmFile>

    fun paths(): List<String>

    fun symbolsOf(path: String): List<CmSymbol>

    fun findSymbols(part: String, limit: Int): List<CmSymbol>

    fun importsOf(path: String): List<String>

    fun allImports(): List<Pair<String, String>>

    fun termHits(terms: List<String>): List<CmTermHit>

    fun docFreq(terms: List<String>): Map<String, Int>

    fun stats(): CmStats

    fun meta(key: String): String?
}

interface CodeSink : CodeIndex {
    fun begin()

    fun commit()

    fun put(file: CmFile, symbols: List<CmSym>, imports: List<String>, terms: List<Pair<String, Int>>)

    fun touch(path: String, mtime: Long)

    fun remove(path: String)

    fun setMeta(key: String, value: String)

    fun wipe()
}

class CmStopped : Exception()

class CmToolError(message: String) : Exception(message)
