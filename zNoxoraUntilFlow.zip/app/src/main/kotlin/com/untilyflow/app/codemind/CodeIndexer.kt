package com.untilyflow.app

class CmConfig(
    val maxFileBytes: Int = 524288,
    val maxFiles: Int = 20000,
    val excludes: List<String> = DEFAULT_EXCLUDES,
) {
    companion object {
        val DEFAULT_EXCLUDES = listOf(
            ".git", "node_modules", "build", ".gradle", ".idea", "dist", "out", "__pycache__", "venv", ".venv",
            "target", ".next", ".cache", ".dart_tool", "Pods",
        )
    }
}

class CmProgress {
    @Volatile var total = 0
    @Volatile var done = 0
    @Volatile var skipped = 0
    @Volatile var hits = 0
    @Volatile var misses = 0
    @Volatile var errors = 0
    @Volatile var removed = 0
    @Volatile var bytes = 0L
    @Volatile var detail = ""
    @Volatile var phase = ""
    val problems: MutableList<String> = java.util.Collections.synchronizedList(ArrayList())

    fun problem(text: String) {
        if (problems.size < 30) problems.add(text)
    }
}

class CmRun(
    val millis: Long,
    val scanned: Int,
    val indexed: Int,
    val skipped: Int,
    val hits: Int,
    val misses: Int,
    val errors: Int,
    val removed: Int,
    val bytes: Long,
)

object CodeSummary {
    fun of(lang: String, lines: Int, symbols: List<CmSym>, imports: List<String>): String {
        val main = symbols.filter { it.kind != "method" }
        val shown = main.take(6).joinToString(", ") { it.kind + " " + it.name }
        val rest = symbols.size - minOf(main.size, 6)
        val out = StringBuilder("$lang, $lines lines")
        if (shown.isNotEmpty()) out.append(" | defines: ").append(shown)
        if (rest > 0) out.append(" (+").append(rest).append(" more)")
        if (imports.isNotEmpty()) out.append(" | imports: ").append(imports.size)
        return out.toString()
    }
}

object CodeIndexer {
    private const val BATCH = 200
    private const val MAX_DEPTH = 40

    fun join(root: String, rel: String): String = if (rel.isEmpty()) root else root.trimEnd('/') + "/" + rel

    fun looksBinary(data: ByteArray, len: Int): Boolean {
        val n = minOf(len, 4096)
        for (i in 0 until n) if (data[i].toInt() == 0) return true
        return false
    }

    fun run(
        source: CodeSource,
        sink: CodeSink,
        root: String,
        config: CmConfig,
        progress: CmProgress,
        stopped: () -> Boolean,
        only: List<String>? = null,
        force: Boolean = false,
        clock: () -> Long = { System.currentTimeMillis() },
    ): CmRun {
        val started = clock()
        sink.setMeta("state", "indexing")
        sink.setMeta("run.started", started.toString())
        progress.phase = "scan"
        val files = ArrayList<Pair<String, CmEntry>>()
        if (only != null) {
            for (rel in only.map { it.trim().trim('/') }.filter { it.isNotEmpty() }.distinct()) files.add(rel to CmEntry(rel.substringAfterLast('/'), false, -1L))
        } else {
            walk(source, root, config, progress, stopped, files, sink)
        }
        progress.total = files.size
        progress.phase = "index"
        val seen = HashSet<String>()
        var indexed = 0
        sink.begin()
        try {
            for ((rel, entry) in files) {
                if (stopped()) throw CmStopped()
                seen.add(rel)
                progress.detail = rel
                try {
                    if (process(source, sink, root, rel, entry, config, progress, force, clock)) indexed++
                } catch (e: CmStopped) {
                    throw e
                } catch (e: Exception) {
                    progress.errors++
                    progress.problem(rel + ": " + (e.message?.ifBlank { null } ?: e.toString()))
                }
                progress.done++
                if (progress.done % BATCH == 0) {
                    sink.commit()
                    sink.begin()
                }
            }
        } catch (e: CmStopped) {
            sink.commit()
            sink.setMeta("state", "interrupted")
            throw e
        }
        sink.commit()
        if (only == null) {
            progress.phase = "prune"
            sink.begin()
            for (p in sink.paths()) {
                if (p !in seen) {
                    sink.remove(p)
                    progress.removed++
                }
            }
            sink.commit()
        }
        val millis = clock() - started
        val run = CmRun(millis, files.size, indexed, progress.skipped, progress.hits, progress.misses, progress.errors, progress.removed, progress.bytes)
        sink.setMeta("state", "ready")
        sink.setMeta("run.at", clock().toString())
        sink.setMeta("run.millis", millis.toString())
        sink.setMeta("run.scanned", files.size.toString())
        sink.setMeta("run.indexed", indexed.toString())
        sink.setMeta("run.skipped", progress.skipped.toString())
        sink.setMeta("run.hits", progress.hits.toString())
        sink.setMeta("run.misses", progress.misses.toString())
        sink.setMeta("run.errors", progress.errors.toString())
        sink.setMeta("run.removed", progress.removed.toString())
        sink.setMeta("run.full", if (only == null) "1" else "0")
        val totalHits = (sink.meta("total.hits")?.toLongOrNull() ?: 0L) + progress.hits
        val totalMisses = (sink.meta("total.misses")?.toLongOrNull() ?: 0L) + progress.misses
        sink.setMeta("total.hits", totalHits.toString())
        sink.setMeta("total.misses", totalMisses.toString())
        progress.phase = "done"
        return run
    }

    private fun walk(
        source: CodeSource,
        root: String,
        config: CmConfig,
        progress: CmProgress,
        stopped: () -> Boolean,
        out: MutableList<Pair<String, CmEntry>>,
        sink: CodeSink,
    ) {
        val stack = ArrayList<Pair<String, Int>>()
        stack.add("" to 0)
        while (stack.isNotEmpty()) {
            if (stopped()) {
                sink.setMeta("state", "interrupted")
                throw CmStopped()
            }
            val (dir, depth) = stack.removeAt(stack.size - 1)
            progress.detail = dir.ifEmpty { "/" }
            val entries = try {
                source.list(CodeIndexer.join(root, dir))
            } catch (e: Exception) {
                progress.errors++
                progress.problem(dir.ifEmpty { "/" } + ": " + (e.message?.ifBlank { null } ?: e.toString()))
                continue
            }
            val sorted = entries.sortedBy { it.name }
            val subdirs = ArrayList<Pair<String, Int>>()
            for (e in sorted) {
                val rel = if (dir.isEmpty()) e.name else dir + "/" + e.name
                if (CmGlob.any(config.excludes, rel)) continue
                if (e.dir) {
                    if (depth < MAX_DEPTH) subdirs.add(rel to depth + 1)
                    continue
                }
                if (CmLang.binaryName(e.name)) {
                    progress.skipped++
                    continue
                }
                if (out.size >= config.maxFiles) {
                    progress.problem("File limit of ${config.maxFiles} reached")
                    return
                }
                out.add(rel to e)
            }
            for (i in subdirs.indices.reversed()) stack.add(subdirs[i])
        }
    }

    private fun process(
        source: CodeSource,
        sink: CodeSink,
        root: String,
        rel: String,
        entry: CmEntry,
        config: CmConfig,
        progress: CmProgress,
        force: Boolean,
        clock: () -> Long,
    ): Boolean {
        val abs = join(root, rel)
        val old = sink.file(rel)
        if (entry.size > config.maxFileBytes) {
            progress.skipped++
            if (old != null) sink.remove(rel)
            return false
        }
        if (entry.size < 0 && !source.exists(abs)) {
            if (old != null) {
                sink.remove(rel)
                progress.removed++
            } else {
                progress.errors++
                progress.problem("$rel: not found")
            }
            return false
        }
        val stamp = source.stamp(abs)
        if (!force && old != null && stamp >= 0 && old.mtime == stamp && (entry.size < 0 || old.size == entry.size)) {
            progress.hits++
            return false
        }
        val bytes = source.read(abs, config.maxFileBytes + 1)
        if (bytes.size > config.maxFileBytes || looksBinary(bytes, bytes.size)) {
            progress.skipped++
            if (old != null) sink.remove(rel)
            return false
        }
        progress.bytes += bytes.size
        val head = CodeScan.hash(bytes, bytes.size)
        if (!force && old != null && old.hash == head.first && old.size == bytes.size.toLong()) {
            progress.hits++
            if (old.mtime != stamp) sink.touch(rel, stamp)
            return false
        }
        val name = rel.substringAfterLast('/')
        val scan = CodeScan.scan(bytes, bytes.size, CmLang.idOf(name))
        val lang = CmLang.nameOf(name)
        val file = CmFile(rel, lang, bytes.size.toLong(), stamp, scan.hash, scan.lines, CodeSummary.of(lang, scan.lines, scan.symbols, scan.imports), clock())
        sink.put(file, scan.symbols, scan.imports, scan.terms)
        progress.misses++
        return true
    }
}
