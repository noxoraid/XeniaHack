package com.untilyflow.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URI
import java.net.URL
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

private class HttpReq(val method: String, val path: String, val headers: Map<String, String>, val body: ByteArray)

private class HttpReply(val status: Int, val body: String?, val headers: Map<String, String> = emptyMap())

private class HttpFail(val reply: HttpReply) : Exception()

object McpServer {
    private const val MAX_BODY = 1_048_576
    private const val MAX_HEADER = 16_384
    private const val MAX_SESSIONS = 64
    private val loopbackNames = setOf("127.0.0.1", "localhost", "[::1]")

    var running by mutableStateOf(false)
        private set
    var port by mutableIntStateOf(0)
        private set
    var requests by mutableIntStateOf(0)
        private set
    var rejected by mutableIntStateOf(0)
        private set
    var error by mutableStateOf<String?>(null)
    var exposed by mutableIntStateOf(0)
    var testResult by mutableStateOf("")
    val log = mutableStateListOf<String>()

    @Volatile private var socket: ServerSocket? = null
    @Volatile private var appContext: Context? = null
    private val sessions = ConcurrentHashMap<String, Long>()
    private var core: McpCore? = null
    private var task: TaskRun? = null

    fun address(): String = "http://127.0.0.1:$port/mcp"

    private fun note(text: String) {
        log.add(0, java.text.SimpleDateFormat("HH:mm:ss", Lang.locale()).format(java.util.Date()) + "  " + text)
        while (log.size > 80) log.removeAt(log.size - 1)
        CodeMind.note("MCP " + text)
    }

    fun start(ctx: Context, wanted: Int): Boolean {
        if (running) return true
        CodeMind.attach(ctx)
        appContext = ctx.applicationContext
        val sock = try {
            ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), wanted))
            }
        } catch (e: java.net.BindException) {
            error = tr("Port {0} is already in use", wanted)
            return false
        } catch (e: Exception) {
            error = e.message?.ifBlank { null } ?: e.toString()
            return false
        }
        socket = sock
        port = sock.localPort
        error = null
        requests = 0
        rejected = 0
        running = true
        core = McpCore(CodeMind.mcpTools(), "codemind", "1.0.0") { note(it) }
        note("server started on 127.0.0.1:$port")
        task = TaskBoard.start(TaskKind.Mcp, "127.0.0.1:$port") { run ->
            run.detail = address()
            serve(run, sock)
        }
        return true
    }

    fun stop() {
        task?.stop = true
        try {
            socket?.close()
        } catch (_: Exception) {
        }
    }

    private fun serve(run: TaskRun, sock: ServerSocket) {
        val pool = Executors.newFixedThreadPool(4)
        try {
            sock.soTimeout = 500
            while (!run.stop && !sock.isClosed) {
                val client = try {
                    sock.accept()
                } catch (_: SocketTimeoutException) {
                    continue
                } catch (_: IOException) {
                    break
                }
                pool.execute { handle(client, run) }
            }
        } finally {
            try {
                sock.close()
            } catch (_: Exception) {
            }
            pool.shutdownNow()
            sessions.clear()
            running = false
            exposed = 0
            socket = null
            note("server stopped")
        }
    }

    private fun handle(client: Socket, run: TaskRun) {
        client.use { s ->
            s.soTimeout = 15_000
            val out = s.getOutputStream()
            try {
                val input = BufferedInputStream(s.getInputStream())
                val req = readRequest(input)
                respond(out, route(req))
                run.done = requests
            } catch (e: HttpFail) {
                respond(out, e.reply)
            } catch (_: SocketTimeoutException) {
            } catch (_: IOException) {
            } catch (e: Exception) {
                respond(out, fail(500, -32603, "Internal error"))
            }
        }
    }

    private fun readLine(input: BufferedInputStream, limit: Int): String? {
        val buf = ByteArrayOutputStream()
        while (true) {
            val b = input.read()
            if (b < 0) return if (buf.size() == 0) null else buf.toString("ISO-8859-1")
            if (b == '\n'.code) break
            if (b != '\r'.code) buf.write(b)
            if (buf.size() > limit) throw HttpFail(fail(431, -32600, "Header line too long"))
        }
        return buf.toString("ISO-8859-1")
    }

    private fun readRequest(input: BufferedInputStream): HttpReq {
        val first = readLine(input, 4096) ?: throw IOException("closed")
        val parts = first.split(' ')
        if (parts.size < 3) throw HttpFail(fail(400, -32600, "Bad request line"))
        val headers = HashMap<String, String>()
        var total = 0
        while (true) {
            val line = readLine(input, MAX_HEADER) ?: throw IOException("closed")
            if (line.isEmpty()) break
            total += line.length
            if (total > MAX_HEADER || headers.size > 100) throw HttpFail(fail(431, -32600, "Headers too large"))
            val cut = line.indexOf(':')
            if (cut > 0) headers[line.substring(0, cut).trim().lowercase()] = line.substring(cut + 1).trim()
        }
        val chunked = headers["transfer-encoding"]?.lowercase()?.contains("chunked") == true
        val body = ByteArrayOutputStream()
        if (chunked) {
            while (true) {
                val size = (readLine(input, 64) ?: throw IOException("closed")).substringBefore(';').trim().toIntOrNull(16)
                    ?: throw HttpFail(fail(400, -32600, "Bad chunk"))
                if (size == 0) {
                    while ((readLine(input, MAX_HEADER) ?: "").isNotEmpty()) continue
                    break
                }
                if (body.size() + size > MAX_BODY) throw HttpFail(fail(413, -32600, "Request too large"))
                val chunk = ByteArray(size)
                var got = 0
                while (got < size) {
                    val n = input.read(chunk, got, size - got)
                    if (n < 0) throw IOException("closed")
                    got += n
                }
                body.write(chunk)
                readLine(input, 8)
            }
        } else {
            val length = headers["content-length"]?.toIntOrNull() ?: 0
            if (length < 0 || length > MAX_BODY) throw HttpFail(fail(413, -32600, "Request too large"))
            val data = ByteArray(length)
            var got = 0
            while (got < length) {
                val n = input.read(data, got, length - got)
                if (n < 0) throw IOException("closed")
                got += n
            }
            body.write(data)
        }
        return HttpReq(parts[0].uppercase(), parts[1], headers, body.toByteArray())
    }

    private fun fail(status: Int, code: Int, message: String, extra: Map<String, String> = emptyMap()): HttpReply =
        HttpReply(status, CmJson.write(linkedMapOf("jsonrpc" to "2.0", "id" to null, "error" to linkedMapOf("code" to code, "message" to message))), extra)

    private fun hostAllowed(raw: String?): Boolean {
        val h = raw?.trim()?.lowercase() ?: return false
        val name = if (h.startsWith("[")) h.substringBefore(']') + "]" else h.substringBefore(':')
        return name in loopbackNames
    }

    private fun originAllowed(raw: String?): Boolean {
        if (raw == null) return true
        return try {
            val host = URI(raw).host ?: return false
            host.lowercase() in setOf("127.0.0.1", "localhost", "::1", "[::1]")
        } catch (_: Exception) {
            false
        }
    }

    private fun route(req: HttpReq): HttpReply {
        if (req.path.substringBefore('?') != "/mcp") return fail(404, -32600, "Not found")
        if (!hostAllowed(req.headers["host"]) || !originAllowed(req.headers["origin"])) {
            rejected++
            note("rejected: host or origin not allowed")
            return fail(403, -32600, "Forbidden")
        }
        val ctx = appContext ?: return fail(503, -32603, "Not ready")
        val sent = req.headers["authorization"]?.removePrefix("Bearer ")?.removePrefix("bearer ")?.trim() ?: ""
        if (!MessageDigest.isEqual(sent.toByteArray(Charsets.UTF_8), CmPrefs.token(ctx).toByteArray(Charsets.UTF_8))) {
            rejected++
            note("rejected: missing or wrong token")
            return fail(401, -32001, "Unauthorized", mapOf("WWW-Authenticate" to "Bearer"))
        }
        return when (req.method) {
            "POST" -> post(req)
            "DELETE" -> {
                val sid = req.headers["mcp-session-id"]
                if (sid != null && sessions.remove(sid) != null) HttpReply(200, null) else fail(404, -32600, "Unknown session")
            }
            else -> fail(405, -32600, "Method not allowed", mapOf("Allow" to "POST, DELETE"))
        }
    }

    private fun post(req: HttpReq): HttpReply {
        val engine = core ?: return fail(503, -32603, "Not ready")
        val version = req.headers["mcp-protocol-version"]
        if (version != null && version !in McpCore.SUPPORTED) return fail(400, -32600, "Unsupported MCP-Protocol-Version: $version")
        val text = String(req.body, Charsets.UTF_8)
        val starting = try {
            (CmJson.parse(text) as? Map<*, *>)?.get("method") == "initialize"
        } catch (_: Exception) {
            false
        }
        if (!starting) {
            val sid = req.headers["mcp-session-id"] ?: return fail(400, -32600, "Missing Mcp-Session-Id header. Send initialize first.")
            if (!sessions.containsKey(sid)) return fail(404, -32600, "Unknown session. Send initialize again.")
        }
        requests++
        val out = engine.handle(text)
        val extra = HashMap<String, String>()
        if (out.initialized) {
            if (sessions.size >= MAX_SESSIONS) sessions.entries.minByOrNull { it.value }?.let { sessions.remove(it.key) }
            val id = UUID.randomUUID().toString()
            sessions[id] = System.currentTimeMillis()
            extra["Mcp-Session-Id"] = id
        }
        return HttpReply(out.status, out.body, extra)
    }

    private fun respond(out: OutputStream, reply: HttpReply) {
        val reason = when (reply.status) {
            200 -> "OK"; 202 -> "Accepted"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 403 -> "Forbidden"
            404 -> "Not Found"; 405 -> "Method Not Allowed"; 413 -> "Payload Too Large"; 431 -> "Request Header Fields Too Large"
            503 -> "Service Unavailable"; else -> "Error"
        }
        val body = reply.body?.toByteArray(Charsets.UTF_8) ?: ByteArray(0)
        val head = StringBuilder("HTTP/1.1 ${reply.status} $reason\r\n")
        if (reply.body != null) head.append("Content-Type: application/json\r\n")
        head.append("Content-Length: ${body.size}\r\nConnection: close\r\nCache-Control: no-store\r\n")
        for ((k, v) in reply.headers) head.append(k).append(": ").append(v).append("\r\n")
        head.append("\r\n")
        try {
            out.write(head.toString().toByteArray(Charsets.ISO_8859_1))
            out.write(body)
            out.flush()
        } catch (_: IOException) {
        }
    }

    fun selfTest(ctx: Context) {
        testResult = tr("Testing…")
        TaskBoard.start(TaskKind.Mcp, tr("Connection test")) { run ->
            run.detail = address()
            testResult = try {
                probe(ctx)
            } catch (e: Exception) {
                tr("Failed: {0}", e.message?.ifBlank { null } ?: e.toString())
            }
        }
    }

    private fun post(url: String, token: String?, body: String, session: String?): Triple<Int, String, String?> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 3000
        c.readTimeout = 8000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "application/json, text/event-stream")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        if (session != null) c.setRequestProperty("Mcp-Session-Id", session)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
        val sid = c.getHeaderField("Mcp-Session-Id")
        c.disconnect()
        return Triple(code, text, sid)
    }

    private fun probe(ctx: Context): String {
        if (!running) return tr("Server is not running")
        val url = address()
        val denied = post(url, null, "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"ping\"}", null)
        if (denied.first != 401) return tr("Failed: a request without a token was not refused ({0})", denied.first)
        val token = CmPrefs.token(ctx)
        val init = post(url, token, "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"initialize\",\"params\":{\"protocolVersion\":\"2025-06-18\",\"capabilities\":{},\"clientInfo\":{\"name\":\"selftest\",\"version\":\"1\"}}}", null)
        if (init.first != 200 || init.third == null) return tr("Failed: initialize returned {0}", init.first)
        val version = ((CmJson.parse(init.second) as Map<*, *>)["result"] as Map<*, *>)["protocolVersion"]
        post(url, token, "{\"jsonrpc\":\"2.0\",\"method\":\"notifications/initialized\"}", init.third)
        val list = post(url, token, "{\"jsonrpc\":\"2.0\",\"id\":2,\"method\":\"tools/list\"}", init.third)
        if (list.first != 200) return tr("Failed: tools/list returned {0}", list.first)
        val count = (((CmJson.parse(list.second) as Map<*, *>)["result"] as Map<*, *>)["tools"] as List<*>).size
        return tr("OK: protocol {0}, {1} tools, token required", version, count)
    }
}
