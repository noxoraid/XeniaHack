package com.untilyflow.app

class CmProject(
    val id: String,
    val name: String,
    val root: String,
    val place: String,
    val state: String,
    val files: Int,
    val lastIndexed: Long,
)

class CmCtx(val project: CmProject, val index: CodeIndex, val source: CodeSource)

interface CodeMindApi {
    fun projects(): List<CmProject>

    fun open(ref: String?): CmCtx

    fun canUpdate(): Boolean

    fun update(ctx: CmCtx, paths: List<String>, force: Boolean): String
}

object CodeOverview {
    fun of(project: CmProject, index: CodeIndex): String {
        val stats = index.stats()
        val out = StringBuilder()
        out.append("Project: ").append(project.name).append(" (").append(project.place).append(' ').append(project.root).append(")\n")
        out.append("State: ").append(project.state).append("; ").append(stats.files).append(" files, ").append(stats.symbols).append(" symbols, ")
            .append(stats.imports).append(" imports\n")
        val langs = stats.byLang.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key }).take(6)
        if (langs.isNotEmpty()) out.append("Languages: ").append(langs.joinToString(", ") { it.key + " " + it.value }).append('\n')
        val paths = index.paths()
        val dirs = HashMap<String, Int>()
        for (p in paths) {
            val parts = p.split('/')
            val key = if (parts.size <= 1) "." else if (parts.size == 2) parts[0] else parts[0] + "/" + parts[1]
            dirs[key] = (dirs[key] ?: 0) + 1
        }
        val top = dirs.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key }).take(8)
        if (top.isNotEmpty()) out.append("Main folders: ").append(top.joinToString(", ") { it.key + " (" + it.value + ")" }).append('\n')
        val entries = paths.filter {
            val n = it.substringAfterLast('/').substringBeforeLast('.').lowercase()
            n == "main" || n == "mainactivity" || n == "index" || n == "app" || n == "application" || n == "server"
        }.take(6)
        if (entries.isNotEmpty()) out.append("Likely entry points: ").append(entries.joinToString(", ")).append('\n')
        val builds = paths.filter { CodeQuery.isConfig(it) }.take(8)
        if (builds.isNotEmpty()) out.append("Config files: ").append(builds.joinToString(", ")).append('\n')
        out.append("Test files: ").append(paths.count { CodeQuery.isTest(it) }).append('\n')
        out.append("Analysis: pattern-based symbol extraction (not a full parser).")
        return out.toString()
    }
}

object McpTools {
    private fun projectArg() = McpSchema.str("Project name or id. Defaults to the active project.")

    private fun pageNote(more: Boolean, offset: Int, size: Int): String = if (more) "\n(more results: use offset=${offset + size})" else ""

    fun build(api: CodeMindApi): List<McpTool> {
        fun ctxOf(args: Map<String, Any?>): CmCtx = api.open(args["project"] as? String)
        fun int(args: Map<String, Any?>, key: String, def: Int): Int = (args[key] as? Number)?.toInt() ?: def

        @Suppress("UNCHECKED_CAST")
        fun list(args: Map<String, Any?>, key: String): List<String> = (args[key] as? List<String>) ?: emptyList()

        val tools = ArrayList<McpTool>()

        tools.add(McpTool(
            "search_code", "Search code",
            "Find text in the indexed project files. Reads the files live. Returns path:line: text. Use for exact strings, error messages and identifiers.",
            McpSchema.obj(listOf("query"), linkedMapOf(
                "query" to McpSchema.str("Text to find, or a regular expression when regex is true"),
                "project" to projectArg(),
                "case_sensitive" to McpSchema.bool("Default false"),
                "regex" to McpSchema.bool("Treat query as a regular expression. Default false"),
                "path_glob" to McpSchema.str("Only search paths matching this glob, for example *.kt or src/*"),
                "limit" to McpSchema.int("Results per page, 1 to 100. Default 20", 1, 100),
                "offset" to McpSchema.int("Skip this many results. Default 0", 0, 100000),
            )), true,
        ) { args ->
            val ctx = ctxOf(args)
            val query = (args["query"] as String)
            if (query.isBlank()) throw CmToolError("query must not be empty")
            val limit = int(args, "limit", 20)
            val offset = int(args, "offset", 0)
            val page = try {
                CodeQuery.text(ctx.index, ctx.source, ctx.project.root, query, args["case_sensitive"] == true, args["regex"] == true, args["path_glob"] as? String, limit, offset)
            } catch (e: java.util.regex.PatternSyntaxException) {
                throw CmToolError("Invalid regular expression: " + e.description)
            }
            if (page.items.isEmpty()) "No matches." else page.items.joinToString("\n") { it.path + ":" + it.line + ": " + it.text } + pageNote(page.more, offset, page.items.size)
        })

        tools.add(McpTool(
            "search_symbols", "Search symbols",
            "Find classes, interfaces, functions, methods and other declarations by name. Matching is case-insensitive and ranked: exact, prefix, word, contains.",
            McpSchema.obj(listOf("query"), linkedMapOf(
                "query" to McpSchema.str("Symbol name or part of it"),
                "project" to projectArg(),
                "kind" to McpSchema.str("Filter by kind", listOf("class", "interface", "object", "enum", "struct", "trait", "record", "function", "method", "type", "namespace", "heading")),
                "limit" to McpSchema.int("Results per page, 1 to 100. Default 20", 1, 100),
                "offset" to McpSchema.int("Skip this many results. Default 0", 0, 100000),
            )), true,
        ) { args ->
            val ctx = ctxOf(args)
            val limit = int(args, "limit", 20)
            val offset = int(args, "offset", 0)
            val page = CodeQuery.symbols(ctx.index, args["query"] as String, args["kind"] as? String, limit, offset)
            if (page.items.isEmpty()) "No symbols found." else page.items.joinToString("\n") { it.kind + " " + it.name + "  " + it.file + ":" + it.line } + pageNote(page.more, offset, page.items.size)
        })

        tools.add(McpTool(
            "get_file_summary", "File summary",
            "Summary of one indexed file: language, size, lines, declarations and imports. Cheaper than reading the file.",
            McpSchema.obj(listOf("path"), linkedMapOf("path" to McpSchema.str("Path relative to the project root"), "project" to projectArg())), true,
        ) { args ->
            val ctx = ctxOf(args)
            val path = (args["path"] as String).trim().trim('/')
            val file = ctx.index.file(path) ?: throw CmToolError("File not in the index: $path")
            val syms = ctx.index.symbolsOf(path)
            val out = StringBuilder()
            out.append(file.path).append('\n').append(file.summary).append('\n')
            if (syms.isNotEmpty()) {
                out.append("Declarations:\n")
                for (s in syms.take(80)) out.append("  ").append(s.kind).append(' ').append(s.name).append(':').append(s.line).append('\n')
                if (syms.size > 80) out.append("  (+").append(syms.size - 80).append(" more)\n")
            }
            val imports = ctx.index.importsOf(path)
            if (imports.isNotEmpty()) out.append("Imports: ").append(imports.take(40).joinToString(", ")).append(if (imports.size > 40) " (+${imports.size - 40} more)" else "").append('\n')
            out.toString().trimEnd()
        })

        tools.add(McpTool(
            "get_symbol_info", "Symbol info",
            "Where a symbol is defined, with a short code excerpt, and the files that mention its name. References are textual matches, not semantic analysis.",
            McpSchema.obj(listOf("name"), linkedMapOf(
                "name" to McpSchema.str("Exact symbol name"),
                "project" to projectArg(),
                "kind" to McpSchema.str("Optional kind filter"),
            )), true,
        ) { args ->
            val ctx = ctxOf(args)
            val name = args["name"] as String
            val defs = CodeQuery.symbols(ctx.index, name, args["kind"] as? String, 50, 0).items
                .filter { it.name.equals(name, true) || it.name.substringAfterLast("::").equals(name, true) }.take(5)
            if (defs.isEmpty()) throw CmToolError("No definition named '$name' in the index. Try search_symbols with a part of the name.")
            val out = StringBuilder()
            for (d in defs) {
                out.append(d.kind).append(' ').append(d.name).append("  ").append(d.file).append(':').append(d.line).append('\n')
                try {
                    val text = String(ctx.source.read(CodeIndexer.join(ctx.project.root, d.file), 262144), Charsets.UTF_8).lines()
                    val a = (d.line - 1).coerceIn(0, maxOf(0, text.size - 1))
                    for (i in a until minOf(text.size, a + 14)) out.append("  ").append(i + 1).append(": ").append(text[i].take(160)).append('\n')
                } catch (_: CmStopped) {
                    throw CmStopped()
                } catch (_: Exception) {
                    out.append("  (file could not be read)\n")
                }
            }
            val refs = CodeQuery.text(ctx.index, ctx.source, ctx.project.root, name, true, false, null, 15, 0)
            out.append("Mentioned in (textual):\n")
            if (refs.items.isEmpty()) out.append("  none\n") else for (r in refs.items) out.append("  ").append(r.path).append(':').append(r.line).append('\n')
            out.toString().trimEnd()
        })

        tools.add(McpTool(
            "get_dependencies", "Dependencies",
            "Imports of a file, the project files they resolve to, and the project files that import it.",
            McpSchema.obj(listOf("path"), linkedMapOf("path" to McpSchema.str("Path relative to the project root"), "project" to projectArg())), true,
        ) { args ->
            val ctx = ctxOf(args)
            val path = (args["path"] as String).trim().trim('/')
            if (ctx.index.file(path) == null) throw CmToolError("File not in the index: $path")
            val deps = CodeQuery.dependencies(ctx.index, path)
            val out = StringBuilder()
            out.append("Imports (").append(deps.imports.size).append("): ").append(deps.imports.take(60).joinToString(", ").ifEmpty { "none" }).append('\n')
            out.append("Resolved in project: ").append(deps.resolved.joinToString(", ").ifEmpty { "none" }).append('\n')
            out.append("Imported by: ").append(deps.importedBy.take(60).joinToString(", ").ifEmpty { "none" })
            out.toString()
        })

        tools.add(McpTool(
            "get_relevant_context", "Relevant context",
            "Given a task description, pick the most relevant files, symbols, tests and config, with short excerpts, within a character budget. Constraints in the task are kept verbatim. Ranking is lexical and deterministic.",
            McpSchema.obj(listOf("task"), linkedMapOf(
                "task" to McpSchema.str("What the AI is asked to do, in plain words"),
                "project" to projectArg(),
                "budget_chars" to McpSchema.int("Maximum size of the result in characters. Default 8000", 500, 200000),
                "exclude" to McpSchema.strs("File names or glob patterns to leave out"),
            )), true,
        ) { args ->
            val ctx = ctxOf(args)
            val task = args["task"] as String
            if (task.isBlank()) throw CmToolError("task must not be empty")
            ContextPack.build(ctx.index, ctx.source, ctx.project.root, ctx.project.name, task, int(args, "budget_chars", 8000), list(args, "exclude")).text
        })

        tools.add(McpTool(
            "update_codebase_memory", "Update codebase memory",
            "Re-index the project incrementally. Unchanged files are reused through their hash. Pass paths to refresh only specific files. Changes only CodeMind's own index, never the source files.",
            McpSchema.obj(emptyList(), linkedMapOf(
                "project" to projectArg(),
                "paths" to McpSchema.strs("Only refresh these paths, relative to the project root"),
                "force" to McpSchema.bool("Re-analyze even when the hash is unchanged"),
            )), false,
        ) { args ->
            if (!api.canUpdate()) throw CmToolError("Index updates over MCP are turned off. The user can enable them in CodeMind > MCP Server.")
            val ctx = ctxOf(args)
            if (ctx.project.state == "indexing") throw CmToolError("The project is being indexed right now. Try again in a moment.")
            api.update(ctx, list(args, "paths"), args["force"] == true)
        })

        tools.add(McpTool(
            "optimize_context", "Optimize context",
            "Reduce redundancy in a text or in a freshly built task context without changing technical meaning: identical blocks, blank runs, repeated metadata. Aggressive mode also trims whitespace and whole-line comments in code blocks (heuristic). Returns before and after sizes; token counts are estimates (chars/4).",
            McpSchema.obj(emptyList(), linkedMapOf(
                "text" to McpSchema.str("Text to optimize. If omitted, a context is built from task"),
                "task" to McpSchema.str("Task used to build a context when text is omitted"),
                "project" to projectArg(),
                "mode" to McpSchema.str("conservative (default) or aggressive", listOf("conservative", "aggressive")),
                "exclude" to McpSchema.strs("File names or glob patterns to drop from the result"),
                "budget_chars" to McpSchema.int("Budget when building from task. Default 8000", 500, 200000),
            )), true,
        ) { args ->
            val aggressive = args["mode"] == "aggressive"
            val text = args["text"] as? String
            val source = if (text != null) {
                if (text.isEmpty()) throw CmToolError("text must not be empty")
                text
            } else {
                val task = args["task"] as? String
                if (task.isNullOrBlank()) throw CmToolError("Provide text or task")
                val ctx = ctxOf(args)
                ContextPack.build(ctx.index, ctx.source, ctx.project.root, ctx.project.name, task, int(args, "budget_chars", 8000), list(args, "exclude")).text
            }
            val trim = ContextTrim.run(source, aggressive, list(args, "exclude"))
            trim.report() + "\n\n" + trim.text
        })

        tools.add(McpTool(
            "get_project_overview", "Project overview",
            "Languages, main folders, entry points, config files and test count of an indexed project.",
            McpSchema.obj(emptyList(), linkedMapOf("project" to projectArg())), true,
        ) { args ->
            val ctx = ctxOf(args)
            CodeOverview.of(ctx.project, ctx.index)
        })

        tools.add(McpTool(
            "get_index_statistics", "Index statistics",
            "Counts, sizes, cache hits and misses and timing of the last indexing run of a project.",
            McpSchema.obj(emptyList(), linkedMapOf("project" to projectArg())), true,
        ) { args ->
            val ctx = ctxOf(args)
            val s = ctx.index.stats()
            val m = ctx.index
            val out = StringBuilder()
            out.append("Project: ").append(ctx.project.name).append(" (").append(ctx.project.state).append(")\n")
            out.append("Files: ").append(s.files).append(", symbols: ").append(s.symbols).append(", imports: ").append(s.imports).append(", terms: ").append(s.terms).append('\n')
            out.append("Source bytes indexed: ").append(s.sourceBytes).append(", index size: ").append(s.storeBytes).append(" bytes\n")
            out.append("Last run: scanned ").append(m.meta("run.scanned") ?: "-").append(", analyzed ").append(m.meta("run.indexed") ?: "-")
                .append(", skipped ").append(m.meta("run.skipped") ?: "-").append(", errors ").append(m.meta("run.errors") ?: "-")
                .append(", removed ").append(m.meta("run.removed") ?: "-").append(", ").append(m.meta("run.millis") ?: "-").append(" ms")
                .append(if (m.meta("run.full") == "0") " (partial)" else "").append('\n')
            out.append("Cache this run: ").append(m.meta("run.hits") ?: "-").append(" hits, ").append(m.meta("run.misses") ?: "-").append(" misses\n")
            out.append("Cache all runs: ").append(m.meta("total.hits") ?: "0").append(" hits, ").append(m.meta("total.misses") ?: "0").append(" misses")
            out.toString()
        })

        tools.add(McpTool(
            "list_indexed_projects", "List projects",
            "Projects CodeMind has indexed on this phone, with state and file counts.",
            McpSchema.obj(emptyList(), linkedMapOf()), true,
        ) { _ ->
            val all = api.projects()
            if (all.isEmpty()) "No projects indexed." else all.joinToString("\n") { it.name + "  [" + it.state + ", " + it.files + " files]  " + it.place + " " + it.root }
        })

        tools.add(McpTool(
            "get_file_metadata", "File metadata",
            "Stored metadata of one file: language, size, lines, hash, modification time, index time, counts, and whether it may have changed since indexing.",
            McpSchema.obj(listOf("path"), linkedMapOf("path" to McpSchema.str("Path relative to the project root"), "project" to projectArg())), true,
        ) { args ->
            val ctx = ctxOf(args)
            val path = (args["path"] as String).trim().trim('/')
            val f = ctx.index.file(path) ?: throw CmToolError("File not in the index: $path")
            val now = try {
                ctx.source.stamp(CodeIndexer.join(ctx.project.root, path))
            } catch (_: Exception) {
                -1L
            }
            val stale = when {
                !ctx.source.exists(CodeIndexer.join(ctx.project.root, path)) -> "file no longer exists"
                now < 0 -> "unknown"
                now != f.mtime -> "possibly changed since indexing"
                else -> "unchanged"
            }
            "path: ${f.path}\nlanguage: ${f.lang}\nsize: ${f.size} bytes\nlines: ${f.lines}\nhash: ${f.hash}\nmodified: ${f.mtime}\nindexed at: ${f.indexedAt}\n" +
                "symbols: ${ctx.index.symbolsOf(path).size}\nimports: ${ctx.index.importsOf(path).size}\nstatus: $stale"
        })

        return tools
    }
}
