package com.untilyflow.app

import android.content.Context

object OneTool {
    private const val HEAD = "nx"
    private const val READ_LIMIT = 3600
    private const val PAGE_LIMIT = 4000
    private const val PAGE_TEXT = "document.body?document.body.innerText:''"

    fun isCall(line: String): Boolean {
        val text = line.trim()
        return text == HEAD || text.startsWith("$HEAD ")
    }

    fun spec(target: AgentTarget): String {
        val shell = if (target is VpsAgentTarget) {
            "runs on the real server shell (sh -c): apt, npm, git, docker, pipes and && work. Use non-interactive flags and never start servers in the foreground. Destructive commands are blocked or wait for the user."
        } else {
            "runs on the phone's built-in shell: no pipes, no chaining, no npm or apt. rm waits for the user."
        }
        return """
One tool, many actions. Put "nx <action> <args>" as a line in commands. Any other line still runs as a plain shell command.
nx read <path> [from] [to]  file text, optional 1-based line range
nx ls [path]  |  nx find <glob> [path]  |  nx grep <text> [path]
nx sh <line>  $shell
${CodeMind.specLine()}nx web <url or search>  open in the in-app browser  |  nx text  visible page text  |  nx js <code>  run JavaScript on the page, waits for the user
Quote arguments with single quotes. To create or replace a file use the files list. A wrong call returns its correct usage.
Current location: ${target.place}
""".trim()
    }

    fun credit(app: Context, target: AgentTarget) {
        val gain = (target.toolbox.length - spec(target).length) / 4
        if (gain > 0) Cfg.addOneToolSaved(app, gain.toLong())
    }

    fun run(target: AgentTarget, app: Context, line: String, stopped: () -> Boolean, onOut: (String) -> Unit): ConsoleOut {
        if (!isCall(line)) return target.run(line, stopped, onOut)
        val body = line.trim().removePrefix(HEAD).trim()
        val action = body.substringBefore(' ').lowercase()
        val rest = body.substringAfter(' ', "").trim()
        return try {
            dispatch(target, app, action, rest, stopped, onOut)
        } catch (e: TaskStopped) {
            throw e
        } catch (e: Exception) {
            ConsoleOut(tr("nx {0}: {1}", action.ifEmpty { "?" }, e.message?.ifBlank { null } ?: e.toString()) + "\n" + usageOf(action), false)
        }
    }

    private fun dispatch(
        target: AgentTarget, app: Context, action: String, rest: String, stopped: () -> Boolean, onOut: (String) -> Unit,
    ): ConsoleOut {
        val words = consoleTokens(rest)
        return when (action) {
            "read" -> read(target, words, stopped, onOut)
            "ls" -> target.run((listOf("ls -l") + words.map { quote(it) }).joinToString(" "), stopped, onOut)
            "find" -> {
                if (words.isEmpty()) throw Exception(tr("Missing argument"))
                target.run("find ${quote(words.getOrElse(1) { "." })} -name ${quote(words[0])}", stopped, onOut)
            }
            "grep" -> {
                if (words.isEmpty()) throw Exception(tr("Missing argument"))
                target.run("grep -r -n ${quote(words[0])} ${quote(words.getOrElse(1) { "." })}", stopped, onOut)
            }
            "sh" -> {
                if (rest.isEmpty()) throw Exception(tr("Missing argument"))
                target.run(rest, stopped, onOut)
            }
            "cm" -> CodeMindTool.run(target, app, words, stopped)
            "web" -> {
                if (rest.isEmpty()) throw Exception(tr("Missing argument"))
                ConsoleOut(WebHost.open(rest, stopped), true)
            }
            "text" -> ConsoleOut(WebHost.script(PAGE_TEXT).take(PAGE_LIMIT), true)
            "js" -> script(target, app, rest, stopped, onOut)
            else -> throw Exception(tr("unknown action"))
        }
    }

    private fun read(target: AgentTarget, words: List<String>, stopped: () -> Boolean, onOut: (String) -> Unit): ConsoleOut {
        if (words.isEmpty()) throw Exception(tr("Missing argument"))
        val out = target.run("cat " + quote(words[0]), stopped, onOut)
        if (!out.ok) return out
        val lines = out.text.lines()
        val from = words.getOrNull(1)?.toIntOrNull()?.coerceAtLeast(1) ?: 1
        val end = minOf(words.getOrNull(2)?.toIntOrNull() ?: Int.MAX_VALUE, lines.size)
        if (from > lines.size) throw Exception(tr("file has {0} lines", lines.size))
        val body = StringBuilder()
        var last = from - 1
        for (i in from - 1 until end) {
            val row = lines[i]
            if (body.isNotEmpty() && body.length + row.length + 1 > READ_LIMIT) break
            body.append(if (body.isEmpty()) row.take(READ_LIMIT) else row).append('\n')
            last = i + 1
        }
        if (last < end) body.append(tr("[cut after line {0} of {1}, continue with: nx read {2} {3}]", last, lines.size, words[0], last + 1))
        return ConsoleOut(body.toString().trimEnd(), true)
    }

    private fun script(target: AgentTarget, app: Context, code: String, stopped: () -> Boolean, onOut: (String) -> Unit): ConsoleOut {
        if (code.isEmpty()) throw Exception(tr("Missing argument"))
        onOut(tr("Waiting for your approval"))
        val allowed = ApprovalBoard.request(app, tr("Browser page"), "nx js $code", tr("This script runs on the open web page and can act as you"), stopped)
        if (!allowed) return ConsoleOut(tr("Denied by you: {0}", "nx js"), false)
        return ConsoleOut(WebHost.script(code).take(PAGE_LIMIT), true)
    }

    private fun quote(value: String): String {
        if (value.contains('\'')) throw Exception(tr("single quotes cannot be used inside an argument"))
        val plain = value.isNotEmpty() && value.none { it.isWhitespace() || it in "*?[]{}()<>|&;$\"\\" }
        return if (plain) value else "'$value'"
    }

    private fun usageOf(action: String): String = when (action) {
        "read" -> "usage: nx read <path> [from] [to]"
        "ls" -> "usage: nx ls [path]"
        "find" -> "usage: nx find <glob> [path]"
        "grep" -> "usage: nx grep <text> [path]"
        "sh" -> "usage: nx sh <line>"
        "cm" -> CodeMindTool.USAGE
        "web" -> "usage: nx web <url or search>"
        "text" -> "usage: nx text"
        "js" -> "usage: nx js <code>"
        else -> "actions: read, ls, find, grep, sh, cm, web, text, js"
    }
}
