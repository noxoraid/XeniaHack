package com.untilyflow.app

class McpTool(
    val name: String,
    val title: String,
    val description: String,
    val schema: Map<String, Any?>,
    val readOnly: Boolean,
    val run: (Map<String, Any?>) -> String,
)

class McpOut(val status: Int, val body: String?, val initialized: Boolean = false)

object McpSchema {
    fun obj(required: List<String>, props: Map<String, Any?>): Map<String, Any?> =
        linkedMapOf("type" to "object", "properties" to props, "required" to required, "additionalProperties" to false)

    fun str(desc: String, values: List<String>? = null): Map<String, Any?> {
        val m = linkedMapOf<String, Any?>("type" to "string", "description" to desc)
        if (values != null) m["enum"] = values
        return m
    }

    fun int(desc: String, min: Long, max: Long): Map<String, Any?> =
        linkedMapOf("type" to "integer", "description" to desc, "minimum" to min, "maximum" to max)

    fun bool(desc: String): Map<String, Any?> = linkedMapOf("type" to "boolean", "description" to desc)

    fun strs(desc: String): Map<String, Any?> =
        linkedMapOf("type" to "array", "description" to desc, "items" to linkedMapOf("type" to "string"))

    fun validate(schema: Map<String, Any?>, args: Map<String, Any?>): String? {
        @Suppress("UNCHECKED_CAST")
        val props = schema["properties"] as Map<String, Map<String, Any?>>
        val required = (schema["required"] as? List<*>)?.map { it.toString() } ?: emptyList()
        for (r in required) if (!args.containsKey(r) || args[r] == null) return "Missing required argument '$r'"
        for ((k, v) in args) {
            val p = props[k] ?: return "Unknown argument '$k'. Allowed: " + props.keys.joinToString(", ")
            if (v == null) continue
            when (p["type"]) {
                "string" -> {
                    if (v !is String) return "Argument '$k' must be a string"
                    val allowed = p["enum"] as? List<*>
                    if (allowed != null && v !in allowed) return "Argument '$k' must be one of: " + allowed.joinToString(", ")
                }
                "integer" -> {
                    val n = when (v) {
                        is Long -> v
                        is Int -> v.toLong()
                        is Double -> if (v % 1.0 == 0.0) v.toLong() else return "Argument '$k' must be an integer"
                        else -> return "Argument '$k' must be an integer"
                    }
                    val min = (p["minimum"] as? Number)?.toLong()
                    val max = (p["maximum"] as? Number)?.toLong()
                    if (min != null && n < min) return "Argument '$k' must be at least $min"
                    if (max != null && n > max) return "Argument '$k' must be at most $max"
                }
                "boolean" -> if (v !is Boolean) return "Argument '$k' must be true or false"
                "array" -> {
                    if (v !is List<*>) return "Argument '$k' must be an array of strings"
                    if (v.any { it !is String }) return "Argument '$k' must contain only strings"
                }
            }
        }
        return null
    }
}

class McpCore(
    private val tools: List<McpTool>,
    private val serverName: String,
    private val version: String,
    private val log: (String) -> Unit,
) {
    companion object {
        val SUPPORTED = listOf("2025-06-18", "2025-03-26", "2024-11-05")
        const val INSTRUCTIONS = "CodeMind indexes projects on the user's phone. Call list_indexed_projects first, then search_symbols or get_relevant_context to find code before reading files. Results are lexical and pattern based, not a full semantic analysis."
    }

    private fun error(id: Any?, code: Int, message: String): Map<String, Any?> =
        linkedMapOf("jsonrpc" to "2.0", "id" to id, "error" to linkedMapOf("code" to code, "message" to message))

    private fun result(id: Any?, value: Any?): Map<String, Any?> =
        linkedMapOf("jsonrpc" to "2.0", "id" to id, "result" to value)

    fun handle(text: String): McpOut {
        val parsed = try {
            CmJson.parse(text)
        } catch (e: CmJsonError) {
            return McpOut(400, CmJson.write(error(null, -32700, "Parse error: " + e.message)))
        }
        if (parsed is List<*>) {
            if (parsed.isEmpty()) return McpOut(400, CmJson.write(error(null, -32600, "Empty batch")))
            val replies = ArrayList<Any?>()
            for (item in parsed) {
                val one = single(item)
                if (one.first != null) replies.add(one.first)
            }
            return if (replies.isEmpty()) McpOut(202, null) else McpOut(200, CmJson.write(replies))
        }
        val one = single(parsed)
        val reply = one.first ?: return McpOut(202, null)
        val bad = (reply["error"] as? Map<*, *>)?.get("code") == -32600
        return McpOut(if (bad) 400 else 200, CmJson.write(reply), one.second)
    }

    private fun single(node: Any?): Pair<Map<String, Any?>?, Boolean> {
        @Suppress("UNCHECKED_CAST")
        val msg = node as? Map<String, Any?> ?: return error(null, -32600, "Invalid request") to false
        if (msg["jsonrpc"] != "2.0") return error(msg["id"], -32600, "jsonrpc must be \"2.0\"") to false
        val method = msg["method"]
        if (method == null) return null to false
        if (method !is String) return error(msg["id"], -32600, "method must be a string") to false
        val hasId = msg.containsKey("id")
        val id = msg["id"]
        if (hasId && id != null && id !is String && id !is Number) return error(null, -32600, "id must be a string or a number") to false
        if (hasId && id == null) return error(null, -32600, "id must not be null") to false
        if (!hasId) {
            log("notification $method")
            return null to false
        }
        @Suppress("UNCHECKED_CAST")
        val params = (msg["params"] as? Map<String, Any?>) ?: emptyMap()
        return when (method) {
            "initialize" -> initialize(id, params)
            "ping" -> result(id, emptyMap<String, Any?>()) to false
            "tools/list" -> result(id, linkedMapOf("tools" to tools.map { describe(it) })) to false
            "tools/call" -> call(id, params) to false
            else -> error(id, -32601, "Method not found: $method") to false
        }
    }

    private fun initialize(id: Any?, params: Map<String, Any?>): Pair<Map<String, Any?>, Boolean> {
        val asked = params["protocolVersion"] as? String
            ?: return error(id, -32602, "protocolVersion is required") to false
        val chosen = if (asked in SUPPORTED) asked else SUPPORTED.first()
        log("initialize $asked -> $chosen")
        val value = linkedMapOf(
            "protocolVersion" to chosen,
            "capabilities" to linkedMapOf("tools" to linkedMapOf("listChanged" to false)),
            "serverInfo" to linkedMapOf("name" to serverName, "title" to "CodeMind", "version" to version),
            "instructions" to INSTRUCTIONS,
        )
        return result(id, value) to true
    }

    private fun describe(t: McpTool): Map<String, Any?> = linkedMapOf(
        "name" to t.name,
        "title" to t.title,
        "description" to t.description,
        "inputSchema" to t.schema,
        "annotations" to linkedMapOf(
            "title" to t.title,
            "readOnlyHint" to t.readOnly,
            "destructiveHint" to false,
            "idempotentHint" to true,
            "openWorldHint" to false,
        ),
    )

    private fun call(id: Any?, params: Map<String, Any?>): Map<String, Any?> {
        val name = params["name"] as? String ?: return error(id, -32602, "Tool name is required")
        val tool = tools.firstOrNull { it.name == name } ?: return error(id, -32602, "Unknown tool: $name")
        val rawArgs = params["arguments"]
        if (rawArgs != null && rawArgs !is Map<*, *>) return error(id, -32602, "arguments must be an object")
        @Suppress("UNCHECKED_CAST")
        val args = (rawArgs as? Map<String, Any?>) ?: emptyMap()
        val started = System.currentTimeMillis()
        val reply = try {
            val problem = McpSchema.validate(tool.schema, args)
            if (problem != null) {
                toolResult(id, problem, true)
            } else {
                toolResult(id, tool.run(args), false)
            }
        } catch (e: CmToolError) {
            toolResult(id, e.message ?: "Tool error", true)
        } catch (e: CmStopped) {
            toolResult(id, "The operation was cancelled", true)
        } catch (e: Exception) {
            toolResult(id, "Tool failed: " + (e.message?.ifBlank { null } ?: e.toString()), true)
        }
        val isError = ((reply["result"] as? Map<*, *>)?.get("isError")) == true
        log("tools/call $name " + (if (isError) "error " else "ok ") + (System.currentTimeMillis() - started) + "ms")
        return reply
    }

    private fun toolResult(id: Any?, text: String, isError: Boolean): Map<String, Any?> = result(
        id,
        linkedMapOf("content" to listOf(linkedMapOf("type" to "text", "text" to text)), "isError" to isError),
    )
}
