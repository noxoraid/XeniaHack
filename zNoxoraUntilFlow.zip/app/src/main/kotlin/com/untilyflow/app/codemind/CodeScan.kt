package com.untilyflow.app

class CmSym(val kind: String, val name: String, val line: Int)

class CmScan(
    val hash: String,
    val lines: Int,
    val symbols: List<CmSym>,
    val imports: List<String>,
    val terms: List<Pair<String, Int>>,
)

object CodeScan {
    private val loaded: Boolean = try {
        System.loadLibrary("nxcore")
        true
    } catch (_: Throwable) {
        false
    }

    private external fun nativeScan(data: ByteArray, len: Int, lang: Int): ByteArray

    fun pack(data: ByteArray, len: Int, lang: Int): String {
        val native = if (loaded) {
            try {
                nativeScan(data, len, lang)
            } catch (_: Throwable) {
                null
            }
        } else {
            null
        }
        return if (native != null) String(native, Charsets.UTF_8) else CodeScanFallback.pack(data, len, lang)
    }

    fun scan(data: ByteArray, len: Int, lang: Int): CmScan = parse(pack(data, len, lang))

    fun hash(data: ByteArray, len: Int): Pair<String, Int> {
        val head = pack(data, len, -1).lineSequence().first().split('\t')
        return head[1] to (head.getOrNull(2)?.toIntOrNull() ?: 0)
    }

    fun parse(text: String): CmScan {
        var hash = ""
        var lines = 0
        val symbols = ArrayList<CmSym>()
        val imports = ArrayList<String>()
        val terms = ArrayList<Pair<String, Int>>()
        for (row in text.split('\n')) {
            if (row.length < 3) continue
            val cut = row.split('\t')
            when (cut[0]) {
                "H" -> {
                    hash = cut.getOrElse(1) { "" }
                    lines = cut.getOrNull(2)?.toIntOrNull() ?: 0
                }
                "S" -> if (cut.size >= 4) symbols.add(CmSym(cut[1], cut[2], cut[3].toIntOrNull() ?: 0))
                "I" -> imports.add(row.substring(2))
                "T" -> if (cut.size >= 3) terms.add(cut[1] to (cut[2].toIntOrNull() ?: 1))
            }
        }
        return CmScan(hash, lines, symbols, imports, terms)
    }
}
