package com.untilyflow.app

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import java.io.File

class SqlIndex(private val file: File) : CodeSink {
    private val db: SQLiteDatabase
    private var open = false

    init {
        file.parentFile?.mkdirs()
        db = SQLiteDatabase.openOrCreateDatabase(file, null)
        try {
            db.enableWriteAheadLogging()
        } catch (_: Exception) {
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY, path TEXT UNIQUE NOT NULL, lang TEXT, size INTEGER, mtime INTEGER, hash TEXT, lines INTEGER, summary TEXT, indexed INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS syms(fid INTEGER NOT NULL, name TEXT NOT NULL, lname TEXT NOT NULL, kind TEXT, line INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS imps(fid INTEGER NOT NULL, target TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS terms(term TEXT NOT NULL, fid INTEGER NOT NULL, n INTEGER)")
        db.execSQL("CREATE INDEX IF NOT EXISTS syms_fid ON syms(fid)")
        db.execSQL("CREATE INDEX IF NOT EXISTS syms_name ON syms(lname)")
        db.execSQL("CREATE INDEX IF NOT EXISTS imps_fid ON imps(fid)")
        db.execSQL("CREATE INDEX IF NOT EXISTS terms_term ON terms(term)")
        db.execSQL("CREATE INDEX IF NOT EXISTS terms_fid ON terms(fid)")
    }

    fun close() {
        try {
            db.close()
        } catch (_: Exception) {
        }
    }

    private fun like(text: String): String = text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    private fun fileOf(c: android.database.Cursor): CmFile = CmFile(
        c.getString(0), c.getString(1) ?: "", c.getLong(2), c.getLong(3), c.getString(4) ?: "", c.getInt(5), c.getString(6) ?: "", c.getLong(7),
    )

    private val columns = "path, lang, size, mtime, hash, lines, summary, indexed"

    override fun fileCount(): Int = db.rawQuery("SELECT COUNT(*) FROM files", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    override fun file(path: String): CmFile? =
        db.rawQuery("SELECT $columns FROM files WHERE path = ?", arrayOf(path)).use { if (it.moveToFirst()) fileOf(it) else null }

    override fun files(prefix: String, offset: Int, limit: Int): List<CmFile> {
        val out = ArrayList<CmFile>()
        db.rawQuery("SELECT $columns FROM files WHERE path LIKE ? ESCAPE '\\' ORDER BY path LIMIT ? OFFSET ?", arrayOf(like(prefix) + "%", limit.toString(), offset.toString())).use {
            while (it.moveToNext()) out.add(fileOf(it))
        }
        return out
    }

    override fun paths(): List<String> {
        val out = ArrayList<String>()
        db.rawQuery("SELECT path FROM files ORDER BY path", null).use { while (it.moveToNext()) out.add(it.getString(0)) }
        return out
    }

    override fun symbolsOf(path: String): List<CmSymbol> {
        val out = ArrayList<CmSymbol>()
        db.rawQuery("SELECT s.name, s.kind, s.line FROM syms s JOIN files f ON f.id = s.fid WHERE f.path = ? ORDER BY s.line", arrayOf(path)).use {
            while (it.moveToNext()) out.add(CmSymbol(path, it.getString(0), it.getString(1) ?: "", it.getInt(2)))
        }
        return out
    }

    override fun findSymbols(part: String, limit: Int): List<CmSymbol> {
        val out = ArrayList<CmSymbol>()
        db.rawQuery(
            "SELECT f.path, s.name, s.kind, s.line FROM syms s JOIN files f ON f.id = s.fid WHERE s.lname LIKE ? ESCAPE '\\' LIMIT ?",
            arrayOf("%" + like(part.lowercase()) + "%", limit.toString()),
        ).use { while (it.moveToNext()) out.add(CmSymbol(it.getString(0), it.getString(1), it.getString(2) ?: "", it.getInt(3))) }
        return out
    }

    override fun importsOf(path: String): List<String> {
        val out = ArrayList<String>()
        db.rawQuery("SELECT i.target FROM imps i JOIN files f ON f.id = i.fid WHERE f.path = ? ORDER BY i.rowid", arrayOf(path)).use {
            while (it.moveToNext()) out.add(it.getString(0))
        }
        return out
    }

    override fun allImports(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        db.rawQuery("SELECT f.path, i.target FROM imps i JOIN files f ON f.id = i.fid", null).use {
            while (it.moveToNext()) out.add(it.getString(0) to it.getString(1))
        }
        return out
    }

    override fun termHits(terms: List<String>): List<CmTermHit> {
        if (terms.isEmpty()) return emptyList()
        val out = ArrayList<CmTermHit>()
        val marks = terms.joinToString(",") { "?" }
        db.rawQuery("SELECT f.path, t.term, t.n FROM terms t JOIN files f ON f.id = t.fid WHERE t.term IN ($marks)", terms.toTypedArray()).use {
            while (it.moveToNext()) out.add(CmTermHit(it.getString(0), it.getString(1), it.getInt(2)))
        }
        return out
    }

    override fun docFreq(terms: List<String>): Map<String, Int> {
        if (terms.isEmpty()) return emptyMap()
        val out = HashMap<String, Int>()
        val marks = terms.joinToString(",") { "?" }
        db.rawQuery("SELECT term, COUNT(*) FROM terms WHERE term IN ($marks) GROUP BY term", terms.toTypedArray()).use {
            while (it.moveToNext()) out[it.getString(0)] = it.getInt(1)
        }
        return out
    }

    private fun count(sql: String): Int = db.rawQuery(sql, null).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    override fun stats(): CmStats {
        val langs = LinkedHashMap<String, Int>()
        db.rawQuery("SELECT lang, COUNT(*) FROM files GROUP BY lang", null).use { while (it.moveToNext()) langs[it.getString(0) ?: "text"] = it.getInt(1) }
        val bytes = db.rawQuery("SELECT COALESCE(SUM(size), 0) FROM files", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
        val wal = File(file.path + "-wal").let { if (it.isFile) it.length() else 0L }
        return CmStats(count("SELECT COUNT(*) FROM files"), count("SELECT COUNT(*) FROM syms"), count("SELECT COUNT(*) FROM imps"), count("SELECT COUNT(*) FROM terms"), bytes, file.length() + wal, langs)
    }

    override fun meta(key: String): String? = db.rawQuery("SELECT v FROM meta WHERE k = ?", arrayOf(key)).use { if (it.moveToFirst()) it.getString(0) else null }

    @Synchronized
    override fun begin() {
        if (open) return
        db.beginTransaction()
        open = true
    }

    @Synchronized
    override fun commit() {
        if (!open) return
        db.setTransactionSuccessful()
        db.endTransaction()
        open = false
    }

    private fun dropChildren(fid: Long) {
        val arg = arrayOf(fid.toString())
        db.delete("syms", "fid = ?", arg)
        db.delete("imps", "fid = ?", arg)
        db.delete("terms", "fid = ?", arg)
    }

    private fun idOf(path: String): Long? = db.rawQuery("SELECT id FROM files WHERE path = ?", arrayOf(path)).use { if (it.moveToFirst()) it.getLong(0) else null }

    @Synchronized
    override fun put(file: CmFile, symbols: List<CmSym>, imports: List<String>, terms: List<Pair<String, Int>>) {
        val old = idOf(file.path)
        if (old != null) {
            dropChildren(old)
            db.delete("files", "id = ?", arrayOf(old.toString()))
        }
        val row = ContentValues()
        row.put("path", file.path)
        row.put("lang", file.lang)
        row.put("size", file.size)
        row.put("mtime", file.mtime)
        row.put("hash", file.hash)
        row.put("lines", file.lines)
        row.put("summary", file.summary)
        row.put("indexed", file.indexedAt)
        val fid = db.insertOrThrow("files", null, row)
        val sym = db.compileStatement("INSERT INTO syms(fid, name, lname, kind, line) VALUES(?,?,?,?,?)")
        for (s in symbols) {
            sym.clearBindings()
            sym.bindLong(1, fid)
            sym.bindString(2, s.name)
            sym.bindString(3, s.name.lowercase())
            sym.bindString(4, s.kind)
            sym.bindLong(5, s.line.toLong())
            sym.executeInsert()
        }
        sym.close()
        val imp = db.compileStatement("INSERT INTO imps(fid, target) VALUES(?,?)")
        for (t in imports) {
            imp.clearBindings()
            imp.bindLong(1, fid)
            imp.bindString(2, t)
            imp.executeInsert()
        }
        imp.close()
        val term = db.compileStatement("INSERT INTO terms(term, fid, n) VALUES(?,?,?)")
        for ((t, n) in terms) {
            term.clearBindings()
            term.bindString(1, t)
            term.bindLong(2, fid)
            term.bindLong(3, n.toLong())
            term.executeInsert()
        }
        term.close()
    }

    @Synchronized
    override fun touch(path: String, mtime: Long) {
        val row = ContentValues()
        row.put("mtime", mtime)
        db.update("files", row, "path = ?", arrayOf(path))
    }

    @Synchronized
    override fun remove(path: String) {
        val id = idOf(path) ?: return
        dropChildren(id)
        db.delete("files", "id = ?", arrayOf(id.toString()))
    }

    @Synchronized
    override fun setMeta(key: String, value: String) {
        val row = ContentValues()
        row.put("k", key)
        row.put("v", value)
        db.insertWithOnConflict("meta", null, row, SQLiteDatabase.CONFLICT_REPLACE)
    }

    @Synchronized
    override fun wipe() {
        commit()
        db.beginTransaction()
        try {
            for (t in listOf("syms", "imps", "terms", "files", "meta")) db.delete(t, null, null)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        try {
            db.execSQL("VACUUM")
        } catch (_: Exception) {
        }
    }

    fun delete() {
        close()
        for (suffix in listOf("", "-wal", "-shm", "-journal")) File(file.path + suffix).delete()
    }
}
