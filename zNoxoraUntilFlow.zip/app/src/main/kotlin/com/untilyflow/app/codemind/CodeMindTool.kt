package com.untilyflow.app

import android.content.Context

object CodeMindTool {
    const val USAGE = "usage: nx cm index [path] [force] | find <text> | sym <name> | file <path> | deps <path> | ctx <task> | stats | projects"

    fun spec(): String =
        "nx cm index [path] [force]  index or refresh this project (incremental)  |  nx cm find <text>  |  nx cm sym <name>  |  nx cm file <path>  |  nx cm deps <path>  |  nx cm ctx <task>  relevant files for a task  |  nx cm stats"

    fun run(target: AgentTarget, app: Context, words: List<String>, stopped: () -> Boolean): ConsoleOut {
        CodeMind.attach(app)
        val sub = words.firstOrNull()?.lowercase() ?: return ConsoleOut(USAGE, false)
        val rest = words.drop(1)
        return try {
            when (sub) {
                "index" -> index(target, app, rest, stopped)
                "projects" -> ConsoleOut(CodeMind.callTool("list_indexed_projects", emptyMap()), true)
                else -> query(target, sub, rest)
            }
        } catch (e: CmToolError) {
            ConsoleOut(e.message ?: USAGE, false)
        }
    }

    private fun index(target: AgentTarget, app: Context, rest: List<String>, stopped: () -> Boolean): ConsoleOut {
        val force = rest.any { it == "force" }
        val path = rest.firstOrNull { it != "force" }
        val root = fixPath(path ?: target.cwd, target.cwd)
        val rec = try {
            CodeMind.recFor(target)?.takeIf { path == null || it.root == root } ?: CodeMind.add(app, target.source, root)
        } catch (e: Exception) {
            return ConsoleOut(e.message ?: e.toString(), false)
        }
        val text = CodeMind.indexBlocking(rec, force, null, 10 * 60_000L, stopped)
        CodeMind.select(app, rec.id)
        return ConsoleOut(text, !text.startsWith("Indexing failed"))
    }

    private fun query(target: AgentTarget, sub: String, rest: List<String>): ConsoleOut {
        val rec = CodeMind.recFor(target) ?: return ConsoleOut("No indexed project contains " + target.cwd + ". Run: nx cm index", false)
        val project = rec.id
        val joined = rest.joinToString(" ").trim()
        fun need(): String = joined.ifEmpty { throw CmToolError(USAGE) }
        val text = when (sub) {
            "find" -> CodeMind.callTool("search_code", mapOf("query" to need(), "project" to project))
            "sym" -> CodeMind.callTool("search_symbols", mapOf("query" to need(), "project" to project))
            "file" -> CodeMind.callTool("get_file_summary", mapOf("path" to relative(rec, need(), target.cwd), "project" to project))
            "deps" -> CodeMind.callTool("get_dependencies", mapOf("path" to relative(rec, need(), target.cwd), "project" to project))
            "ctx" -> CodeMind.callTool("get_relevant_context", mapOf("task" to need(), "project" to project, "budget_chars" to 6000))
            "stats" -> CodeMind.callTool("get_index_statistics", mapOf("project" to project))
            else -> throw CmToolError(USAGE)
        }
        return ConsoleOut(text, true)
    }

    private fun relative(rec: CmProjectRec, path: String, cwd: String): String {
        val abs = fixPath(path, cwd)
        val root = rec.root.trimEnd('/')
        return if (abs == root) "" else if (abs.startsWith("$root/")) abs.substring(root.length + 1) else path.trim('/')
    }
}
