package com.untilyflow.app

class CmJsonError(message: String) : Exception(message)

object CmJson {
    private const val MAX_DEPTH = 48

    fun parse(text: String): Any? {
        val reader = Reader(text)
        reader.skip()
        val value = reader.value(0)
        reader.skip()
        if (!reader.done()) throw CmJsonError("Unexpected data after the JSON value")
        return value
    }

    fun write(value: Any?): String {
        val out = StringBuilder()
        put(out, value)
        return out.toString()
    }

    private fun put(out: StringBuilder, value: Any?) {
        when (value) {
            null -> out.append("null")
            is Boolean -> out.append(if (value) "true" else "false")
            is Int, is Long -> out.append(value.toString())
            is Double -> out.append(if (value.isNaN() || value.isInfinite()) "null" else if (value % 1.0 == 0.0 && Math.abs(value) < 1e15) value.toLong().toString() else value.toString())
            is Float -> put(out, value.toDouble())
            is String -> quote(out, value)
            is Map<*, *> -> {
                out.append('{')
                var first = true
                for ((k, v) in value) {
                    if (!first) out.append(',')
                    first = false
                    quote(out, k.toString())
                    out.append(':')
                    put(out, v)
                }
                out.append('}')
            }
            is Iterable<*> -> {
                out.append('[')
                var first = true
                for (v in value) {
                    if (!first) out.append(',')
                    first = false
                    put(out, v)
                }
                out.append(']')
            }
            is Array<*> -> put(out, value.toList())
            else -> quote(out, value.toString())
        }
    }

    private fun quote(out: StringBuilder, text: String) {
        out.append('"')
        for (c in text) {
            when {
                c == '"' -> out.append("\\\"")
                c == '\\' -> out.append("\\\\")
                c == '\n' -> out.append("\\n")
                c == '\r' -> out.append("\\r")
                c == '\t' -> out.append("\\t")
                c == '\b' -> out.append("\\b")
                c == '\u000c' -> out.append("\\f")
                c < ' ' || c == '\u2028' || c == '\u2029' -> out.append("\\u").append(String.format("%04x", c.code))
                else -> out.append(c)
            }
        }
        out.append('"')
    }

    private class Reader(val text: String) {
        var pos = 0

        fun done(): Boolean = pos >= text.length

        fun skip() {
            while (pos < text.length && (text[pos] == ' ' || text[pos] == '\n' || text[pos] == '\r' || text[pos] == '\t')) pos++
        }

        fun value(depth: Int): Any? {
            if (depth > MAX_DEPTH) throw CmJsonError("JSON is nested too deeply")
            if (done()) throw CmJsonError("Unexpected end of JSON")
            return when (val c = text[pos]) {
                '{' -> obj(depth)
                '[' -> arr(depth)
                '"' -> str()
                't' -> word("true", true)
                'f' -> word("false", false)
                'n' -> word("null", null)
                else -> if (c == '-' || c in '0'..'9') num() else throw CmJsonError("Unexpected character '$c' at $pos")
            }
        }

        fun word(w: String, v: Any?): Any? {
            if (!text.startsWith(w, pos)) throw CmJsonError("Unexpected token at $pos")
            pos += w.length
            return v
        }

        fun num(): Any {
            val a = pos
            if (text[pos] == '-') pos++
            while (pos < text.length && text[pos] in '0'..'9') pos++
            var real = false
            if (pos < text.length && text[pos] == '.') {
                real = true
                pos++
                while (pos < text.length && text[pos] in '0'..'9') pos++
            }
            if (pos < text.length && (text[pos] == 'e' || text[pos] == 'E')) {
                real = true
                pos++
                if (pos < text.length && (text[pos] == '+' || text[pos] == '-')) pos++
                while (pos < text.length && text[pos] in '0'..'9') pos++
            }
            val raw = text.substring(a, pos)
            if (raw == "-" || raw.isEmpty()) throw CmJsonError("Bad number at $a")
            return try {
                if (real) raw.toDouble() else raw.toLongOrNull() ?: raw.toDouble()
            } catch (_: NumberFormatException) {
                throw CmJsonError("Bad number at $a")
            }
        }

        fun str(): String {
            pos++
            val out = StringBuilder()
            while (true) {
                if (done()) throw CmJsonError("Unterminated string")
                val c = text[pos++]
                if (c == '"') return out.toString()
                if (c < ' ') throw CmJsonError("Control character in string")
                if (c != '\\') {
                    out.append(c)
                    continue
                }
                if (done()) throw CmJsonError("Unterminated string")
                when (val e = text[pos++]) {
                    '"' -> out.append('"')
                    '\\' -> out.append('\\')
                    '/' -> out.append('/')
                    'b' -> out.append('\b')
                    'f' -> out.append('\u000c')
                    'n' -> out.append('\n')
                    'r' -> out.append('\r')
                    't' -> out.append('\t')
                    'u' -> {
                        if (pos + 4 > text.length) throw CmJsonError("Bad unicode escape")
                        val code = text.substring(pos, pos + 4).toIntOrNull(16) ?: throw CmJsonError("Bad unicode escape")
                        out.append(code.toChar())
                        pos += 4
                    }
                    else -> throw CmJsonError("Bad escape '\\$e'")
                }
            }
        }

        fun arr(depth: Int): List<Any?> {
            pos++
            val out = ArrayList<Any?>()
            skip()
            if (pos < text.length && text[pos] == ']') {
                pos++
                return out
            }
            while (true) {
                skip()
                out.add(value(depth + 1))
                skip()
                if (done()) throw CmJsonError("Unterminated array")
                val c = text[pos++]
                if (c == ']') return out
                if (c != ',') throw CmJsonError("Expected ',' or ']' at ${pos - 1}")
            }
        }

        fun obj(depth: Int): Map<String, Any?> {
            pos++
            val out = LinkedHashMap<String, Any?>()
            skip()
            if (pos < text.length && text[pos] == '}') {
                pos++
                return out
            }
            while (true) {
                skip()
                if (done() || text[pos] != '"') throw CmJsonError("Expected a string key at $pos")
                val key = str()
                skip()
                if (done() || text[pos] != ':') throw CmJsonError("Expected ':' at $pos")
                pos++
                skip()
                out[key] = value(depth + 1)
                skip()
                if (done()) throw CmJsonError("Unterminated object")
                val c = text[pos++]
                if (c == '}') return out
                if (c != ',') throw CmJsonError("Expected ',' or '}' at ${pos - 1}")
            }
        }
    }
}
