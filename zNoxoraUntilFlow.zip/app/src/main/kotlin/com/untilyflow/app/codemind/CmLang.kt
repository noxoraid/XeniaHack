package com.untilyflow.app

object CmLang {
    const val TEXT = 0
    const val KOTLIN = 1
    const val JAVA = 2
    const val JS = 3
    const val TS = 4
    const val PYTHON = 5
    const val C = 6
    const val CPP = 7
    const val HTML = 8
    const val CSS = 9
    const val JSON = 10
    const val XML = 11
    const val MARKDOWN = 12

    private val byExt = mapOf(
        "kt" to KOTLIN, "kts" to KOTLIN, "java" to JAVA,
        "js" to JS, "mjs" to JS, "cjs" to JS, "jsx" to JS,
        "ts" to TS, "tsx" to TS,
        "py" to PYTHON, "c" to C, "h" to C,
        "cpp" to CPP, "cc" to CPP, "cxx" to CPP, "hpp" to CPP, "hh" to CPP, "hxx" to CPP,
        "html" to HTML, "htm" to HTML, "css" to CSS, "json" to JSON,
        "xml" to XML, "md" to MARKDOWN, "markdown" to MARKDOWN,
    )

    private val names = mapOf(
        KOTLIN to "kotlin", JAVA to "java", JS to "javascript", TS to "typescript", PYTHON to "python", C to "c",
        CPP to "cpp", HTML to "html", CSS to "css", JSON to "json", XML to "xml", MARKDOWN to "markdown",
    )

    val binaryExt = setOf(
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "ico", "heic", "mp3", "wav", "ogg", "flac", "m4a", "aac",
        "mp4", "mkv", "avi", "mov", "webm", "3gp", "zip", "gz", "tgz", "bz2", "xz", "7z", "rar", "tar", "jar",
        "aar", "apk", "aab", "dex", "so", "a", "o", "obj", "dll", "exe", "class", "bin", "dat", "db", "sqlite",
        "ttf", "otf", "woff", "woff2", "pdf", "keystore", "jks", "p12", "iso", "img", "lock", "map",
    )

    fun extOf(fileName: String): String {
        val dot = fileName.lastIndexOf('.')
        return if (dot <= 0 || dot == fileName.length - 1) "" else fileName.substring(dot + 1).lowercase()
    }

    fun idOf(fileName: String): Int {
        if (fileName == "CMakeLists.txt") return TEXT
        return byExt[extOf(fileName)] ?: TEXT
    }

    fun nameOf(fileName: String): String {
        val id = idOf(fileName)
        if (id != TEXT) return names.getValue(id)
        val ext = extOf(fileName)
        return if (ext.isEmpty()) "text" else ext
    }

    fun parsed(id: Int): Boolean = id != TEXT

    fun binaryName(fileName: String): Boolean = extOf(fileName) in binaryExt
}
