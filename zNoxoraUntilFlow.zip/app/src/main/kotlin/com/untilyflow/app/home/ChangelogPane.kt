package com.untilyflow.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class Release(val version: String, val notes: List<String>)

private fun pick(id: String, en: String): String = if (Lang.current.code == "id") id else en

private fun releases(): List<Release> = listOf(
    Release(
        "4.0.0",
        listOf(
            pick("Tampilan baru terang berwarna biru dengan bar tab bawah", "New light blue interface with a bottom tab bar"),
            pick("Perbaikan crash saat berpindah tab", "Fixed crash when switching tabs"),
            pick("Perbaikan crash saat membuka laporan error", "Fixed crash when opening the error report"),
            pick("Tab Changelog di Pengaturan", "Changelog tab in Settings"),
            pick("Tanda tangan APK V1, V2 dan V3", "APK signing with V1, V2 and V3"),
        ),
    ),
    Release(
        "3.0.0",
        listOf(
            pick("CodeMind: indeks dan pencarian kode proyek", "CodeMind: project code indexing and search"),
            pick("Agen AI untuk file dan terminal", "AI agent for files and terminal"),
            pick("Pemutar audio dan video bawaan", "Built-in audio and video player"),
            pick("Tile cepat di panel notifikasi", "Quick tile in the notification panel"),
        ),
    ),
    Release(
        "2.0.0",
        listOf(
            pick("Arus Kas dengan grafik donat dan batang", "Cash flow with donut and bar charts"),
            pick("Peramban dengan pemblokir iklan", "Browser with ad blocker"),
            pick("Server Localhost dari folder HP", "Localhost server from phone folders"),
            pick("Jelajah isi ZIP tanpa ekstrak", "Browse ZIP contents without extracting"),
        ),
    ),
    Release(
        "1.0.0",
        listOf(pick("Rilis pertama", "First Release")),
    ),
)

@Composable
fun ChangelogPane() {
    val list = releases()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
    ) {
        for ((i, release) in list.withIndex()) {
            Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp, start = 2.dp).nxEnter(i), verticalAlignment = Alignment.CenterVertically) {
                Text(release.version, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = NxText)
                if (i == 0) {
                    Text(
                        tr("New"),
                        Modifier.padding(start = 10.dp).clip(CircleShape).background(NxAccent).padding(horizontal = 10.dp, vertical = 3.dp),
                        fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = NxOnAccent,
                    )
                }
            }
            Column(
                Modifier.fillMaxWidth().nxEnter(i).nxGlass(20.dp).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                for (note in release.notes) {
                    Row(verticalAlignment = Alignment.Top) {
                        Box(Modifier.padding(top = 7.dp).size(6.dp).clip(CircleShape).background(NxAccent))
                        Text(note, Modifier.padding(start = 12.dp), fontSize = 14.sp)
                    }
                }
            }
            Box(Modifier.height(8.dp))
        }
        Box(Modifier.height(32.dp))
    }
}
