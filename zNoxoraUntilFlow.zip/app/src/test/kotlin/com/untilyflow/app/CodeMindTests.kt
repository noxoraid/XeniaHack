package com.untilyflow.app

import java.io.File
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue
import org.junit.Test

class CodeMindTests {
    private val sample = mapOf(
        "app/build.gradle.kts" to "plugins { id(\"x\") }\n",
        "app/src/main/kotlin/auth/AuthService.kt" to "package auth\n\nimport auth.TokenStore\n\nclass AuthService(private val store: TokenStore) {\n    fun login(user: String, password: String): Boolean {\n        return store.check(user, password)\n    }\n\n    fun logout(user: String) {\n        store.clear(user)\n    }\n}\n",
        "app/src/main/kotlin/auth/TokenStore.kt" to "package auth\n\nclass TokenStore {\n    fun check(user: String, password: String): Boolean = user.isNotEmpty()\n    fun clear(user: String) {}\n}\n",
        "app/src/main/kotlin/ui/LoginScreen.kt" to "package ui\n\nimport auth.AuthService\n\nfun LoginScreen(service: AuthService) {\n    service.login(\"a\", \"b\")\n}\n",
        "app/src/test/kotlin/auth/AuthServiceTest.kt" to "package auth\n\nclass AuthServiceTest {\n    fun loginWorks() {}\n}\n",
        "web/index.ts" to "import { helper } from './lib/helper';\nexport function boot() { helper(); }\n",
        "web/lib/helper.ts" to "export function helper() {}\n",
        "README.md" to "# Demo\n\nAuthentication demo project\n",
    )

    @Test
    fun jsonRoundTrip() {
        val text = "{\"a\":[1,2.5,\"x\\n\\u00e9\",null,true],\"b\":{\"c\":-3}}"
        val v = CmJson.parse(text)
        assertEquals(CmJson.write(v), CmJson.write(CmJson.parse(CmJson.write(v))))
        assertFailsWith<CmJsonError> { CmJson.parse("{\"a\":") }
        assertFailsWith<CmJsonError> { CmJson.parse("[1,]") }
        assertFailsWith<CmJsonError> { CmJson.parse("[".repeat(200)) }
    }

    @Test
    fun indexesProjectFiles() {
        val root = tempProject(sample)
        val (sink, run, _) = indexOf(root)
        assertEquals(sample.size, sink.fileCount())
        assertEquals(sample.size, run.misses)
        assertEquals("ready", sink.meta("state"))
        assertTrue(sink.symbolsOf("app/src/main/kotlin/auth/AuthService.kt").any { it.name == "AuthService" && it.kind == "class" })
        assertTrue(sink.symbolsOf("app/src/main/kotlin/auth/AuthService.kt").any { it.name == "login" && it.kind == "method" })
        assertTrue(sink.importsOf("app/src/main/kotlin/ui/LoginScreen.kt").contains("auth.AuthService"))
        assertEquals("markdown", sink.file("README.md")!!.lang)
    }

    @Test
    fun secondRunReusesEverything() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        val (_, run, _) = indexOf(root, sink)
        assertEquals(0, run.misses)
        assertEquals(sample.size, run.hits)
    }

    @Test
    fun changedFileIsAnalyzedAgainOnly() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        val f = File(root, "app/src/main/kotlin/auth/TokenStore.kt")
        f.writeText(f.readText() + "\nfun extra() {}\n")
        f.setLastModified(f.lastModified() + 5000)
        val (_, run, _) = indexOf(root, sink)
        assertEquals(1, run.misses)
        assertEquals(sample.size - 1, run.hits)
        assertTrue(sink.symbolsOf("app/src/main/kotlin/auth/TokenStore.kt").any { it.name == "extra" })
    }

    @Test
    fun touchedButIdenticalFileCountsAsHit() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        val f = File(root, "README.md")
        f.setLastModified(f.lastModified() + 9000)
        val (_, run, _) = indexOf(root, sink)
        assertEquals(0, run.misses)
        assertEquals(f.lastModified(), sink.file("README.md")!!.mtime)
    }

    @Test
    fun deletedFileLeavesIndex() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        File(root, "web/lib/helper.ts").delete()
        val (_, run, _) = indexOf(root, sink)
        assertEquals(1, run.removed)
        assertNull(sink.file("web/lib/helper.ts"))
        assertTrue(sink.findSymbols("helper", 10).none { it.file == "web/lib/helper.ts" })
    }

    @Test
    fun edgeCasesDoNotBreakIndexing() {
        val root = tempProject(sample + mapOf("empty.kt" to "", "deep/a/b/c/d/e/Deep.kt" to "class Deep\n"))
        File(root, "latin1.txt").writeBytes(byteArrayOf(0x63, 0xe9.toByte(), 0x66, 0xe9.toByte(), 0x0a))
        File(root, "blob.dat2").writeBytes(byteArrayOf(1, 0, 2, 0, 3))
        File(root, "huge.kt").writeText("val x = 1\n".repeat(200000))
        File(root, "pic.png").writeBytes(byteArrayOf(1, 2, 3))
        val (sink, run, progress) = indexOf(root)
        assertNotNull(sink.file("empty.kt"))
        assertEquals(0, sink.file("empty.kt")!!.lines)
        assertNotNull(sink.file("deep/a/b/c/d/e/Deep.kt"))
        assertNotNull(sink.file("latin1.txt"))
        assertNull(sink.file("blob.dat2"))
        assertNull(sink.file("huge.kt"))
        assertNull(sink.file("pic.png"))
        assertTrue(run.skipped >= 3)
        assertEquals(0, progress.errors)
    }

    @Test
    fun excludedFoldersAreSkipped() {
        val root = tempProject(sample + mapOf("node_modules/x/index.js" to "var a=1", "build/out.kt" to "class Out", "keep/a.min.js" to "x"))
        val (sink, _, _) = indexOf(root, cfg = CmConfig(excludes = listOf("node_modules", "build", "*.min.js")))
        assertNull(sink.file("node_modules/x/index.js"))
        assertNull(sink.file("build/out.kt"))
        assertNull(sink.file("keep/a.min.js"))
    }

    @Test
    fun readFailureIsPerFile() {
        val root = tempProject(sample)
        val (sink, run, progress) = indexOf(root, source = FaultySource("TokenStore.kt"))
        assertEquals(1, run.errors)
        assertEquals(1, progress.problems.size)
        assertEquals(sample.size - 1, sink.fileCount())
        assertEquals("ready", sink.meta("state"))
    }

    @Test
    fun stopLeavesInterruptedStateAndResumesFromCache() {
        val root = tempProject((1..50).associate { "f$it.kt" to "class C$it\n" })
        val sink = MemoryIndex()
        var calls = 0
        assertFailsWith<CmStopped> {
            CodeIndexer.run(DiskSource(), sink, root.absolutePath, CmConfig(), CmProgress(), { ++calls > 30 })
        }
        assertEquals("interrupted", sink.meta("state"))
        val before = sink.fileCount()
        assertTrue(before in 1..49)
        val (_, run, _) = indexOf(root, sink)
        assertEquals(50, sink.fileCount())
        assertTrue(run.hits >= before)
    }

    @Test
    fun manyFilesFinishQuickly() {
        val root = tempProject((1..600).associate { "p${it % 20}/F$it.kt" to "class F$it { fun run$it() {} }\n" })
        val t = System.currentTimeMillis()
        val (sink, _, _) = indexOf(root)
        assertEquals(600, sink.fileCount())
        assertTrue(System.currentTimeMillis() - t < 20000)
    }

    @Test
    fun partialUpdateOnlyTouchesGivenPaths() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        File(root, "README.md").delete()
        File(root, "web/index.ts").writeText("export function bootAgain() {}\n")
        val (_, run, _) = indexOf(root, sink, only = listOf("web/index.ts", "README.md"), force = true)
        assertEquals(1, run.removed)
        assertNull(sink.file("README.md"))
        assertTrue(sink.symbolsOf("web/index.ts").any { it.name == "bootAgain" })
        assertEquals(sample.size - 1, sink.fileCount())
    }

    @Test
    fun symbolSearchRanksExactFirst() {
        val root = tempProject(sample + mapOf("x/Other.kt" to "class AuthServiceFactory\n"))
        val (sink, _, _) = indexOf(root)
        val page = CodeQuery.symbols(sink, "authservice", null, 10, 0)
        assertEquals("AuthService", page.items.first().name)
        assertTrue(page.items.any { it.name == "AuthServiceFactory" })
        assertTrue(CodeQuery.symbols(sink, "nothingHere", null, 10, 0).items.isEmpty())
        assertTrue(CodeQuery.symbols(sink, "login", "method", 10, 0).items.all { it.kind == "method" })
    }

    @Test
    fun pathSearchAndGlob() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        assertEquals("app/src/main/kotlin/auth/TokenStore.kt", CodeQuery.paths(sink, "tokenstore", 5, 0).items.first())
        assertTrue(CodeQuery.paths(sink, "*.ts", 10, 0).items.containsAll(listOf("web/index.ts", "web/lib/helper.ts")))
    }

    @Test
    fun textSearchLiteralRegexAndPaging() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        val src = DiskSource()
        val r = root.absolutePath
        val hits = CodeQuery.text(sink, src, r, "store.check", true, false, null, 10, 0)
        assertEquals(1, hits.items.size)
        assertEquals(7, hits.items[0].line)
        assertTrue(CodeQuery.text(sink, src, r, "AUTHSERVICE", false, false, "*.kt", 50, 0).items.size >= 3)
        assertTrue(CodeQuery.text(sink, src, r, "AUTHSERVICE", true, false, null, 50, 0).items.none { it.text.contains("authservice") })
        assertTrue(CodeQuery.text(sink, src, r, "zzzzqqq", false, false, null, 10, 0).items.isEmpty())
        assertEquals(2, CodeQuery.text(sink, src, r, "fun ", false, false, null, 2, 0).items.size)
        assertTrue(CodeQuery.text(sink, src, r, "fun ", false, false, null, 2, 0).more)
        assertTrue(CodeQuery.text(sink, src, r, "fun\\s+log(in|out)", false, true, null, 10, 0).items.size >= 2)
        assertFailsWith<java.util.regex.PatternSyntaxException> { CodeQuery.text(sink, src, r, "(", false, true, null, 10, 0) }
    }

    @Test
    fun dependenciesResolveBothWays() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        val d = CodeQuery.dependencies(sink, "app/src/main/kotlin/ui/LoginScreen.kt")
        assertTrue(d.resolved.contains("app/src/main/kotlin/auth/AuthService.kt"))
        val back = CodeQuery.dependencies(sink, "app/src/main/kotlin/auth/AuthService.kt")
        assertTrue(back.importedBy.contains("app/src/main/kotlin/ui/LoginScreen.kt"))
        val ts = CodeQuery.dependencies(sink, "web/index.ts")
        assertEquals(listOf("web/lib/helper.ts"), ts.resolved)
        assertTrue(CodeQuery.dependencies(sink, "web/lib/helper.ts").importedBy.contains("web/index.ts"))
    }

    @Test
    fun rankingIsDeterministicAndFindsAuthFiles() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        val a = CodeQuery.rank(sink, "Perbaiki bug pada login AuthService", 10, emptyList())
        val b = CodeQuery.rank(sink, "Perbaiki bug pada login AuthService", 10, emptyList())
        assertEquals(a.map { it.path }, b.map { it.path })
        assertEquals("app/src/main/kotlin/auth/AuthService.kt", a.first().path)
        assertTrue(CodeQuery.rank(sink, "AuthService", 10, listOf("auth")).none { it.path.contains("/auth/") })
        assertTrue(CodeQuery.rank(sink, "zzzqqq", 10, emptyList()).isEmpty())
    }

    @Test
    fun contextPackKeepsConstraintsBudgetAndFlagsGaps() {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        val task = "Perbaiki bug pada login AuthService. Jangan mengubah API publik. Cek juga Missing.kt"
        val pack = ContextPack.build(sink, DiskSource(), root.absolutePath, "demo", task, 4000, emptyList())
        assertTrue(pack.text.contains("Jangan mengubah API publik"))
        assertTrue(pack.text.length <= 4000)
        assertTrue(pack.picked.any { it.path.endsWith("AuthService.kt") && it.role == "primary" })
        assertTrue(pack.picked.any { it.role == "test" })
        assertTrue(pack.picked.any { it.role == "config" })
        assertTrue(pack.missing.any { it.contains("Missing.kt") })
        assertTrue(pack.text.contains("fun login"))
        val tiny = ContextPack.build(sink, DiskSource(), root.absolutePath, "demo", task, 600, emptyList())
        assertTrue(tiny.text.length <= 600)
        val empty = ContextPack.build(MemoryIndex(), DiskSource(), root.absolutePath, "demo", task, 4000, emptyList())
        assertTrue(empty.missing.isNotEmpty())
        assertEquals(1, ContextPack.constraintsOf("Fix the bug. Do not touch the public API").size)
    }

    @Test
    fun trimConservativeRemovesOnlyRedundancy() {
        val text = "# A\n\nsame paragraph that is long enough to count\n\nsame paragraph that is long enough to count\n\n\n\n\nstatus: ready\nstatus: ready\n```kotlin\nval a = 1\n\n\n// keep\n```\n"
        val r = ContextTrim.run(text, false, emptyList())
        assertTrue(r.after.chars < r.before.chars)
        assertEquals(1, r.text.split("same paragraph that is long enough to count").size - 1)
        assertEquals(1, r.text.split("status: ready").size - 1)
        assertTrue(r.text.contains("// keep"))
        assertTrue(r.text.contains("val a = 1\n\n\n"))
        val expect = (r.before.chars - r.after.chars).toDouble() / r.before.chars * 100.0
        assertEquals(expect, r.percent, 0.0001)
    }

    @Test
    fun trimAggressiveHandlesCodeCarefully() {
        val code = "```kotlin\n/* Copyright 2020 License */\nval a = 1\n\n// note\nval b = \"// not a comment\"\n```\n```python\nx = 1\n\n# keep\n```\n"
        val r = ContextTrim.run(code, true, emptyList())
        assertFalse(r.text.contains("Copyright"))
        assertFalse(r.text.contains("// note"))
        assertTrue(r.text.contains("\"// not a comment\""))
        assertTrue(r.text.contains("x = 1\n\n# keep"))
        val raw = ContextTrim.run("```kotlin\nval s = \"\"\"\n// inside\n\"\"\"\n// outside\n```\n", true, emptyList())
        assertTrue(raw.text.contains("// inside"))
    }

    @Test
    fun trimReportsNoReductionHonestly() {
        val r = ContextTrim.run("one\ntwo\nthree\n", false, emptyList())
        assertEquals("one\ntwo\nthree\n", r.text)
        assertEquals(0.0, r.percent, 0.0)
        assertTrue(r.report().contains("No measurable reduction"))
        assertEquals(0, ContextTrim.run("", true, emptyList()).before.chars)
    }

    @Test
    fun trimExcludesFileSections() {
        val text = "### src/a.kt [primary]\nA body\n### src/b.kt [primary]\nB body\n### config.json\nC body\n"
        val r = ContextTrim.run(text, false, listOf("*.json", "b.kt"))
        assertTrue(r.text.contains("A body"))
        assertFalse(r.text.contains("B body"))
        assertFalse(r.text.contains("C body"))
    }

    private class FakeApi(val ctx: CmCtx, var allow: Boolean = true) : CodeMindApi {
        var updated = 0
        override fun projects(): List<CmProject> = listOf(ctx.project)
        override fun open(ref: String?): CmCtx {
            if (ref != null && ref != ctx.project.name && ref != ctx.project.id) throw CmToolError("Unknown project: $ref")
            return ctx
        }
        override fun canUpdate(): Boolean = allow
        override fun update(ctx: CmCtx, paths: List<String>, force: Boolean): String {
            updated++
            return "updated"
        }
    }

    private fun core(allow: Boolean = true): Pair<McpCore, FakeApi> {
        val root = tempProject(sample)
        val (sink, _, _) = indexOf(root)
        val api = FakeApi(CmCtx(CmProject("p1", "demo", root.absolutePath, "Internal", "ready", sink.fileCount(), 0L), sink, DiskSource()), allow)
        return McpCore(McpTools.build(api), "codemind", "1.0", { }) to api
    }

    @Suppress("UNCHECKED_CAST")
    private fun obj(text: String?): Map<String, Any?> = CmJson.parse(text!!) as Map<String, Any?>

    private fun call(c: McpCore, name: String, args: String): Map<String, Any?> =
        obj(c.handle("{\"jsonrpc\":\"2.0\",\"id\":7,\"method\":\"tools/call\",\"params\":{\"name\":\"$name\",\"arguments\":$args}}").body)

    @Suppress("UNCHECKED_CAST")
    private fun textOf(reply: Map<String, Any?>): String = ((reply["result"] as Map<String, Any?>)["content"] as List<Map<String, Any?>>)[0]["text"] as String

    private fun isError(reply: Map<String, Any?>): Boolean = (reply["result"] as Map<*, *>)["isError"] == true

    @Test
    fun mcpInitializeNegotiatesVersion() {
        val (c, _) = core()
        val ok = c.handle("{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"initialize\",\"params\":{\"protocolVersion\":\"2025-03-26\",\"capabilities\":{},\"clientInfo\":{\"name\":\"t\",\"version\":\"1\"}}}")
        assertTrue(ok.initialized)
        val result = obj(ok.body)["result"] as Map<*, *>
        assertEquals("2025-03-26", result["protocolVersion"])
        assertTrue((result["capabilities"] as Map<*, *>).containsKey("tools"))
        val newer = obj(c.handle("{\"jsonrpc\":\"2.0\",\"id\":2,\"method\":\"initialize\",\"params\":{\"protocolVersion\":\"2030-01-01\"}}").body)["result"] as Map<*, *>
        assertEquals("2025-06-18", newer["protocolVersion"])
        val missing = obj(c.handle("{\"jsonrpc\":\"2.0\",\"id\":3,\"method\":\"initialize\",\"params\":{}}").body)
        assertEquals(-32602L, (missing["error"] as Map<*, *>)["code"])
    }

    @Test
    fun mcpNotificationsPingAndErrors() {
        val (c, _) = core()
        assertEquals(202, c.handle("{\"jsonrpc\":\"2.0\",\"method\":\"notifications/initialized\"}").status)
        assertNull(c.handle("{\"jsonrpc\":\"2.0\",\"method\":\"notifications/initialized\"}").body)
        assertEquals(200, c.handle("{\"jsonrpc\":\"2.0\",\"id\":\"a\",\"method\":\"ping\"}").status)
        assertEquals(400, c.handle("{bad").status)
        assertEquals(-32700L, ((obj(c.handle("{bad").body))["error"] as Map<*, *>)["code"])
        assertEquals(-32601L, ((obj(c.handle("{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"nope\"}").body))["error"] as Map<*, *>)["code"])
        assertEquals(400, c.handle("{\"jsonrpc\":\"2.0\",\"id\":null,\"method\":\"ping\"}").status)
        assertEquals(400, c.handle("{\"jsonrpc\":\"1.0\",\"id\":1,\"method\":\"ping\"}").status)
        assertEquals(400, c.handle("[]").status)
        val batch = c.handle("[{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"ping\"},{\"jsonrpc\":\"2.0\",\"method\":\"notifications/initialized\"}]")
        assertEquals(1, (CmJson.parse(batch.body!!) as List<*>).size)
        assertEquals(202, c.handle("{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{}}").status)
    }

    @Test
    fun mcpToolsListHasAllTwelveWithSchemas() {
        val (c, _) = core()
        val tools = ((obj(c.handle("{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"tools/list\"}").body)["result"] as Map<*, *>)["tools"] as List<*>)
        val names = tools.map { (it as Map<*, *>)["name"] }
        assertEquals(
            setOf("search_code", "search_symbols", "get_file_summary", "get_symbol_info", "get_dependencies", "get_relevant_context", "update_codebase_memory", "optimize_context", "get_project_overview", "get_index_statistics", "list_indexed_projects", "get_file_metadata"),
            names.toSet(),
        )
        for (t in tools) {
            val m = t as Map<*, *>
            assertEquals("object", (m["inputSchema"] as Map<*, *>)["type"])
            assertTrue((m["description"] as String).isNotEmpty())
        }
    }

    @Test
    fun mcpToolsReturnRealResults() {
        val (c, _) = core()
        assertTrue(textOf(call(c, "search_symbols", "{\"query\":\"AuthService\"}")).contains("class AuthService"))
        assertEquals("No matches.", textOf(call(c, "search_code", "{\"query\":\"zzzqqq\"}")))
        assertTrue(textOf(call(c, "search_code", "{\"query\":\"store.check\"}")).contains("AuthService.kt:7"))
        assertTrue(textOf(call(c, "get_file_summary", "{\"path\":\"app/src/main/kotlin/auth/AuthService.kt\"}")).contains("class AuthService"))
        assertTrue(textOf(call(c, "get_symbol_info", "{\"name\":\"AuthService\"}")).contains("AuthService.kt:5"))
        assertTrue(textOf(call(c, "get_dependencies", "{\"path\":\"web/index.ts\"}")).contains("web/lib/helper.ts"))
        assertTrue(textOf(call(c, "get_relevant_context", "{\"task\":\"fix login in AuthService, do not change the public API\",\"budget_chars\":3000}")).contains("do not change the public API"))
        assertTrue(textOf(call(c, "get_project_overview", "{}")).contains("kotlin"))
        assertTrue(textOf(call(c, "get_index_statistics", "{}")).contains("Cache this run"))
        assertTrue(textOf(call(c, "list_indexed_projects", "{}")).contains("demo"))
        assertTrue(textOf(call(c, "get_file_metadata", "{\"path\":\"README.md\"}")).contains("status: unchanged"))
        val opt = textOf(call(c, "optimize_context", "{\"text\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaa\\n\\naaaaaaaaaaaaaaaaaaaaaaaaaaaa\\n\"}"))
        assertTrue(opt.contains("Reduction:"))
    }

    @Test
    fun mcpToolErrors() {
        val (c, api) = core(allow = false)
        assertTrue(isError(call(c, "search_code", "{}")))
        assertTrue(isError(call(c, "search_code", "{\"query\":5}")))
        assertTrue(isError(call(c, "search_code", "{\"query\":\"a\",\"limit\":500}")))
        assertTrue(isError(call(c, "search_code", "{\"query\":\"a\",\"bogus\":1}")))
        assertTrue(isError(call(c, "search_code", "{\"query\":\"(\",\"regex\":true}")))
        assertTrue(isError(call(c, "get_file_summary", "{\"path\":\"nope.kt\"}")))
        assertTrue(isError(call(c, "search_symbols", "{\"query\":\"a\",\"project\":\"other\"}")))
        assertTrue(isError(call(c, "update_codebase_memory", "{}")))
        assertEquals(0, api.updated)
        val unknown = call(c, "no_such_tool", "{}")
        assertEquals(-32602L, (unknown["error"] as Map<*, *>)["code"])
        api.allow = true
        assertEquals("updated", textOf(call(c, "update_codebase_memory", "{}")))
        assertEquals(1, api.updated)
    }

    @Test
    fun globMatching() {
        assertTrue(CmGlob.match("*.kt", "A.kt"))
        assertTrue(CmGlob.match("a?c", "abc"))
        assertFalse(CmGlob.match("*.kt", "A.java"))
        assertTrue(CmGlob.any(listOf("node_modules"), "web/node_modules/x/y.js"))
        assertFalse(CmGlob.any(listOf("node"), "web/node_modules/x"))
    }

    private class PathsSource(private val have: Set<String>) : CodeSource {
        var probes = 0

        override fun list(dir: String): List<CmEntry> = emptyList()

        override fun read(path: String, max: Int): ByteArray = ByteArray(0)

        override fun stamp(path: String): Long = -1L

        override fun exists(path: String): Boolean {
            probes++
            return path in have
        }
    }

    @Test
    fun rootClimbsToNearestMarker() {
        val src = PathsSource(setOf("/storage/emulated/0/Work/app/package.json", "/storage/emulated/0/Work/.git"))
        assertEquals("/storage/emulated/0/Work/app", CodeRoot.find(src, "/storage/emulated/0/Work/app/src/ui"))
        assertEquals("/storage/emulated/0/Work/app", CodeRoot.find(src, "/storage/emulated/0/Work/app"))
        assertEquals("/storage/emulated/0/Work", CodeRoot.find(src, "/storage/emulated/0/Work/docs"))
        for (m in CodeRoot.MARKERS) {
            assertEquals("/p/q", CodeRoot.find(PathsSource(setOf("/p/q/$m")), "/p/q/r/s"))
        }
    }

    @Test
    fun rootFallsBackToCwdWhenNoMarker() {
        val src = PathsSource(emptySet())
        assertNull(CodeRoot.find(src, "/storage/emulated/0/Work/app/src"))
        assertEquals("/storage/emulated/0/Work/app/src", CodeRoot.autoRoot(src, "/storage/emulated/0/Work/app/src"))
        assertEquals("/srv/site", CodeRoot.autoRoot(src, "/srv/site/"))
    }

    @Test
    fun rootClimbIsBounded() {
        val deep = "/a/b/c/d/e/f/g/h/i/j/k/l"
        val src = PathsSource(setOf("/a/.git"))
        assertNull(CodeRoot.find(src, deep))
        assertTrue(src.probes <= (CodeRoot.MAX_CLIMB + 1) * CodeRoot.MARKERS.size)
        assertEquals("/a", CodeRoot.find(PathsSource(setOf("/a/.git")), "/a/b/c"))
    }

    @Test
    fun broadRootsAreNeverAutoIndexed() {
        for (p in listOf("/", "/storage", "/storage/emulated", "/storage/emulated/0", "/storage/emulated/0/", "/storage/self/primary", "/sdcard", "/storage/1A2B-3C4D", "/storage/emulated/0/Download", "/storage/emulated/0/DCIM", "/home", "/home/rpg", "/root", "/data/user/0")) {
            assertTrue(CodeRoot.tooBroad(p), p)
            assertNull(CodeRoot.autoRoot(PathsSource(setOf("$p/.git", "/.git", "/storage/emulated/0/.git")), p), p)
        }
        assertFalse(CodeRoot.tooBroad("/storage/emulated/0/Work"))
        assertFalse(CodeRoot.tooBroad("/home/rpg/app"))
        assertFalse(CodeRoot.tooBroad("/root/site"))
    }

    @Test
    fun markerAtStorageRootDoesNotPullTheProjectUp() {
        val src = PathsSource(setOf("/storage/emulated/0/.git", "/.git"))
        assertNull(CodeRoot.find(src, "/storage/emulated/0/Work/app"))
        assertEquals("/storage/emulated/0/Work/app", CodeRoot.autoRoot(src, "/storage/emulated/0/Work/app"))
        assertEquals("/storage/emulated/0/Work/app", CodeRoot.autoRoot(src, "/storage/emulated/0/Work/app/../app"))
    }

    @Test
    fun brokenSourceCountsAsMissingMarker() {
        val boom = object : CodeSource {
            override fun list(dir: String): List<CmEntry> = emptyList()

            override fun read(path: String, max: Int): ByteArray = ByteArray(0)

            override fun stamp(path: String): Long = -1L

            override fun exists(path: String): Boolean = throw java.io.IOException("offline")
        }
        assertEquals("/srv/site", CodeRoot.autoRoot(boom, "/srv/site"))
    }

    @Test
    fun refreshThresholdsDifferForLocalAndRemote() {
        val now = 10_000_000L
        assertTrue(CodeAuto.refreshDue(true, 0L, now))
        assertFalse(CodeAuto.refreshDue(true, now - 59_000L, now))
        assertTrue(CodeAuto.refreshDue(true, now - 60_000L, now))
        assertFalse(CodeAuto.refreshDue(false, now - 60_000L, now))
        assertFalse(CodeAuto.refreshDue(false, now - 599_000L, now))
        assertTrue(CodeAuto.refreshDue(false, now - 600_000L, now))
        assertTrue(CodeAuto.refreshDue(false, now + 5_000L, now))
    }

    @Test
    fun smallProjectsGetNoBrief() {
        assertFalse(CodeAuto.briefWorth(14, 15))
        assertTrue(CodeAuto.briefWorth(15, 15))
        assertTrue(CodeAuto.briefWorth(1, 0))
        assertEquals(15, CodeAuto.MIN_FILES)
    }

    @Test
    fun onceGateAllowsEachKeyOnce() {
        val gate = CmOnce()
        assertTrue(gate.first("internal\u0000/a"))
        assertFalse(gate.first("internal\u0000/a"))
        assertTrue(gate.first("vps:x\u0000/a"))
        gate.clear()
        assertTrue(gate.first("internal\u0000/a"))
    }

    @Test
    fun briefNoteRoundTripsAndEstimatesTokens() {
        val n = CmBriefNote(1234L, "my\tproj\nx", 1601, 42, "sent")
        val back = CmBriefNote.decode(n.encode())
        assertNotNull(back)
        assertEquals(1234L, back!!.at)
        assertEquals("my proj x", back.project)
        assertEquals(1601, back.chars)
        assertEquals(401, back.tokens)
        assertEquals(42, back.files)
        assertEquals("sent", back.outcome)
        assertNull(CmBriefNote.decode("garbage"))
        assertNull(CmBriefNote.decode("a\tb\tc\td\te"))
        assertEquals(0, CmBriefNote(1L, "p", 0, 0, "small").tokens)
    }

    @Test
    fun apiTaskKeepsItsKeywords() {
        val t = CodeQuery.tokens("Perbaiki bug pada API publik login")
        assertTrue(t.contains("api"))
        assertTrue(t.contains("publik"))
        assertTrue(t.contains("login"))
        assertFalse(t.contains("bug"))
        val files = mapOf(
            "src/ApiClient.kt" to "package net\n\nclass ApiClient {\n    fun fetchApi(): String = \"\"\n}\n",
            "src/Screen.kt" to "package ui\n\nclass Screen {\n    fun draw() {}\n}\n",
            "src/Store.kt" to "package db\n\nclass Store {\n    fun save() {}\n}\n",
        )
        val (sink, _, _) = indexOf(tempProject(files))
        val ranked = CodeQuery.rank(sink, "fix the api", 5, emptyList())
        assertEquals("src/ApiClient.kt", ranked.first().path)
        assertTrue(CodeQuery.rank(sink, "api", 5, emptyList()).isNotEmpty())
    }
}
