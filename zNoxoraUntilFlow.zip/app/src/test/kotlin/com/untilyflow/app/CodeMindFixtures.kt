package com.untilyflow.app

import java.io.File
import java.io.FileInputStream

class MemoryIndex : CodeSink {
    private val files = java.util.TreeMap<String, CmFile>()
    private val syms = HashMap<String, List<CmSym>>()
    private val imps = HashMap<String, List<String>>()
    private val terms = HashMap<String, List<Pair<String, Int>>>()
    private val meta = HashMap<String, String>()

    override fun fileCount(): Int = files.size
    override fun file(path: String): CmFile? = files[path]
    override fun files(prefix: String, offset: Int, limit: Int): List<CmFile> =
        files.values.filter { it.path.startsWith(prefix) }.drop(offset).take(limit)
    override fun paths(): List<String> = files.keys.toList()
    override fun symbolsOf(path: String): List<CmSymbol> = (syms[path] ?: emptyList()).map { CmSymbol(path, it.name, it.kind, it.line) }
    override fun findSymbols(part: String, limit: Int): List<CmSymbol> {
        val out = ArrayList<CmSymbol>()
        for ((p, list) in syms) for (s in list) if (s.name.lowercase().contains(part.lowercase())) out.add(CmSymbol(p, s.name, s.kind, s.line))
        return out.take(limit)
    }
    override fun importsOf(path: String): List<String> = imps[path] ?: emptyList()
    override fun allImports(): List<Pair<String, String>> = imps.flatMap { (p, l) -> l.map { p to it } }
    override fun termHits(terms: List<String>): List<CmTermHit> {
        val out = ArrayList<CmTermHit>()
        for ((p, list) in this.terms) for ((t, n) in list) if (t in terms) out.add(CmTermHit(p, t, n))
        return out
    }
    override fun docFreq(terms: List<String>): Map<String, Int> {
        val out = HashMap<String, Int>()
        for (t in terms) out[t] = this.terms.values.count { l -> l.any { it.first == t } }
        return out
    }
    override fun stats(): CmStats = CmStats(
        files.size, syms.values.sumOf { it.size }, imps.values.sumOf { it.size }, terms.values.sumOf { it.size },
        files.values.sumOf { it.size }, 0, files.values.groupingBy { it.lang }.eachCount(),
    )
    override fun meta(key: String): String? = meta[key]
    override fun begin() {}
    override fun commit() {}
    override fun put(file: CmFile, symbols: List<CmSym>, imports: List<String>, terms: List<Pair<String, Int>>) {
        files[file.path] = file
        syms[file.path] = symbols
        imps[file.path] = imports
        this.terms[file.path] = terms
    }
    override fun touch(path: String, mtime: Long) {
        val f = files[path] ?: return
        files[path] = CmFile(f.path, f.lang, f.size, mtime, f.hash, f.lines, f.summary, f.indexedAt)
    }
    override fun remove(path: String) {
        files.remove(path)
        syms.remove(path)
        imps.remove(path)
        terms.remove(path)
    }
    override fun setMeta(key: String, value: String) {
        meta[key] = value
    }
    override fun wipe() {
        files.clear()
        syms.clear()
        imps.clear()
        terms.clear()
        meta.clear()
    }
}

open class DiskSource : CodeSource {
    override fun list(dir: String): List<CmEntry> {
        val arr = File(dir).listFiles() ?: throw java.io.IOException("Cannot read folder")
        return arr.map { CmEntry(it.name, it.isDirectory, if (it.isDirectory) 0L else it.length()) }
    }

    override fun read(path: String, max: Int): ByteArray {
        FileInputStream(File(path)).use { input ->
            val buf = ByteArray(max)
            var n = 0
            while (n < max) {
                val got = input.read(buf, n, max - n)
                if (got < 0) break
                n += got
            }
            return buf.copyOf(n)
        }
    }

    override fun stamp(path: String): Long = File(path).lastModified()

    override fun exists(path: String): Boolean = File(path).exists()
}

class FaultySource(private val bad: String) : DiskSource() {
    override fun read(path: String, max: Int): ByteArray {
        if (path.endsWith(bad)) throw java.io.IOException("denied")
        return super.read(path, max)
    }
}

fun tempProject(files: Map<String, String>): File {
    val root = java.nio.file.Files.createTempDirectory("cm").toFile()
    for ((p, c) in files) {
        val f = File(root, p)
        f.parentFile.mkdirs()
        f.writeText(c)
    }
    return root
}

fun indexOf(root: File, sink: CodeSink = MemoryIndex(), cfg: CmConfig = CmConfig(), source: CodeSource = DiskSource(), force: Boolean = false, only: List<String>? = null): Triple<CodeSink, CmRun, CmProgress> {
    val progress = CmProgress()
    val run = CodeIndexer.run(source, sink, root.absolutePath, cfg, progress, { false }, only, force)
    return Triple(sink, run, progress)
}
