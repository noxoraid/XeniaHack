# Dokumen rancangan dan prompt

Urutan baca dan pakai:

1. konsep-v6-pro.md: konsep, target yang harus diukur, daftar bug, dan urutan fase.
2. prompt-v6-pro.md: prompt upgrade v6-pro bertahap untuk semua permukaan AI (terminal, AI File, VPS, provider).
3. prompt-keamanan-tahap-1.md: prompt keamanan tahap 1 (rahasia keluar dari repo, R8, Keystore). Sudah digabung ke prompt berikutnya.
4. prompt-gabungan-keamanan-perintah.md: versi gabungan keamanan dan perintah, pendahulu prompt lengkap.
5. prompt-nx-lengkap-hp-vps.md: prompt terbaru dan paling lengkap untuk perintah nx di HP dan VPS, dengan uji penerimaan per tahap. Pakai yang ini.

Catatan: prompt nomor 3 dan 4 tetap disimpan sebagai riwayat. Jangan dijalankan bersamaan dengan nomor 5, karena isinya tumpang tindih.

Status saat ini: semua dokumen ini rancangan. Belum ada yang dibuktikan di HP atau VPS sungguhan.
