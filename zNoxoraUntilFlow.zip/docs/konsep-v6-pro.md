# Konsep v6-pro (CodeMind + Agen AI)

Dokumen ini rancangan, belum kode. Angka hemat token di sini adalah target yang harus dibuktikan dengan pengukuran, bukan janji.

## 1. Tujuan

- Agen AI di HP bisa mengerjakan proyek nyata (baca, edit, audit error, jalankan tool) tanpa PC.
- Pemakaian token turun drastis pada tugas yang membaca banyak kode, dengan angka yang diukur dari respons penyedia.
- Proyek besar bisa selesai bertahap, walau melebihi batas output dan konteks satu model.
- Fungsi harus bekerja nyata dan responsif, tidak dibebani aturan yang kaku.

## 2. Target yang harus diukur

Setiap fase wajib menunjukkan angka sebelum dan sesudah pada tugas yang sama:

- Token input dan output per run, dari field `usage` respons penyedia (bukan estimasi karakter).
- Jumlah langkah tool per tugas.
- Jumlah request per tugas (untuk limit RPM).
- Waktu sampai jawaban pertama dan total.

Contoh target yang ingin dicapai (belum terbukti): membaca proyek 200 file untuk satu pertanyaan, dari ratusan ribu token ke belasan ribu, lewat pencarian simbol dan pembacaan per rentang baris. Angka "150x" hanya boleh ditulis kalau sudah ada hasil ukur nyata.

## 3. Lapisan hemat token

1. **Retrieval per simbol.** Agen menerima daftar simbol (nama, file, baris, tanda tangan), bukan file utuh.
2. **Baca per rentang.** `nx read <path> <dari> <sampai>` untuk isi fungsi, dengan batas karakter yang sudah ada.
3. **Dedup per sesi.** App mencatat hash file yang sudah dikirim. Kalau tidak berubah, kirim "sudah dikirim di langkah N".
4. **Pemadatan keluaran tool.** Hasil `grep` dikelompokkan per file, duplikat dibuang, dibatasi jumlahnya. Error dipotong ke baris relevan.
5. **Ringkasan deterministik per file.** Dibuat dari indeks, diperbarui saat hash berubah. Tanpa memanggil model.
6. **Edit berbasis patch.** Perubahan kecil per potongan, bukan menulis ulang file utuh.
7. **Rencana di file.** `PLAN.md` berisi langkah dan status. Sesi baru mulai dari rencana, bukan dari riwayat chat.
8. **Pemotongan riwayat.** Setelah langkah selesai, ringkasannya disimpan dan riwayat lama dibuang dari konteks.

## 4. Bug dan error yang sudah teramati

Dari screenshot dan pembacaan kode:

1. **`Balasan terpotong atau bukan JSON valid`** muncul saat balasan model terpotong di tengah tool call. Pesannya tidak membedakan batas panjang dari JSON rusak.
2. **`Model mengembalikan balasan kosong`** muncul setelah percobaan ulang. Penyebab belum pasti.
3. **`java.io.EOFException`** muncul saat membuat file `alok.txt` dengan 999 baris. Stream kemungkinan terputus atau kosong. Belum dipastikan.
4. **`Permintaan gagal (502)`** dari sisi penyedia (Cloudflare, origin kelebihan beban). Harus ditampilkan sebagai "penyedia sedang sibuk, coba lagi", bukan error mentah.
5. **`max_tokens: 4096` hardcoded** di `AiClient.kt` jalur Anthropic. Jalur OpenAI-compatible (dipakai DeepSeek) tidak mengirim `max_tokens` sama sekali, jadi batasnya default penyedia.
6. **Tidak membaca `finish_reason`.** Balasan yang kena batas panjang tidak dikenali sebagai terpotong.
7. **Penghapusan massal tanpa konfirmasi.** Perintah seperti `rm app.js index.html README.md style.css` dijalankan dari satu permintaan "hapus semua file". Di Android tidak ada tempat sampah, jadi file hilang permanen.
8. **Agen mengarang sumber token.** Agen menyebut `platform.openai.com` untuk model DeepSeek dan mengaku tidak punya akses data. Jawaban seperti ini harus ditolak atau diberi tanda tidak tahu.
9. **Pemakaian token tidak tercatat.** Dashboard hanya menampilkan estimasi karakter/4 untuk brief CodeMind.
10. **`nx cm` tidak dikenali** saat One Tool mati (mode non-compact) dan tidak tersedia di AgentConsole (agen file).
11. **Auto-reconnect VPS tidak ada.** Port forward mati saat SSH putus, dan alamat MCP di UI tetap tampil.
12. **Tidak ada perintah `nx fetch`.** Agen tidak bisa mengambil URL secara langsung dari HP.
13. **Tidak ada lampiran.** Agen belum bisa menerima foto, video, atau zip sebagai input.

## 5. Fitur yang diminta

- Salin, tempel, unduh, dan unggah teks, gambar, video, dan zip dari dan ke agen.
- Penghapusan file dan folder massal wajib meminta konfirmasi yang menyebut setiap nama.
- Tugas panjang berjalan lewat `PLAN.md` dan bisa dilanjutkan di sesi berikutnya.
- Pesan error yang jelas untuk setiap jenis kegagalan di butir 4.

## 6. Urutan kerja

- **Fase 0:** build APK dan jalankan tes JVM. Belum ada yang pernah dikompilasi di lingkungan pembuatnya.
- **Fase 1:** baca `usage` dan `finish_reason` dari respons penyedia, catat per run, perbaiki pesan error di butir 1 sampai 4, dan tambahkan konfirmasi hapus massal (butir 7).
- **Fase 2:** `max_tokens` per penyedia, dan lanjutkan balasan yang terpotong.
- **Fase 3:** retrieval per simbol, dedup, dan pemadatan keluaran tool, diukur dengan tugas yang sama.
- **Fase 4:** `PLAN.md`, lampiran, `nx fetch` dengan penjaga alamat lokal, dan perbaikan VPS.

## 7. Prompt untuk agen coding

Salin blok di bawah ke agen coding yang kamu pakai:

```
Kamu mengerjakan aplikasi Android "UntilyFlow" (Kotlin, Jetpack Compose) di repo ini.

Baca dulu CLAUDE.md dan CODEMIND.md, ikuti semua aturannya.

Tugas: kerjakan Fase 1 dari konsep-v6-pro.md, tidak lebih.

1. Baca `usage` (prompt dan completion token) dan `finish_reason` dari respons penyedia di jalur OpenAI-compatible dan Anthropic. Catat per run di log ringkas. Jangan menampilkan estimasi sebagai angka pasti.
2. Bedakan tiga kasus dengan pesan berbeda: balasan terpotong karena batas panjang (finish_reason = length), balasan kosong dari penyedia, dan JSON tool call rusak. Tampilkan teks pesan lewat tr() dan tambahkan ke LangEn dan LangId.
3. Untuk HTTP 502 dan 503 dari penyedia, tampilkan pesan "penyedia sedang sibuk, coba lagi" dan jangan tampilkan body mentah.
4. Penghapusan file atau folder lebih dari satu item wajib meminta konfirmasi yang menyebut setiap nama. Jangan jalankan rm secara massal dari satu permintaan tanpa konfirmasi.
5. Tambahkan tes JVM untuk logika pemilihan pesan error dan konfirmasi hapus di inti non-Android. Jalankan tools/codemind-test/run.sh kalau kotlinc tersedia.

Aturan:
- Logika murni di inti non-Android, tambah tes di CodeMindTests.kt atau file tes baru.
- Jangan hapus tool MCP, perintah nx, atau pengaturan yang sudah ada.
- Jangan tulis komentar di kode.
- Jangan refactor di luar daftar ini.
- Jangan klaim sukses compile atau test kalau tidak dijalankan.

Laporan akhir: daftar file yang diubah, apa yang benar-benar diverifikasi (tes JVM atau tidak), apa yang belum, dan bukti angka usage yang tercatat dari satu run nyata kalau tersedia.
```

## 8. Yang belum diputuskan

- Apakah `nx fetch` boleh ke domain mana saja, atau minta persetujuan per domain.
- Batas output default per penyedia, dicek dari dokumentasi masing-masing.
- Apakah ringkasan per file dibuat saat indeks atau saat dibutuhkan.
