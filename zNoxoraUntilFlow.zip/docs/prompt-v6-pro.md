Kamu mengerjakan aplikasi Android "UntilyFlow" (Kotlin, Jetpack Compose) di repo ini. Tugas: upgrade ke v6-pro, yaitu hemat token, pesan error yang jelas, dan agen yang bisa menyelesaikan proyek besar secara bertahap. Berlaku untuk SEMUA permukaan AI: agen terminal (TermAgent dan OneTool), AI File (AgentSheet dan AgentConsole), AI VPS (SSH), dan semua jalur provider (AiClient dan AiWire, termasuk OpenAI-compatible, Anthropic, dan Gemini).

Baca dulu CLAUDE.md, CODEMIND.md, dan konsep-v6-pro.md. Ikuti semua aturannya.

## Aturan wajib

- Kerjakan per tahap. Setelah tiap tahap selesai, berhenti, laporkan, dan tunggu konfirmasi sebelum lanjut. Jangan mengerjakan dua tahap sekaligus.
- Jangan hapus tool MCP, perintah `nx` (termasuk `nx cm`), atau pengaturan yang sudah ada. Fitur yang sudah ada harus tetap bekerja.
- Jangan menulis komentar di kode.
- Jangan refactor di luar tahap yang sedang dikerjakan.
- Logika murni ditaruh di inti non-Android supaya bisa dites di JVM. Tambahkan tes di CodeMindTests.kt atau file tes baru yang sesuai.
- Semua teks UI lewat tr(), dan tambahkan kuncinya ke LangEn dan LangId.
- Pengaturan baru lewat CmPrefs atau prefs yang sudah ada di modulnya, bukan Cfg, kecuali pengaturan itu memang milik Cfg.
- Jangan ubah format keluaran scanner. Kalau menyentuh codescan.cpp, cadangan Kotlin harus identik.
- Simbol itu pencocokan pola, bukan AST. Jangan menyebut AST.
- Jangan klaim compile atau tes lulus kalau tidak dijalankan. Tulis dengan jelas apa yang diverifikasi dan apa yang tidak.
- Kalau ada hal yang tidak pasti (misalnya format field usage penyedia), cek kodenya atau dokumentasi resminya dulu. Jangan menebak.

## Tahap 0: peta dan laporan (tanpa edit)

Petakan semua jalur AI dan tulis laporannya:
- Di mana request dibentuk untuk tiap provider, dan apakah `max_tokens` dikirim.
- Di mana respons stream dibaca, dan apa yang terjadi saat stream kosong atau terputus (cari sumber EOFException).
- Di mana tool call diurai, dan pesan "Balasan terpotong atau bukan JSON valid" dihasilkan.
- Di mana pesan "Model mengembalikan balasan kosong" dihasilkan.
- Di mana perintah hapus dijalankan, dan apakah ada konfirmasi.
- Bagaimana toolbox non-compact dibuat, dan apakah `nx cm` bisa dijalankan dari AgentConsole.
- Bagaimana Vps.forwardLoopback dan unforwardLoopback menangani SSH putus.
- Apakah ada tempat yang mencatat usage token dari respons penyedia.

Laporkan temuan itu dan berhenti.

## Tahap 1: ukur dan perjelas error

1. Baca `usage` (prompt dan completion token) dari respons di semua jalur provider yang menyediakannya. Simpan per run di log ringkas, dengan field: waktu, permukaan (terminal, file, vps), provider, model, token input, token output, jumlah langkah tool, dan hasil. Jangan tampilkan estimasi karakter sebagai angka pasti.
2. Baca `finish_reason` (OpenAI-compatible) atau `stop_reason` (Anthropic) dan bedakan kasus:
   - balasan terpotong karena batas panjang: pesan "balasan kepotong karena batas panjang output", dan tawarkan lanjutkan
   - balasan kosong dari penyedia: pesan "penyedia tidak mengirim isi, coba lagi"
   - tool call JSON rusak: pesan yang sekarang, tetapi jelas bahwa ini bukan batas panjang
3. HTTP 502 dan 503 dari penyedia: "penyedia sedang sibuk, coba lagi". Jangan tampilkan body mentah.
4. EOFException saat membaca stream: tangkap, bedakan dari kasus lain, dan tampilkan pesan yang jelas. Jangan menutupinya.
5. Agen tidak boleh mengarang sumber data. Kalau ditanya soal token atau akun, dan app tidak punya datanya, jawabannya harus jujur bahwa app tidak punya datanya. Tambahkan instruksi ini ke system prompt agen.
6. Penghapusan file atau folder yang lebih dari satu item wajib meminta konfirmasi yang menyebut setiap nama, lewat jalur ApprovalBoard yang sudah ada. Berlaku untuk rm, rmdir, dan perintah sejenis, di semua permukaan.
7. Tes JVM untuk logika pemilihan pesan dan logika konfirmasi hapus.

Laporkan dan berhenti.

## Tahap 2: batas output dan lanjutkan

1. `max_tokens` menjadi pengaturan per penyedia, dengan default yang wajar. Di jalur OpenAI-compatible, kirim `max_tokens` secara eksplisit kalau belum ada. Jangan membuat balasan melebihi batas output yang diketahui untuk model itu.
2. Extra body tetap digabung, dan nilainya boleh menimpa default.
3. Kalau balasan terpotong karena batas, tawarkan tombol lanjutkan yang meminta sisa output dari titik terpotong. Jangan memulai ulang dari nol dan jangan menulis file setengah jadi.
4. Tes JVM untuk logika lanjutkan.

Laporkan dan berhenti.

## Tahap 3: hemat konteks di semua permukaan

Terapkan ke terminal, AI File, dan AI VPS dengan logika yang sama, bukan tiga versi berbeda:

1. Pencarian simbol: agen menerima daftar simbol (nama, file, baris, tanda tangan) lewat `nx sym` dan `nx find`. Isi fungsi hanya lewat `nx read <path> <dari> <sampai>`. Pakai CodeQuery dan CodeScan yang sudah ada.
2. Dedup per sesi: catat hash file yang sudah dikirim ke model. Kalau file yang sama diminta lagi dan tidak berubah, kirim "sudah dikirim di langkah N, tidak berubah".
3. Pemadatan keluaran tool: hasil grep dikelompokkan per file, duplikat dibuang, batas jumlah baris diterapkan. Error dipotong ke baris yang relevan.
4. Ringkasan deterministik per file, dibuat dari indeks dan diperbarui hanya saat hash berubah. Tanpa memanggil model.
5. Pengukuran: bandingkan token dan jumlah langkah untuk tugas yang sama dengan dan tanpa fitur ini. Catat hasilnya di log dan laporkan angkanya. Jangan tulis angka hemat di UI tanpa pembanding nyata.
6. Brief CodeMind tetap berjalan seperti sebelumnya.

Laporkan angka sebelum dan sesudah, dan berhenti.

## Tahap 4: rencana, lampiran, dan VPS

1. PLAN.md: tugas panjang menulis rencana berisi langkah dan statusnya ke file. Sesi baru membaca PLAN.md, bukan riwayat chat. Riwayat lama bisa dipotong setelah ringkasannya disimpan.
2. Lampiran: agen bisa menerima dan mengirim teks, gambar, video, dan zip dari dan ke app. Batas ukuran dan tipe file wajib jelas, dan file besar tidak boleh dikirim penuh ke model.
3. `nx fetch <url>`: GET langsung dari proses app, bukan lewat WebView. Hanya http dan https. Tolak alamat 127.0.0.1, localhost, rentang privat (10.x, 172.16–31.x, 192.168.x), dan link-local. Ada timeout, batas ukuran respons, dan HTML diubah jadi teks. Domain baru minta persetujuan lewat ApprovalBoard, atau tidak, sesuai keputusan pemilik. Kalau keputusan belum ada, tandai sebagai pertanyaan terbuka dan jangan memilih sendiri.
4. Nx cm dan AgentConsole: pastikan `nx cm` bisa dijalankan dari AgentConsole, dan toolbox non-compact tidak menyebut perintah yang tidak bisa dijalankan.
5. VPS: Vps.forwardLoopback perlu auto-reconnect saat SSH putus, memasang ulang forward yang hilang, dan menghapus alamat MCP lama dari UI kalau forward tidak hidup. Beberapa forward per VPS harus bebas konflik port. Port remote yang sama dua kali harus ditolak dengan pesan yang jelas.

Laporkan dan berhenti.

## Format laporan di tiap tahap

- Daftar file yang diubah.
- Apa yang diverifikasi (tes JVM dijalankan atau tidak, hasilnya apa).
- Apa yang belum diverifikasi dan perlu dicoba di perangkat (misalnya build APK, stream provider sungguhan, lampiran).
- Angka usage dari run nyata, kalau ada.
- Pertanyaan terbuka yang perlu keputusan pemilik.
