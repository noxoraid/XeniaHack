Kamu mengerjakan aplikasi Android "UntilyFlow" (Kotlin, Jetpack Compose, C++ lewat CMake) di repo ini.

Tugas: buat set perintah `nx` lengkap yang berjalan nyata di HP (tanpa VPS) dan di VPS (lewat SSH). Setiap perintah dianggap selesai hanya kalau lolos uji penerimaannya. Tidak ada perintah yang dianggap "sudah" karena ada di daftar.

Baca dulu CLAUDE.md, CODEMIND.md, dan konsep-v6-pro.md. Ikuti semua aturannya.

## Kondisi awal (sudah diverifikasi dari kode)

Perintah `nx` yang ada sekarang di `onetool/OneTool.kt`: `read`, `ls`, `find`, `grep`, `sh`, `cm`, `web`, `text`, `js`.

Yang TIDAK ada: `du`, `tree`, `stat`, `zip`, `unzip`, `edit`, `write`, `mv`, `cp`, `rm`, `mkdir`, `hash`, `diff`, `json`, `fetch`, `env`, `help`.

Jalur eksekusi:
- Lokal: `terminal/PhoneShell.kt` (`PhoneShell.run`), shell terbatas di HP.
- VPS: `ssh/Vps.kt`, dengan `exec(script)` dan SFTP (`openSftp`). Untuk VPS, pakai `exec` dan SFTP, bukan `sh` bawaan HP.
- Antarmuka target: `terminal/AgentTarget.kt`.

Akibatnya sudah terlihat di screenshot: `nx sh 'toybox du ...'` ditolak sebagai "Unknown command", dan `nx ls` tidak menghitung ukuran folder.

## Aturan wajib

- Jangan hapus tool MCP, `nx cm`, atau fitur yang sudah ada.
- Jangan menulis komentar di kode.
- Semua teks UI lewat tr(), tambahkan kuncinya ke LangEn dan LangId.
- Pengaturan baru lewat CmPrefs atau prefs modul yang relevan, bukan Cfg.
- Logika murni di inti non-Android, dites di JVM.
- Jangan cetak password, API key, atau isi keystore di laporan.
- Jangan klaim sukses. Setiap klaim harus disertai bukti (output tes atau log).
- Kalau sebuah perintah tidak bisa dibuat di HP (misalnya `node` atau `python` tidak tersedia), jangan dipalsukan. Tandai "tidak tersedia di HP" dan jelaskan.

## Gerbang per tahap

Kerjakan satu tahap per run. Setelah tiap tahap, berhenti, tulis laporan dengan bukti, dan tunggu konfirmasi.

### Tahap 1: fondasi dan keamanan

1. Pindahkan `storePassword` dan `keyPassword` dari `app/build.gradle.kts` ke `~/.gradle/gradle.properties` atau environment variable (`NOXORA_STORE_PASSWORD`, `NOXORA_KEY_PASSWORD`, `NOXORA_KEYSTORE_PATH`). Tambahkan `*.jks`, `*.keystore`, dan `keystore.properties` ke `.gitignore`.
2. Aktifkan `isMinifyEnabled = true` dan `isShrinkResources = true` di release, dengan `proguard-android-optimize.txt` dan `proguard-rules.pro`. Setiap `keep` harus ada alasannya di kode. Jangan pakai `-dontobfuscate` atau `keep` lebar hanya agar build lolos.
3. Simpan rahasia (API key di AiStore dan AiProfile, password dan kunci SSH VPS, token MCP) lewat `SecretBox` berbasis AES-GCM dengan kunci Android Keystore. Migrasi dari teks biasa wajib: baca data lama, simpan ulang terenkripsi, dan jangan kehilangan key.
4. Tulis `nx help`: mencetak daftar perintah, satu baris deskripsi, dan kebutuhan (lokal, butuh VPS, atau butuh internet).
5. Penghapusan (rm, rmdir, mv yang menimpa) lebih dari satu item wajib konfirmasi yang menyebut setiap nama lewat ApprovalBoard. Target akar storage (`/`, `/storage`, `/storage/emulated/0`, `/sdcard`) dan folder media tingkat atas (Download, DCIM, Documents, dst.) ditolak, tanpa bisa dikonfirmasi.

Uji penerimaan tahap 1:
- `nx help` mencetak semua perintah di tahap ini dan tahap berikutnya dengan kebutuhannya.
- Tes JVM untuk migrasi `SecretBox` (data lama terbaca, data baru terenkripsi, data rusak ditolak) dan untuk aturan penolakan path.
- `assembleRelease` berhasil dan `mapping.txt` menunjukkan rename, atau catat kalau tidak bisa dijalankan.
- Di HP sungguhan (dicek pemilik): upgrade dari versi lama dengan API key tersimpan tidak kehilangan key.

### Tahap 2: deteksi kemampuan (`nx env`)

`nx env` mencetak ringkasan pendek dan dicache per sesi:
- Lokal: perintah nx yang tersedia, perintah shell bawaan yang dikenali (dicek dengan probe ringan), dan keberadaan `node`, `python`, `git`, `zip`, `unzip`.
- VPS: tidak dikonfigurasi, dikonfigurasi tapi putus, atau tersambung. Kalau tersambung: OS, versi shell, dan keberadaan `du`, `tar`, `zip`, `node`, `python3`, `git`.
- Internet: tersedia atau tidak (cek status jaringan sistem, jangan mengunduh data besar).
- CodeMind: jumlah file terindeks dan umur indeks.
- WebView: sudah dibuka atau belum.
- Cache diperbarui saat VPS tersambung atau putus, dan saat internet berubah.

Agen wajib memanggil `nx env` sebelum perintah pertama di sesi. Perintah yang butuh VPS tidak dicoba kalau VPS tidak tersambung. Agen langsung memakai padanan lokal atau memberi tahu pengguna.

Uji penerimaan tahap 2:
- Dengan VPS dicabut (nonaktif), `nx env` menunjukkan "tidak tersambung" dan agen tidak mencoba perintah VPS.
- Dengan internet dimatikan, `nx env` menunjukkan internet tidak tersedia.
- Tes JVM untuk logika cache dan pemilihan padanan.

### Tahap 3: perintah baca di HP (dan VPS dengan padanan yang sama)

Nama dan keluaran sama di kedua target. Implementasi lokal di Kotlin; implementasi VPS lewat `exec` atau SFTP.

- `nx ls [path]`: daftar isi, ukuran file, jumlah item per folder. Sudah ada, tambah jumlah item dan urutan.
- `nx du [path]`: ukuran rekursif per folder dan total, dihitung di dalam app dengan batas kedalaman dan batas waktu, diurutkan dari terbesar. Di VPS memakai `du -sb` atau setara, dan kalau tidak ada, pakai hitungan SFTP.
- `nx tree [path] [kedalaman]`: pohon dengan batas kedalaman dan batas jumlah item, dan output dipotong dengan pesan jelas kalau terlalu panjang.
- `nx stat <path>`: tipe, ukuran, waktu ubah, izin.
- `nx find <nama> [path]`: sudah ada, tambah pengelompokan per folder dan batas hasil.
- `nx grep <teks> [path]`: sudah ada, tambah pengelompokan per file dan batas hasil.
- `nx read <path> [dari] [sampai]`: sudah ada, tambah batas karakter dan pesan lanjutan yang jelas.
- `nx head <path> [n]` dan `nx tail <path> [n]`.
- `nx hash <path>` (SHA-256) dan `nx diff <a> <b>`.
- `nx json <path> [kunci]`: nilai JSON tanpa memuat seluruh file.

Uji penerimaan tahap 3:
- Di HP: folder berisi 3 item dengan ukuran diketahui. `nx du` mengembalikan total yang sama dengan jumlah ukuran file (tes JVM untuk fungsi hitung, dan cek manual di perangkat).
- Di VPS (dicek pemilik): `nx du /home` mengembalikan angka yang sama dengan `du -sb /home` di SSH.
- `nx find` dan `nx grep` tidak mengembalikan lebih dari batas, dan pesan terpotong menyebut cara melanjutkan.

### Tahap 4: perubahan file (dengan konfirmasi)

- `nx write <path>`: tulis baru. Kalau file sudah ada, minta konfirmasi dengan nama file.
- `nx edit <path>`: patch potongan kecil (old_str harus tepat satu kali, new_str pengganti). Tidak menulis ulang file utuh.
- `nx mkdir <path>`.
- `nx cp <src> <dst>` dan `nx mv <src> <dst>`: timpa butuh konfirmasi.
- `nx rm <path>`: konfirmasi per nama. Tidak ada hapus massal tanpa daftar nama.
- `nx zip <sumber> <tujuan.zip>` dan `nx unzip <zip> [tujuan]`: dibuat di dalam app di HP. Di VPS pakai `zip` dan `unzip` kalau ada, kalau tidak ada tandai tidak tersedia. Unzip wajib memeriksa path (zip slip) dan batas ukuran.

Uji penerimaan tahap 4:
- Hapus satu file: konfirmasi muncul dengan namanya. Tanpa konfirmasi, file tidak terhapus.
- Hapus tiga file sekaligus: konfirmasi menyebut ketiga nama.
- Target akar storage ditolak dengan pesan jelas.
- Tes JVM untuk zip slip (entri `../` ditolak) dan untuk edit (old_str tidak ada atau lebih dari satu kali ditolak).

### Tahap 5: jaringan (`nx fetch`)

- `nx fetch <url>`: GET dari proses app. Hanya http dan https. Tolak 127.0.0.1, localhost, `[::1]`, 10.x, 172.16–31.x, 192.168.x, dan link-local. Timeout dan batas ukuran. HTML diubah jadi teks.
- Domain baru minta persetujuan lewat ApprovalBoard. Keputusan pemilik soal "boleh semua domain atau per domain" belum ada. Tandai sebagai pertanyaan terbuka, jangan memutuskan sendiri.

Uji penerimaan tahap 5:
- Tes JVM: 127.0.0.1, localhost, 192.168.1.1, dan 169.254.1.1 ditolak sebelum koneksi dibuka.
- Di HP (dicek pemilik): satu URL publik dikembalikan sebagai teks dengan batas.

### Tahap 6: perintah VPS dan kestabilan SSH

Aktif hanya kalau VPS tersambung. Target VPS memakai nama perintah yang sama dengan HP.

- `nx sh <perintah>` di VPS: `exec` penuh. Perintah yang menghapus, menimpa, atau mengubah izin di luar folder kerja butuh persetujuan.
- `nx node <file>` dan `nx py <file>`: hanya kalau `nx env` menunjukkan tersedia. Batas waktu dan batas output wajib.
- `nx install <paket>`: VPS saja, dengan persetujuan. Di HP ditandai tidak tersedia.
- Auto-reconnect: saat SSH putus, forward port dipasang ulang otomatis dengan backoff. Alamat MCP di UI dihapus kalau forward tidak hidup.
- Beberapa forward per VPS bebas konflik. Port remote yang sama dua kali ditolak dengan pesan jelas.
- `nx cm index` di VPS: throttle lebih lama, tidak memblokir run agen, hanya saat tersambung.

Uji penerimaan tahap 6 (dicek pemilik di VPS nyata):
- Putus koneksi SSH (matikan jaringan sebentar), lalu pulihkan. Forward kembali hidup tanpa intervensi.
- `nx sh 'echo ok'` mengembalikan `ok`.
- `nx node` atau `nx py` dengan file kecil mengembalikan keluaran, atau pesan tidak tersedia kalau runtime tidak ada.

### Tahap 7: format hasil dan retry

- Tidak ada tabel dengan pipa `|` di chat. Pakai daftar satu baris per item: nama, ukuran dalam satuan manusia (KB, MB, GB), dan keterangan.
- Urutan dari terbesar. Total di baris pertama.
- Folder yang belum dihitung ditandai "belum dihitung", bukan "-" atau tebakan.
- Output panjang dipadatkan sebelum dikirim ke model.
- Perintah yang gagal "Unknown command" atau tidak tersedia tidak dicoba ulang dengan variasi nama yang sama. Pilih padanan dari `nx env`.
- Maksimal dua percobaan per tujuan. Setelah itu agen melapor apa yang gagal dan apa yang sudah dicoba.

Uji penerimaan tahap 7: simulasi `nx sh 'toybox du'` di HP menghasilkan satu penolakan dan saran `nx du`, bukan empat percobaan.

## Format laporan di setiap tahap

- Daftar file yang diubah.
- Bukti: output tes JVM (lulus atau gagal, dengan jumlah), output `assembleRelease`, dan output perintah yang diuji.
- Yang belum diverifikasi, dengan jelas: pengujian di HP sungguhan, VPS sungguhan, dan internet sungguhan.
- Pertanyaan terbuka yang perlu keputusan pemilik.
