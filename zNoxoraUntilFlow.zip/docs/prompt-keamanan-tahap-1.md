Kamu mengerjakan aplikasi Android "UntilyFlow" (Kotlin, Jetpack Compose, ada C++ lewat CMake) di repo ini. Tugas: upgrade keamanan TAHAP 1 saja. Jangan mengerjakan tahap lain.

Baca dulu CLAUDE.md dan CODEMIND.md, ikuti semua aturannya.

## Aturan wajib

- Kerjakan hanya tahap 1 ini. Setelah selesai, berhenti dan laporkan. Jangan lanjut ke enkripsi string, native code, atau cek integritas.
- Jangan hapus tool MCP, perintah `nx` (termasuk `nx cm`), atau fitur yang sudah ada. Semua fitur AI, terminal, VPS, dan CodeMind harus tetap bekerja.
- Jangan menulis komentar di kode.
- Semua teks UI lewat tr(), dan tambahkan kuncinya ke LangEn dan LangId.
- Jangan commit atau tampilkan isi password dan keystore di laporan. Sebut nama variabelnya saja.
- Jangan klaim build release sukses atau tes lulus kalau tidak dijalankan. Tulis jelas apa yang diverifikasi.

## Bagian A: keluarkan rahasia dari repo

Di `app/build.gradle.kts`, blok `signingConfigs` berisi `storePassword` dan `keyPassword` yang tertulis langsung, dan `noxora.jks` ada di folder app.

1. Ganti nilai password dengan pembacaan dari `gradle.properties` di home pengguna (`~/.gradle/gradle.properties`) atau environment variable. Pakai nama properti yang jelas, misalnya `NOXORA_STORE_PASSWORD`, `NOXORA_KEY_PASSWORD`, dan `NOXORA_KEYSTORE_PATH`.
2. Kalau properti tidak ada, build release harus gagal dengan pesan yang jelas. Build debug tetap jalan.
3. Tambahkan `*.jks`, `*.keystore`, dan `keystore.properties` ke `.gitignore`.
4. Jangan hapus `noxora.jks` dari disk. Cukup beri tahu di laporan bahwa file itu dan password lama sudah ada di repo dan zip sebelumnya, dan sebaiknya kunci dibuat ulang kalau pernah dibagikan.

## Bagian B: R8 untuk build release

Di blok `release`:

1. Aktifkan `isMinifyEnabled = true` dan `isShrinkResources = true`.
2. Pakai `proguard-android-optimize.txt` dan `proguard-rules.pro`.
3. Tulis aturan `keep` yang diperlukan untuk:
   - metode JNI dan kelas yang memanggil native (cek semua `external fun` di `app/src/main/kotlin`, dan semua `System.loadLibrary`)
   - kelas yang dipakai lewat reflection atau nama string
   - model data yang diserialisasi ke JSON (AiStore, pengaturan, catatan CodeMind, brief)
   - Compose dan kelas yang dibutuhkan library di `build.gradle.kts`
4. Jangan pakai `-dontobfuscate` atau `keep` yang lebar hanya untuk membuat build lolos. Setiap `keep` harus punya alasan yang bisa ditunjuk di kode.
5. Jalankan `./gradlew assembleRelease` kalau memungkinkan. Kalau tidak bisa, katakan demikian.
6. Setelah build, cek `mapping.txt` dan hasil dex: nama kelas utama seperti `CodeMind` dan `AiClient` harus sudah berubah.

## Bagian C: simpan rahasia pengguna dengan Android Keystore

Saat ini API key provider AI disimpan di `AiStore` dalam bentuk teks biasa (field `key` di JSON). Ini harus dilindungi.

1. Cari semua tempat rahasia disimpan di app: API key AI (AiStore dan AiProfile), password atau kunci SSH VPS, token MCP, dan header otorisasi yang disimpan. Tulis daftarnya di laporan sebelum mengubah apa pun.
2. Buat satu pembungkus enkripsi di inti yang bisa dites, misalnya `SecretBox`, yang memakai AES-GCM dengan kunci dari Android Keystore (`AndroidKeyStore`, alias khusus app, tidak bisa diekspor).
3. Pembacaan data lama wajib tetap berhasil. Kalau data lama masih teks biasa, baca lalu simpan ulang dalam bentuk terenkripsi saat pertama kali disimpan. Jangan kehilangan API key pengguna saat upgrade.
4. Kalau Keystore gagal diinisialisasi (perangkat tertentu, emulator), tampilkan pesan yang jelas dan jangan diam-diam menyimpan teks biasa.
5. Tulis tes JVM untuk logika format dan migrasi (format terenkripsi, pembacaan data lama, dan penolakan data yang rusak). Keystore sendiri tidak bisa dites di JVM, jadi bagian itu ditandai untuk diuji di perangkat.

## Bagian D: pembersihan kecil

- Pastikan log tidak mencetak API key, password, atau isi header otorisasi. Cari `Log.`, `println`, dan pesan error yang memuat nilai rahasia.

## Format laporan

- Daftar file yang diubah.
- Daftar rahasia yang ditemukan dan status tiap rahasia (sudah terenkripsi, belum, atau sengaja ditunda).
- Apa yang diverifikasi: tes JVM dijalankan atau tidak, `assembleRelease` berhasil atau tidak, `mapping.txt` sudah menunjukkan rename atau belum.
- Apa yang harus dicek di perangkat: upgrade dari versi lama dengan API key tersimpan, semua fitur AI, terminal, VPS, dan CodeMind pada build release.
- Tindakan yang perlu dilakukan pemilik sendiri: membuat ulang keystore dan password, serta menghapus salinan lama dari repo atau zip.
