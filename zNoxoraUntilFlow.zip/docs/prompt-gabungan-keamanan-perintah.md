Kamu mengerjakan aplikasi Android "UntilyFlow" (Kotlin, Jetpack Compose, ada C++ lewat CMake) di repo ini. Tugas: upgrade keamanan dan kemampuan perintah agen, bertahap. Kerjakan HANYA satu tahap per run. Setelah selesai, berhenti, laporkan, dan tunggu konfirmasi.

Baca dulu CLAUDE.md, CODEMIND.md, dan konsep-v6-pro.md. Ikuti semua aturannya.

## Aturan wajib (berlaku di semua tahap)

- Jangan hapus tool MCP, perintah `nx` yang sudah ada (termasuk `nx cm`), atau fitur yang sudah ada.
- Jangan menulis komentar di kode.
- Semua teks UI lewat tr(), dan tambahkan kuncinya ke LangEn dan LangId.
- Pengaturan baru lewat CmPrefs atau prefs milik modul yang relevan, bukan Cfg, kecuali memang milik Cfg.
- Logika murni ditaruh di inti non-Android dan dites di JVM.
- Jangan commit atau cetak isi password, API key, atau keystore di laporan. Sebut nama variabelnya saja.
- Jangan klaim build atau tes sukses kalau tidak dijalankan. Tulis dengan jelas apa yang diverifikasi.
- Jangan refactor di luar tahap yang sedang dikerjakan.

## Tahap A: keamanan

1. Pindahkan `storePassword` dan `keyPassword` dari `app/build.gradle.kts` ke `~/.gradle/gradle.properties` atau environment variable (`NOXORA_STORE_PASSWORD`, `NOXORA_KEY_PASSWORD`, `NOXORA_KEYSTORE_PATH`). Kalau properti tidak ada, build release gagal dengan pesan jelas. Build debug tetap jalan.
2. Tambahkan `*.jks`, `*.keystore`, dan `keystore.properties` ke `.gitignore`. Jangan hapus `noxora.jks` dari disk, tapi tulis di laporan bahwa kunci dan password lama sudah ada di repo dan zip, sehingga sebaiknya dibuat ulang.
3. Aktifkan `isMinifyEnabled = true` dan `isShrinkResources = true` di blok release, dengan `proguard-android-optimize.txt` dan `proguard-rules.pro`. Tulis `keep` untuk metode JNI (cek semua `external fun` dan `System.loadLibrary`), kelas yang dipakai reflection, dan model yang diserialisasi ke JSON (AiStore, pengaturan, catatan CodeMind). Setiap `keep` harus punya alasan yang bisa ditunjuk di kode. Jangan pakai `-dontobfuscate` atau `keep` lebar hanya agar build lolos.
4. Rahasia pengguna (API key di AiStore dan AiProfile, password atau kunci SSH VPS, token MCP, header otorisasi) saat ini disimpan sebagai teks biasa. Buat daftarnya dulu di laporan. Lalu buat `SecretBox` di inti yang bisa dites: AES-GCM dengan kunci dari Android Keystore (`AndroidKeyStore`, alias khusus app, tidak bisa diekspor). Data lama yang masih teks biasa dibaca lalu disimpan ulang terenkripsi saat pertama kali ditulis. Jangan kehilangan key pengguna saat upgrade. Kalau Keystore gagal diinisialisasi, tampilkan pesan jelas dan jangan diam-diam menyimpan teks biasa.
5. Pastikan log tidak mencetak API key, password, atau isi header otorisasi. Cari `Log.`, `println`, dan pesan error yang memuat nilai rahasia.
6. Penghapusan file atau folder lebih dari satu item, di semua permukaan (terminal, AI File, VPS), wajib konfirmasi yang menyebut setiap nama lewat ApprovalBoard. Perintah destruktif (rm, rmdir, mv yang menimpa, dan sejenisnya) tidak boleh dijalankan pada akar storage, `/`, `/sdcard`, atau folder media tingkat atas. Pola seperti "hapus semua file" harus meminta daftar nama dulu, bukan langsung menjalankan rm.
7. Tes JVM untuk logika migrasi, format terenkripsi, penolakan data rusak, dan logika konfirmasi hapus. Bagian Keystore ditandai untuk diuji di perangkat.

Laporkan dan berhenti.

## Tahap B: deteksi kemampuan dan `nx env`

Tujuan: agen tidak menebak apa yang tersedia. Ia memeriksanya dulu, sekali per sesi, lalu memilih perintah yang memang bisa jalan.

1. Tambahkan `nx env` yang mengembalikan ringkasan kemampuan dalam format pendek:
   - Lokal: daftar perintah nx yang tersedia, ada atau tidaknya `node`, `python`, `git`, `zip`, `unzip` (cek dengan probe, bukan asumsi).
   - Shell bawaan app: apa saja yang dikenali (ls, find, grep, cat, cd, pwd, cp, mv, rm, mkdir, dll), dan apa yang tidak (du, toybox, dll).
   - VPS: tidak dikonfigurasi, dikonfigurasi tapi tidak tersambung, atau tersambung. Kalau tersambung, tampilkan OS, versi shell, dan apakah node, python, git, du, tar tersedia di sana.
   - Internet: tersedia atau tidak (cek konektivitas sistem, bukan mengunduh data besar).
   - CodeMind: proyek yang terindeks dan umur indeksnya.
   - Browser: WebView sudah dibuka atau belum.
2. Tambahkan `nx help` yang mencetak daftar perintah lengkap dengan satu baris contoh dan kemampuan yang dibutuhkan (misalnya "butuh VPS").
3. Hasil `nx env` dicache per sesi dan diperbarui saat ada perubahan (VPS tersambung atau putus, internet hilang).
4. Agen hanya memanggil perintah yang statusnya tersedia. Kalau perintah butuh VPS dan VPS tidak tersambung, agen langsung memakai padanan lokal atau memberi tahu pengguna, tanpa mencoba dulu.

Laporkan dan berhenti.

## Tahap C: perintah lengkap di tempat biasa (agen, AI File, file manager, dan AI lain)

Semua perintah ini dijalankan lewat OneTool dan berlaku sama di terminal, AI File, dan AI lain. Di HP tanpa VPS, ini adalah jalur utama.

Navigasi dan isi:
- `nx ls [path]`: daftar isi dengan ukuran file, tipe, dan waktu ubah. Untuk folder, tampilkan jumlah item.
- `nx du [path]`: ukuran rekursif per folder dan total, dihitung di dalam app (tidak bergantung pada `du` di shell). Hasilnya diurutkan dari terbesar.
- `nx tree [path] [kedalaman]`: pohon folder dengan batas kedalaman dan batas jumlah item.
- `nx stat <path>`: ukuran, tanggal ubah, izin, dan tipe.
- `nx find <nama> [path]`, `nx grep <teks> [path]`: sudah ada, tambahkan pengelompokan per file dan batas hasil.
- `nx read <path> [dari] [sampai]`, `nx head <path> [n]`, `nx tail <path> [n]`: sudah ada atau baru, dengan batas karakter yang konsisten.
- `nx sym`, `nx file`, `nx deps`, `nx ctx`, `nx cm index`: CodeMind yang sudah ada.

Membuat dan mengubah (diberi konfirmasi bila lebih dari satu item):
- `nx write <path>`: tulis file baru atau timpa dengan konfirmasi.
- `nx edit <path>`: patch potongan kecil (old_str dan new_str), bukan menulis ulang file utuh.
- `nx mkdir <path>`, `nx cp <src> <dst>`, `nx mv <src> <dst>`: mv yang menimpa wajib konfirmasi.
- `nx rm <path>`: konfirmasi untuk setiap nama. Tidak ada rm massal tanpa daftar.

Arsip dan data:
- `nx zip <sumber> <tujuan.zip>`, `nx unzip <zip> [tujuan]`: dibuat di dalam app (tidak bergantung pada zip di shell), dengan batas ukuran dan pengecekan path agar tidak keluar dari folder tujuan (zip slip).
- `nx hash <path>` (SHA-256), `nx diff <a> <b>`.
- `nx json <path> [kunci]`: baca nilai JSON tanpa memuat seluruh file.

Jaringan dan web:
- `nx fetch <url>`: GET dari proses app, hanya http dan https, tolak 127.0.0.1, localhost, rentang privat (10.x, 172.16–31.x, 192.168.x), dan link-local. Ada timeout dan batas ukuran. HTML diubah jadi teks. Domain baru minta persetujuan. Kalau keputusan domain belum ada, tandai sebagai pertanyaan terbuka dan jangan memutuskan sendiri.
- `nx web`, `nx text`, `nx js`: sudah ada, tetap dengan persetujuan untuk `nx js`.

Proyek kecil di HP:
- `nx sh <perintah>`: hanya untuk perintah yang ada di shell bawaan, dan agen wajib memeriksa `nx env` dulu. Perintah yang tidak dikenali harus langsung ditolak dengan pesan "tidak tersedia di shell HP, pakai nx du/nx ls/nx find" dan tidak dicoba ulang dengan variasi nama yang sama.

Laporkan dan berhenti.

## Tahap D: perintah lengkap di VPS (SSH)

Aktif hanya kalau VPS tersambung. Perintah VPS memakai nama yang sama dengan lokal supaya agen tidak perlu belajar dua set.

- Semua perintah di Tahap C berjalan di VPS saat target adalah VPS, dengan implementasi yang sesuai OS VPS (`du`, `find`, `tar`, `zip`, dll).
- `nx sh <perintah>` di VPS menjalankan shell penuh. Tetap ada persetujuan untuk perintah yang menghapus, menimpa, atau mengubah izin di luar folder kerja.
- `nx node <file>` dan `nx py <file>`: hanya kalau `nx env` menunjukkan versi tersedia. Batas waktu dan batas output wajib.
- `nx install <paket>`: hanya di VPS, dengan persetujuan. Di HP tidak tersedia.
- `nx sync` dan `nx cm index` di VPS: throttle lebih lama (sudah ada di CodeMind), tidak memblokir run agen, dan hanya jalan saat tersambung.
- Auto-reconnect: saat SSH putus, port forward dipasang ulang otomatis. Alamat MCP di UI dihapus kalau forward tidak hidup. Beberapa forward per VPS harus bebas konflik port, port remote yang sama dua kali ditolak dengan pesan jelas.

Laporkan dan berhenti.

## Tahap E: format hasil dan retry

Format:
- Jangan pakai tabel dengan pipa `|` di chat. Gunakan daftar dengan satu baris per item: nama, ukuran dalam satuan manusia (KB, MB, GB), dan keterangan singkat.
- Urutkan dari terbesar. Total ditaruh di baris pertama.
- Folder yang ukurannya belum dihitung ditandai "dihitung" atau "tidak tersedia", bukan "-" atau tebakan.
- Output tool yang panjang dipadatkan sebelum sampai ke model, sesuai batas yang sudah ada.

Retry:
- Kalau sebuah perintah gagal dengan "Unknown command" atau tidak tersedia, jangan dicoba ulang dengan variasi yang sama. Pilih padanan dari `nx env` atau `nx help`.
- Maksimal dua percobaan per tujuan. Setelah itu agen melapor apa yang gagal dan apa yang sudah dicoba.
- Jangan mengulang perintah yang sudah gagal dengan alasan yang sama.

Laporkan dan berhenti.

## Format laporan di setiap tahap

- Daftar file yang diubah.
- Apa yang diverifikasi: tes JVM dijalankan atau tidak, hasilnya apa.
- Apa yang belum diverifikasi dan perlu dicek di perangkat (build release, Keystore, VPS sungguhan, internet sungguhan).
- Pertanyaan terbuka yang perlu keputusan pemilik.
