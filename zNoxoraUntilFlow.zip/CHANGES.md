# CHANGES (belum dikompilasi)

## 4.0.0
Diperbaiki: crash IllegalArgumentException alpha negatif di NxBottomBar (nilai spring "barSel" undershoot, kini di-coerce 0..1); coerce alpha di AiScreen, Splash, Motion.
Ditambah: tab Changelog di Pengaturan (home/ChangelogPane.kt).
Versi: versionName 4.0.0, versionCode 4. Signing V1, V2, V3 aktif.

## Fase 5
Diubah (22 file .kt): ai/AiScreen.kt, ai/ModelPicker.kt, ai/FlowScreen.kt, agent/AgentSheet.kt, terminal/TermParts.kt, codemind/CodeMindScreen.kt, ssh/Screens.kt, ssh/VpsScreen.kt, ssh/SessionBar.kt, ssh/SystemPane.kt, ssh/TransferPane.kt, web/WebScreen.kt, github/GitScreen.kt, github/GitRepoView.kt, github/GitBrowseView.kt, github/GitActionsView.kt, cash/CashflowScreen.kt, cash/CashCharts.kt, task/TaskViews.kt, errors/ErrorsScreen.kt, localhost/LocalhostSheet.kt, viewer/EditorScreen.kt
Bahasa: lang/LangEn.kt dan lang/LangId.kt (+ kunci "Active").

Catatan:
- terminal/TermParts.kt tidak ada di daftar, tetapi input bar agen (TermPrompt) ada di sana dan dipakai bersama terminal HP.
- Logika, data, handler, dan navigasi tidak diubah. Tombol Back di semua layar tetap.
- Signature Nx* tidak berubah, tidak ada komponen baru di fase 5 (CodeMind punya StatTile private yang membungkus NxCard + NxIconBox).
- Warna: tidak ada Color(0x...) tersisa di file fase 5 selain ssh/TerminalView.kt (sengaja tetap). Warna irisan donat di CashCharts kini token (Accent, Live, Danger, varian alpha, Dim), jadi urutan warnanya berbeda dari sebelumnya.

Sengaja dihilangkan atau diganti:
- Grid 2 kolom kartu alat di hub GitHub diganti daftar NxListRow (data sama).
- Ikon bernapas (nxBreathe) di header Panel SystemPane diganti NxIconBox statis.
- Garis pemisah tipis antar baris di daftar repo, Browse, Actions, riwayat browser diganti jarak antar baris/kartu.
- Tidak ada elemen data palsu yang ditambahkan. Titik hijau server hanya muncul bila Hub.vps cocok dengan profil (host, port, user). Kartu stat CodeMind memakai view.stats yang sama dengan tabel sebelumnya (tiga baris Kv dipindah ke kartu).

Risiko compile (belum diverifikasi):
- ai/AiScreen.kt, cash/CashflowScreen.kt: NxSegment dipanggil dengan List<Pair<String, ImageVector>> dan List<Pair<String, Nothing?>> untuk parameter List<Pair<String, ImageVector?>>; seharusnya lolos lewat kovarians.
- ssh/Screens.kt: `Hub.vps?.profile?.let` (safe call pada tipe non-null, hanya peringatan).
- web/WebScreen.kt: `decorationBox` pada BasicTextField bersama modifier padding dan onFocusChanged.
- ssh/VpsScreen.kt: `NxBarItem(...) { hideKeyboard(view); tab = 0 }` (lambda berakhir assignment).
- Impor tak terpakai tersisa di beberapa file (hanya peringatan).

## Fase 1–4
Ditambah: ui/NxCloud.kt, home/ToolsScreen.kt
Diubah: ui/Theme.kt, ui/NxV3.kt, ui/NxTile.kt, core/Motion.kt, core/Shell.kt, home/Home.kt, home/SettingsScreen.kt, files/LocalFiles.kt, files/FilesPane.kt, lang/LangEn.kt, lang/LangId.kt
Sengaja dihilangkan (tidak ada data/fungsi nyata): bell notifikasi, profil Noxora, Akun/Notifikasi/Bantuan, Proyek Terbaru, Bagikan, layar detail folder, waktu ubah file, tombol filter di search bar.

## iBank Style
- Theme.kt: single iBank palette (light/dark), semantic colors, purple NxBar header with sheet corners, edge-to-edge system bars, shadow cards, pill buttons, 16dp fields.
- Poppins added (res/font), default UI font. SemiBold maps to the Bold file until a real Poppins-SemiBold.ttf is added.
- New: NxGridTile, NxFab, NxComposer, NxHeadAction, NxPress; NxSegment is a sliding pill; NxChip is pill; NxBottomBar is a 5-tab pill nav.
- Home: hero "My device" card + 3-column tile grid. Tools: semantic tints. AI: primary/tint bubbles that wrap, floating composer.
- Files: header with search/overflow, segmented tabs, chip row, breadcrumb, 64dp rows, FAB speed-dial, contextual selection bar.
- Launcher icon replaced (adaptive + legacy), Splash uses the new logo.
